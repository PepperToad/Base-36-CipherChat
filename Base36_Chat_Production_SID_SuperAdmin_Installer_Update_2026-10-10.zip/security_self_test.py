import asyncio
import inspect
import json
import py_compile
import tempfile
import uuid
from pathlib import Path

from websockets.asyncio.client import connect
from websockets.asyncio.server import serve

from cipher import ALPHABET, decode_message, encode_message
from relay import MAX_WS_MESSAGE_BYTES, RelayState, handle_client
from settings import SettingsStore


ROOT = Path(__file__).resolve().parent


def check(condition, label):
    if not condition:
        raise AssertionError(label)
    print(f"PASS - {label}")


def test_compile():
    for name in (
        "cipher.py",
        "profiles.py",
        "contacts.py",
        "engine.py",
        "app.py",
        "relay.py",
        "settings.py",
    ):
        py_compile.compile(str(ROOT / name), doraise=True)
        print(f"PASS - py_compile: {name}")


def test_cipher():
    samples = [
        "Steve",
        "steve",
        'Hello, Steve! "It\'s 06:30 — coffee?" ☕',
        "José",
        "こんにちは",
        "👍🏽",
        "👨‍👩‍👧‍👦",
        "Line one\nLine TWO\t✓",
    ]
    for sample in samples:
        a, b = encode_message(sample)
        check(a.get("version") == 2 and b.get("version") == 2, "cipher packet version 2")
        check(set(a["ciphertext"]) <= set(ALPHABET), "ciphertext remains Base36-only")
        recovered = decode_message(a, b)
        check(recovered == sample, f"UTF-8/case/emoji exact roundtrip: {sample!r}")

    upper = encode_message("Steve")[0]["ciphertext"]
    lower = encode_message("steve")[0]["ciphertext"]
    check(upper != lower, "case-sensitive plaintexts produce distinct encrypted packets")


def test_settings_no_message_content():
    secret = "THIS MUST NEVER BE IN SETTINGS ☕"
    with tempfile.TemporaryDirectory() as temp:
        store = SettingsStore("testuser", temp)
        store.update(
            appearance="dark",
            font_size=14,
            density="compact",
            notification_mode="generic",
        )
        raw = store.path.read_text(encoding="utf-8")
        check(secret not in raw, "settings file contains no test message content")
        document = json.loads(raw)
        check("settings" in document, "settings file roundtrip")
        check(document["settings"]["appearance"] == "dark", "settings persistence")


def test_static_no_plaintext_retry_queue():
    engine_source = (ROOT / "engine.py").read_text(encoding="utf-8")
    relay_source = (ROOT / "relay.py").read_text(encoding="utf-8")

    check("PendingSendQueue" not in engine_source, "GUI engine has no PendingSendQueue")
    check("pending_sends" not in engine_source, "GUI engine has no pending plaintext send store")
    check("flush_queued_messages" not in engine_source, "GUI engine has no queued-message flush path")
    check("pending_messages" not in relay_source, "relay has no offline pending-message collection")

    inflight_source = inspect.getsource(RelayState.add_inflight)
    check("payload" not in inflight_source, "relay inflight receipt state stores no payload")


async def register_client(uri, client_id):
    ws = await connect(
        uri,
        max_size=MAX_WS_MESSAGE_BYTES,
        compression=None,
    )
    await ws.send(json.dumps({
        "type": "register",
        "client_id": client_id,
        "client_protocol": 3,
        "requires_queue_mode": "none",
    }))
    response = json.loads(await asyncio.wait_for(ws.recv(), timeout=2))
    check(response.get("type") == "registered", f"relay registers {client_id}")
    check(response.get("queue_mode") == "none", "relay advertises no-queue mode")
    check(response.get("relay_protocol") == 2, "relay protocol version 2")
    return ws


async def test_relay_no_queue():
    state = RelayState("Self Test Relay")
    server = await serve(
        lambda websocket: handle_client(websocket, state),
        "127.0.0.1",
        0,
        max_size=MAX_WS_MESSAGE_BYTES,
        compression=None,
    )
    port = server.sockets[0].getsockname()[1]
    uri = f"ws://127.0.0.1:{port}"

    alice = bob = duplicate = None
    cleanup = asyncio.create_task(state.cleanup_loop())
    try:
        alice = await register_client(uri, "alice")

        # Offline recipient must fail immediately with zero message payload state.
        offline_id = uuid.uuid4().hex
        offline_secret = "OFFLINE SECRET MUST NOT BE RETAINED ☕"
        await alice.send(json.dumps({
            "type": "message",
            "message_id": offline_id,
            "to": "bob",
            "payload": {"kind": "data", "secret": offline_secret},
        }))
        offline_response = json.loads(await asyncio.wait_for(alice.recv(), timeout=2))
        check(offline_response.get("code") == "recipient_offline", "offline recipient is rejected immediately")
        check(not state.inflight, "offline message creates no relay inflight state")
        check(offline_secret not in repr(state.inflight), "offline plaintext/cipher payload is not retained")

        bob = await register_client(uri, "bob")

        # Connected recipient gets immediate forwarding; relay retains receipt metadata only.
        message_id = uuid.uuid4().hex
        secret = "FORWARDED OPAQUE PAYLOAD ☕"
        await alice.send(json.dumps({
            "type": "message",
            "message_id": message_id,
            "to": "bob",
            "payload": {"kind": "data", "secret": secret},
        }))

        forwarded = json.loads(await asyncio.wait_for(bob.recv(), timeout=2))
        accepted = json.loads(await asyncio.wait_for(alice.recv(), timeout=2))
        check(forwarded.get("message_id") == message_id, "connected message forwards immediately")
        check(accepted.get("type") == "accepted", "sender receives accepted receipt")
        check(message_id in state.inflight, "receipt metadata exists only while ACK is pending")
        check(set(state.inflight[message_id]) == {"sender", "recipient", "created"}, "inflight state is metadata-only")
        check(secret not in repr(state.inflight), "forwarded payload is not retained in relay state")

        await bob.send(json.dumps({"type": "ack", "message_id": message_id}))
        delivered = json.loads(await asyncio.wait_for(alice.recv(), timeout=2))
        check(delivered.get("type") == "delivered", "recipient ACK produces delivered receipt")
        check(message_id not in state.inflight, "ACK destroys receipt metadata")

        # Duplicate connected user IDs are blocked.
        duplicate = await connect(uri, max_size=MAX_WS_MESSAGE_BYTES, compression=None)
        await duplicate.send(json.dumps({"type": "register", "client_id": "alice"}))
        duplicate_response = json.loads(await asyncio.wait_for(duplicate.recv(), timeout=2))
        check(duplicate_response.get("code") == "already_connected", "duplicate connected user ID is rejected")

        # Malformed JSON is handled without crashing the relay.
        await alice.send("{not-json")
        malformed_response = json.loads(await asyncio.wait_for(alice.recv(), timeout=2))
        check(malformed_response.get("error") == "Invalid JSON", "malformed JSON is rejected cleanly")

    finally:
        for ws in (duplicate, bob, alice):
            if ws is not None:
                try:
                    await ws.close()
                except Exception:
                    pass
        cleanup.cancel()
        await asyncio.gather(cleanup, return_exceptions=True)
        server.close()
        await server.wait_closed()


def main():
    print("Base36 Cipher Chat — Secure Comfort Self-Test")
    print("=" * 60)
    test_compile()
    test_cipher()
    test_settings_no_message_content()
    test_static_no_plaintext_retry_queue()
    asyncio.run(test_relay_no_queue())
    print("=" * 60)
    print("ALL SELF-TESTS PASSED")


if __name__ == "__main__":
    main()
