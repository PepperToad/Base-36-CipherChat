import argparse
import json
import re
import tempfile
import time
import unicodedata
from pathlib import Path

from cryptography.hazmat.primitives.asymmetric import ed25519

from identity import (
    fingerprint,
    public_key_b64,
    public_key_from_b64,
)


CONTACTS_VERSION = 3
STATUS_PINNED = "pinned"
STATUS_LOCKED = "locked_key_change"
STATUS_REMOVED = "removed"
STATUS_REVOKED = "revoked"


def normalize_name(name):
    if not isinstance(name, str):
        raise TypeError("Contact name must be a string")

    name = name.strip().lower()

    if not re.fullmatch(r"[a-z0-9_-]{1,64}", name):
        raise ValueError(
            "Contact name may contain only letters, numbers, "
            "underscore, and hyphen"
        )

    return name


def normalize_display_label(value, field_name="Display name", allow_empty=False):
    """Validate a human-facing Unicode display name or local alias."""
    if value is None and allow_empty:
        return None
    if not isinstance(value, str):
        raise TypeError(f"{field_name} must be a string")

    value = unicodedata.normalize("NFC", value.strip())
    if not value:
        if allow_empty:
            return None
        raise ValueError(f"{field_name} cannot be empty")
    if len(value) > 64:
        raise ValueError(f"{field_name} is too long")
    if any(not ch.isprintable() for ch in value):
        raise ValueError(f"{field_name} contains an unsupported control character")
    return value


def normalize_fingerprint(value):
    if not isinstance(value, str):
        raise TypeError("Fingerprint must be a string")

    value = value.upper()
    value = re.sub(r"[\s:-]", "", value)

    if not re.fullmatch(r"[0-9A-F]{64}", value):
        raise ValueError(
            "Fingerprint must contain exactly 64 hexadecimal characters"
        )

    return value


def format_fingerprint_text(value):
    value = normalize_fingerprint(value)
    return " ".join(
        value[index:index + 4]
        for index in range(0, len(value), 4)
    )


class ContactStore:
    """Persistent identity pin store.

    Important security property:
    - ordinary users may hide/remove a contact from the UI, but the pinned
      identity record remains as a tombstone.
    - a different key for the same contact never silently replaces the pin.
      It transitions the contact to STATUS_LOCKED and requires administrator
      action to resolve.
    """

    def __init__(self, owner_id, directory=None):
        self.owner_id = normalize_name(owner_id)

        if directory is None:
            directory = Path(__file__).parent
        else:
            directory = Path(directory)

        self.path = directory / f"contacts_{self.owner_id}.json"
        self.contacts = {}
        self.load()

    def _migrate_entry(self, name, entry):
        # Version-1 stores used trusted=True/False with no status field.
        if "status" not in entry:
            entry["status"] = (
                STATUS_PINNED if entry.get("trusted") else STATUS_REMOVED
            )

        if entry.get("status") == STATUS_PINNED:
            entry["trusted"] = True
        else:
            entry["trusted"] = False

        entry.setdefault("name", name)
        entry.setdefault("display_name", name.replace("_", " ").title())
        entry.setdefault("local_alias", None)
        entry.setdefault("pinned_at", entry.get("verified_at") or entry.get("added_at"))
        entry.setdefault("last_seen_at", entry.get("added_at"))
        entry.setdefault("removed_at", None)
        entry.setdefault("locked_at", None)
        entry.setdefault("presented_public_key", None)
        entry.setdefault("presented_fingerprint", None)
        entry.setdefault("admin_history", [])
        entry.setdefault("source", "legacy")
        return entry

    def load(self):
        if not self.path.exists():
            self.contacts = {}
            return

        try:
            document = json.loads(
                self.path.read_text(encoding="utf-8")
            )
        except Exception as exc:
            raise ValueError(
                f"Contact store is invalid: {self.path}"
            ) from exc

        version = document.get("version", 1)
        if version not in (1, 2, CONTACTS_VERSION):
            raise ValueError(
                f"Unsupported contact-store version: {version}"
            )

        if document.get("owner") != self.owner_id:
            raise ValueError("Contact store owner mismatch")

        contacts = document.get("contacts", {})
        if not isinstance(contacts, dict):
            raise ValueError("Contact store contacts are invalid")

        self.contacts = {
            normalize_name(name): self._migrate_entry(normalize_name(name), dict(entry))
            for name, entry in contacts.items()
            if isinstance(entry, dict)
        }

        # Persist migration so future reads are unambiguous.
        if version != CONTACTS_VERSION:
            self.save()

    def save(self):
        document = {
            "version": CONTACTS_VERSION,
            "owner": self.owner_id,
            "contacts": self.contacts,
        }

        temp = self.path.with_suffix(".tmp")
        temp.write_text(
            json.dumps(document, sort_keys=True, indent=2, ensure_ascii=False),
            encoding="utf-8",
        )
        temp.replace(self.path)

    def reload(self):
        self.load()

    def _new_entry(self, name, public_key, source, display_name=None):
        now = int(time.time())
        encoded_key = public_key_b64(public_key)
        fp = fingerprint(public_key)
        if display_name is None:
            display_name = name.replace("_", " ").title()
        display_name = normalize_display_label(display_name)

        return {
            "name": name,
            "display_name": display_name,
            "local_alias": None,
            "public_key": encoded_key,
            "fingerprint": fp,
            "trusted": True,
            "status": STATUS_PINNED,
            "source": source,
            "added_at": now,
            "pinned_at": now,
            "last_seen_at": now,
            "removed_at": None,
            "locked_at": None,
            "presented_public_key": None,
            "presented_fingerprint": None,
            "admin_history": [],
        }

    def pin_first_seen(
        self,
        name,
        public_key,
        source="contact-handshake",
        display_name=None,
    ):
        """Pin a first-seen identity, or enforce the existing pin.

        Returns (entry, created, changed_detected).
        """
        name = normalize_name(name)
        if name == self.owner_id:
            raise ValueError("Cannot add yourself as a contact")

        encoded_key = public_key_b64(public_key)
        fp = fingerprint(public_key)
        now = int(time.time())
        existing = self.contacts.get(name)

        if existing is None:
            entry = self._new_entry(
                name, public_key, source, display_name=display_name
            )
            self.contacts[name] = entry
            self.save()
            return entry, True, False

        # A revoked identity can never be user-restored.
        if existing.get("status") == STATUS_REVOKED:
            if existing.get("public_key") != encoded_key:
                self.lock_key_change(name, public_key, source=source)
            raise ValueError(
                f"{name} is revoked. Administrator action is required."
            )

        if existing.get("public_key") == encoded_key:
            existing["last_seen_at"] = now
            if display_name is not None:
                existing["display_name"] = normalize_display_label(display_name)

            # A user may restore a locally hidden contact only if the exact
            # same previously pinned key returns.
            if existing.get("status") == STATUS_REMOVED:
                existing["status"] = STATUS_PINNED
                existing["trusted"] = True
                existing["removed_at"] = None

            # Never let a reappearance clear a security lock by itself.
            if existing.get("status") == STATUS_LOCKED:
                existing["trusted"] = False

            self.save()
            return existing, False, False

        # Same contact name, different identity key = hard security lock.
        locked = self.lock_key_change(name, public_key, source=source)
        return locked, False, True

    def lock_key_change(self, name, presented_public_key, source="network"):
        name = normalize_name(name)
        entry = self.require(name, include_removed=True)
        presented_encoded = public_key_b64(presented_public_key)
        presented_fp = fingerprint(presented_public_key)

        # If this exact candidate was already recorded, only update last seen.
        entry["status"] = STATUS_LOCKED
        entry["trusted"] = False
        entry["locked_at"] = entry.get("locked_at") or int(time.time())
        entry["last_seen_at"] = int(time.time())
        entry["presented_public_key"] = presented_encoded
        entry["presented_fingerprint"] = presented_fp
        entry["presented_source"] = source
        self.save()
        return entry

    def get(self, name, include_removed=True):
        name = normalize_name(name)
        entry = self.contacts.get(name)
        if entry is None:
            return None
        if not include_removed and entry.get("status") == STATUS_REMOVED:
            return None
        return entry

    def set_display_name(self, name, display_name):
        """Update remote-owned display metadata after engine signature checks."""
        name = normalize_name(name)
        entry = self.require(name, include_removed=True)
        entry["display_name"] = normalize_display_label(display_name)
        self.save()
        return entry

    def set_local_alias(self, name, alias):
        """Set/clear a label that exists only in this local contact store."""
        name = normalize_name(name)
        entry = self.require(name, include_removed=True)
        entry["local_alias"] = normalize_display_label(
            alias, field_name="Contact label", allow_empty=True
        )
        self.save()
        return entry

    def require(self, name, include_removed=True):
        entry = self.get(name, include_removed=include_removed)
        if entry is None:
            raise ValueError(f"Unknown contact: {normalize_name(name)}")
        return entry

    def is_trusted(self, name):
        entry = self.get(name)
        return bool(
            entry
            and entry.get("status") == STATUS_PINNED
            and entry.get("trusted")
        )

    def status(self, name):
        entry = self.get(name)
        if entry is None:
            return None
        return entry.get("status")

    def get_public_key(self, name, require_trusted=True):
        entry = self.require(name)

        if require_trusted and not self.is_trusted(name):
            status = entry.get("status")
            if status == STATUS_LOCKED:
                raise ValueError(
                    f"IDENTITY KEY CHANGE LOCK for {normalize_name(name)}. "
                    "Administrator action is required."
                )
            if status == STATUS_REVOKED:
                raise ValueError(
                    f"{normalize_name(name)} identity is revoked."
                )
            raise ValueError(
                f"Contact {normalize_name(name)} is not available for secure messaging"
            )

        return public_key_from_b64(entry["public_key"])

    def hide_contact(self, name):
        """Remove from ordinary UI without deleting the identity pin."""
        name = normalize_name(name)
        entry = self.require(name)
        if entry.get("status") in (STATUS_LOCKED, STATUS_REVOKED):
            raise ValueError(
                "Security-locked or revoked contacts cannot be cleared by a standard user"
            )
        entry["status"] = STATUS_REMOVED
        entry["trusted"] = False
        entry["removed_at"] = int(time.time())
        self.save()
        return True

    def list_contacts(self, include_removed=False):
        result = []
        for name, entry in self.contacts.items():
            if not include_removed and entry.get("status") == STATUS_REMOVED:
                continue
            result.append(entry)

        def sort_key(entry):
            label = (
                entry.get("local_alias")
                or entry.get("display_name")
                or entry.get("name")
                or ""
            )
            return (str(label).casefold(), str(entry.get("name", "")))

        return sorted(result, key=sort_key)

    def list_locked(self):
        return [
            entry
            for entry in self.list_contacts(include_removed=True)
            if entry.get("status") == STATUS_LOCKED
        ]

    # ------------------------------------------------------------------
    # ADMINISTRATOR-ONLY MUTATIONS
    # The caller must enforce administrator authorization. Ordinary UI
    # paths never call these methods.
    # ------------------------------------------------------------------

    def admin_authorize_replacement(self, name, admin_id, reason):
        name = normalize_name(name)
        entry = self.require(name)

        if entry.get("status") != STATUS_LOCKED:
            raise ValueError("Contact is not waiting for an identity replacement")

        new_key = entry.get("presented_public_key")
        new_fp = entry.get("presented_fingerprint")
        if not new_key or not new_fp:
            raise ValueError("No replacement identity is available")

        old_fp = entry["fingerprint"]
        now = int(time.time())

        entry.setdefault("admin_history", []).append({
            "action": "authorize_identity_replacement",
            "admin": normalize_name(admin_id),
            "reason": str(reason).strip(),
            "at": now,
            "old_fingerprint": old_fp,
            "new_fingerprint": new_fp,
        })

        entry["public_key"] = new_key
        entry["fingerprint"] = new_fp
        entry["status"] = STATUS_PINNED
        entry["trusted"] = True
        entry["pinned_at"] = now
        entry["locked_at"] = None
        entry["presented_public_key"] = None
        entry["presented_fingerprint"] = None
        entry["presented_source"] = None
        entry["last_seen_at"] = now
        self.save()
        return entry

    def admin_reject_presented_key(self, name, admin_id, reason):
        """Discard the candidate key and restore the previously pinned key."""
        name = normalize_name(name)
        entry = self.require(name)

        if entry.get("status") != STATUS_LOCKED:
            raise ValueError("Contact is not security locked")

        now = int(time.time())
        entry.setdefault("admin_history", []).append({
            "action": "reject_presented_identity",
            "admin": normalize_name(admin_id),
            "reason": str(reason).strip(),
            "at": now,
            "pinned_fingerprint": entry["fingerprint"],
            "rejected_fingerprint": entry.get("presented_fingerprint"),
        })

        entry["status"] = STATUS_PINNED
        entry["trusted"] = True
        entry["locked_at"] = None
        entry["presented_public_key"] = None
        entry["presented_fingerprint"] = None
        entry["presented_source"] = None
        self.save()
        return entry

    def admin_revoke(self, name, admin_id, reason):
        name = normalize_name(name)
        entry = self.require(name)
        now = int(time.time())
        entry.setdefault("admin_history", []).append({
            "action": "revoke_identity",
            "admin": normalize_name(admin_id),
            "reason": str(reason).strip(),
            "at": now,
            "fingerprint": entry["fingerprint"],
        })
        entry["status"] = STATUS_REVOKED
        entry["trusted"] = False
        entry["revoked_at"] = now
        self.save()
        return entry


def self_test():
    print()
    print("=" * 60)
    print(" Base36 Contact Pinning Self-Test")
    print("=" * 60)
    print()

    alice = ed25519.Ed25519PrivateKey.generate()
    bob = ed25519.Ed25519PrivateKey.generate()
    replacement_bob = ed25519.Ed25519PrivateKey.generate()

    with tempfile.TemporaryDirectory() as temp:
        store = ContactStore("alice", temp)

        print("TEST 1: First-seen key pins automatically")
        entry, created, changed = store.pin_first_seen("bob", bob.public_key())
        assert created and not changed and store.is_trusted("bob")
        print("STATUS : PASS")
        print("-" * 60)

        print("TEST 2: Same key remains trusted")
        entry, created, changed = store.pin_first_seen("bob", bob.public_key())
        assert not created and not changed and store.is_trusted("bob")
        print("STATUS : PASS")
        print("-" * 60)

        print("TEST 3: Different key causes hard lock")
        entry, created, changed = store.pin_first_seen("bob", replacement_bob.public_key())
        assert changed and entry["status"] == STATUS_LOCKED and not store.is_trusted("bob")
        print("STATUS : PASS")
        print("-" * 60)

        print("TEST 4: Standard user cannot hide locked contact")
        try:
            store.hide_contact("bob")
            print("STATUS : FAIL")
        except ValueError:
            print("STATUS : PASS")
        print("-" * 60)

        print("TEST 5: Admin can reject candidate and retain old pin")
        old_fp = fingerprint(bob.public_key())
        store.admin_reject_presented_key("bob", "admin", "suspected phishing")
        assert store.is_trusted("bob")
        assert store.require("bob")["fingerprint"] == old_fp
        print("STATUS : PASS")
        print("-" * 60)

        print("TEST 6: Admin can authorize legitimate replacement")
        store.pin_first_seen("bob", replacement_bob.public_key())
        store.admin_authorize_replacement("bob", "admin", "lost device")
        assert store.is_trusted("bob")
        assert store.require("bob")["fingerprint"] == fingerprint(replacement_bob.public_key())
        print("STATUS : PASS")
        print("-" * 60)

        print("TEST 7: User removal preserves pin")
        store.hide_contact("bob")
        assert store.require("bob")["status"] == STATUS_REMOVED
        store.pin_first_seen("bob", replacement_bob.public_key())
        assert store.is_trusted("bob")
        print("STATUS : PASS")
        print("-" * 60)

    print()
    print("Contact pinning self-test complete.")
    print()


def main():
    parser = argparse.ArgumentParser(description="Base36 contact pin store")
    parser.add_argument("--test", action="store_true")
    args = parser.parse_args()

    if args.test:
        self_test()
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
