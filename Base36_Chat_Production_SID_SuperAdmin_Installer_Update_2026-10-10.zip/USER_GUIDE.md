# Base36 Cipher Chat — User Guide

## Starting the app

Launch the application normally and choose a local user. New users receive a random permanent user ID and an Ed25519 identity. The display name can be edited later without changing the user ID or fingerprint.

The chat window reconnects to Relay A and Relay B automatically if either network connection drops. Reconnection restores the transport only; it never resends an old message.

## Contacts and invitations

Use **My Invite** to create a signed `B36C1-...` invitation. If the optional `qrcode` and Pillow packages are installed, the window also displays a QR code that can be saved as a PNG. The invitation contains the public cryptographic identity, immutable user ID, display name, protocol version, and signature; it does not contain email, phone, address, or other required PII.

To add somebody, click **Add Contact** and paste either their permanent user ID or invitation code. You can also copy an invitation to the clipboard and click **Paste Invite**. A signed invitation can pin the supplied identity without a centralized directory. A conflicting key for an already-pinned user ID causes the same hard security lock as normal contact onboarding.

If several contacts use the same display name, the sidebar adds a short ID suffix. Right-click a contact and choose **Rename local label** to give that person a private label such as `Steve - Accounting`. The alias stays only on your computer.

## Secure sessions and sending

Select a trusted contact. Base36 Chat prepares an authenticated secure session automatically. The composer stays disabled until the header says **Secure**.

A message is sent immediately or discarded. There is no plaintext retry queue and no offline mailbox. If the recipient is offline, a relay is unavailable, or the immediate send fails, Base36 Chat tells you that the message was not retained. Type/send it again yourself after the problem is corrected.

Message status may progress through **sending**, **sent**, and **delivered**. `Delivered` means both relay paths received the recipient's protocol ACK after successful processing. If the ACK cannot be confirmed, the app can show `sent • delivery unconfirmed`; it does not automatically retry.

The composer supports case-sensitive text, punctuation, Unicode, and emoji. The ☕ button opens the quick emoji picker. Supported shortcuts include `:coffee:`, `:)`, `:(`, `;)`, `:D`, `:P`, and `<3` when shortcuts are enabled in Settings.

## Conversation tools

Right-click a message to copy or reply. Replying includes a compact quoted reference inside the newly encrypted message. `Ctrl+F` searches only the current in-memory conversation. `Ctrl+K` searches the current contact list. Unread counts and recently used emoji are memory-only and disappear when the app closes.

The message editor grows automatically as you type. By default Enter sends and Shift+Enter inserts a newline. You can change the behavior in Settings; when Enter-to-send is disabled, Ctrl+Enter sends.

## Contact and identity tools

Right-click a contact for local alias editing, identity details, Copy User ID, Copy Fingerprint, and Remove. Removing a normal contact hides it but retains the original pinned identity as a tombstone so remove/re-add cannot be used to bypass key continuity.

**Contact Details** shows the current display name, local label, full user ID, trust status, fingerprint, and active session ID when one exists.

## Settings

Settings provides light/dark appearance, font size, compact/comfortable spacing, Enter-to-send behavior, emoji shortcut control, normal-message sound, distinct security-warning sound, and notification privacy.

Notification modes are **off**, **generic**, and **name**. Base36 Chat deliberately does not place plaintext message previews into Windows notification history. Generic mode reveals neither sender name nor message text; the app may flash its taskbar button and play the selected local sound.

## Emergency Lock

Press **Ctrl+Shift+L** or click **Emergency Lock** to clear the composer and current in-memory conversation structures, clear the application clipboard where possible, disconnect, and close the chat window. Production does not expose a profile chooser; reopen Base36 Chat while signed in to the same Windows account.

Emergency Lock reduces intentional application retention but is not forensic RAM wiping. The operating system, pagefile, screenshots, malware, or crash infrastructure may retain data outside the application's control.

## Security warning

If **IDENTITY KEY CHANGED** appears, secure messaging is suspended. There is no ordinary-user override. Do not remove and re-add the contact to work around it. Administrator review is required.
