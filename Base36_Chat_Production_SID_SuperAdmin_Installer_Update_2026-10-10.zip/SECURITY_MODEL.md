# Base36 Cipher Chat — Security and Privacy Model

## Purpose

Base36 Cipher Chat is an experimental secure-messaging client built around data minimization. The application is intentionally not an account directory, social network, cloud mailbox, or message archive. Its security objective is to authenticate pinned peers, protect message content in transit, split per-message key material across two relay paths, and retain as little message-related state as practical.

This prototype has **not** received an independent professional security audit. It should not be represented as proven secure for life-safety, legal-defense, intelligence, dissident, or other high-consequence use until external review has been completed.

## Core cryptographic layers

- Long-term Ed25519 identity keys authenticate users cryptographically.
- A first accepted contact key is pinned locally. A different key for the same immutable user ID causes a hard security lock; ordinary users cannot override it.
- Ephemeral X25519 session establishment is authenticated by the pinned Ed25519 identities. HKDF-SHA256 derives directional HMAC keys and session-confirmation material.
- Plaintext is converted from UTF-8 bytes into fixed-width Base36 symbols. The modular cipher remains `C_i = (P_i + K_i) mod 36` with a fresh random full-length `K` for each message.
- The message key is split additively into `Y1` and `Y2`, which travel over separate relay paths.
- HMAC-SHA256 binds sender, recipient, message ID, relay channel, session, replay metadata, and cipher body.
- Replay protection uses freshness checks and short-lived hashes of consumed message IDs.

## No-message-queue rule

Message delivery is **immediate or discarded**.

The GUI/protocol engine does not maintain a plaintext retry queue. If both relays are unavailable, the secure session is not ready, the recipient is offline, or an immediate send fails, Base36 Chat reports the failure and does not retain a copy for automatic retry. The user must send the message again manually.

The relay does not provide store-and-forward or an offline mailbox. It forwards an opaque packet immediately to an already-connected recipient or rejects it. While waiting for the recipient ACK, the relay keeps only short-lived receipt metadata consisting of the message ID, sender routing ID, recipient routing ID, and a monotonic timestamp. It does **not** retain the packet payload/ciphertext in an application queue.

Operating systems, network libraries, kernel socket buffers, Python internals, and hardware may create temporary copies outside application control. “No queue” means Base36 Chat deliberately implements no application-level message retry/offline storage mechanism; it is not a claim that every transient byte in a computer can be deterministically overwritten.

## Persistent data that is allowed

Base36 Chat intentionally persists only state required for identity, trust continuity, security, and local preferences:

- Windows-user-protected Ed25519 identity material (DPAPI in production) and public identity key files.
- `profiles.json`: immutable local user ID, editable display name, and creation metadata. Production authorization roles come from signed authority state rather than editable profile metadata.
- `contacts_<id>.json`: pinned public keys, fingerprints, trust/lock/tombstone state, remote display name, and local-only alias.
- replay-state hashes/expiry metadata.
- administrator identity-security audit metadata.
- `settings_<id>.json`: local UI preferences such as theme, font size, notification mode, and composer behavior.

These files must never contain conversation transcripts, message plaintext, offline messages, retry messages, per-message key `K`, or relay payload archives.

## Identity and PII minimization

A Base36 Chat identity consists primarily of a random immutable routing/user ID and a cryptographic public identity. Display names are user-selected and need not be legal names. Local aliases are visible only to the local user.

The protocol does not require email addresses, telephone numbers, street addresses, dates of birth, legal names, employer records, advertising identifiers, or a centralized user directory. A relay may observe a routing ID, but Base36 Chat does not maintain a database mapping that ID to real-world PII.

Signed invitation codes contain only the immutable user ID, display name, public identity key, client-protocol version, and signature. Saved QR images therefore represent a shareable public identity card, not a message archive.

## Metadata deliberately avoided

The application does not implement read receipts, last-seen history, typing indicators, persistent presence history, contact-cloud synchronization, analytics, advertising identifiers, or message telemetry. Delivery receipts are operational and short-lived; they are not persisted as a behavioral history.

Unread counts, emoji recents, conversation search indexes, and visible conversation history exist only in the running GUI and disappear when the application exits or Emergency Lock is used.

## Emergency Lock

Emergency Lock clears the composer and visible in-memory conversation structures, clears the application clipboard where possible, disconnects the relays, stops the engine, and closes the chat window. The development harness may return to its test profile chooser; the production client never exposes a cross-user profile chooser.

Because this application is written in Python, it cannot guarantee forensic zeroization of every previous RAM copy. Python strings are immutable and the operating system may use pagefiles, crash dumps, screenshots, or other mechanisms outside Base36 Chat's control.


## Windows account isolation and administrative authority

The production executable is installed machine-wide, but Base36 identity state is stored under the currently signed-in Windows user's `%LOCALAPPDATA%\Base36Chat` directory and bound to that account's Windows SID. The production executable does not expose `--id` identity selection or the development profile chooser.

A Base36 administrative environment has a dedicated Ed25519 authority key. The Super Administrator endpoint holds the DPAPI-protected authority private key. Other endpoints trust only the authority public key imported through a signed environment invitation. Administrator grants and revocations are signed authority statements. Administrative authority never includes message-decryption keys and never permits one Base36 user to launch or sign as another Base36 identity.

## Network anonymity is outside scope

Base36 Chat does **not** claim to hide source IP addresses, ISP records, network timing, traffic volume, or global traffic correlation. Users who require network-layer anonymity must use an appropriate external network/privacy layer such as a VPN or other independently evaluated solution.

This separation is intentional: Base36 Chat protects its own message and identity protocol rather than claiming to replace network-anonymity tools.

## Important residual risks

- Compromise of both relay paths for the same message defeats the split-relay confidentiality assumption.
- Compromise of an endpoint can expose displayed plaintext, clipboard contents, identity keys, and active session material.
- In production, private identity material is protected with Windows DPAPI and bound to the signed-in Windows user context. This is endpoint hardening, not a claim against malware or an attacker with sufficient Windows privileges.
- First contact still depends on the authenticity of the invitation/out-of-band exchange or the initial signed dual-relay exchange. Pinning protects continuity after that point.
- Denial of service remains possible. The design intentionally prefers dropping a message over storing it for later delivery.
- The custom protocol composition and implementation require independent cryptographic and application-security review before high-consequence deployment.
