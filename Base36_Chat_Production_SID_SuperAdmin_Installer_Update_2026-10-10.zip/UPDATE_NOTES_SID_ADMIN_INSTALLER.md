# Base36 Chat — Windows SID / Super Admin / Installer Update

This update adds the production deployment boundary discussed after the Secure Comfort build.

## Added

- Production identity is bound to the current Windows **SID**, not the visible Windows account name.
- Production state moves under `%LOCALAPPDATA%\Base36Chat`.
- Production has no application-level user/profile chooser and rejects command-line `--id` identity selection.
- Multiple people may use the same physical PC only by signing in to their separate Windows accounts.
- Production private Ed25519 identity material is protected with Windows DPAPI.
- Existing legacy private PEM identity material encountered in production is migrated to DPAPI storage and the legacy private PEM is removed.
- Separate development entry point (`app_dev.py` / `Run-Development.bat`) preserves multi-profile testing.
- Added `super_administrator`, `administrator`, and `user` production roles.
- Production administrative roles are cryptographically signed by a dedicated environment authority key instead of trusted from editable profile JSON.
- The Super Administrator can send signed Administrator grants and revocations through both relays. These controls are immediate-only and are not queued.
- Added signed environment invitation format for onboarding another Windows user into the same administrative trust environment.
- Added Role Administration UI for the Super Administrator.
- Added Windows production build script using PyInstaller.
- Added Inno Setup installer definition for a normal `Base36Chat-Setup.exe`.

## Security boundary

A Windows administrator is not automatically a Base36 administrator. A Base36 Super Administrator cannot open another Windows user's Base36 identity, obtain that user's private key, or decrypt that user's messages.

The SID/DPAPI layer assumes the Windows account itself is trustworthy. If another person is using Joel's already-unlocked `Joel.Hall` Windows session, Windows reports Joel's SID; Base36 cannot determine which human is physically at the keyboard. The operational rule remains: a borrower must sign out/switch user and sign in to their own Windows account before launching Base36 Chat.

## Important packaging note

This archive is an **update layer**, not the complete repository. The files supplied in the conversation did not include `identity.py`, `session.py`, `client.py`, `auth.py`, `replay.py`, or `security_admin.py`. `build_windows.bat` deliberately checks for them and refuses to pretend it can create a complete EXE until this update is copied into the full current source tree.

The new production-foundation unit tests pass in the build environment. Windows DPAPI and final PyInstaller/Inno Setup execution must be tested on Windows because the current build environment is Linux.
