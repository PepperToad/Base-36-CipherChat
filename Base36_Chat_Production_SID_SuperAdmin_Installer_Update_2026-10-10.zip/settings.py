import json
from pathlib import Path


SETTINGS_VERSION = 1

DEFAULT_SETTINGS = {
    "appearance": "light",
    "font_size": 10,
    "density": "comfortable",
    "enter_to_send": True,
    "emoji_shortcuts": True,
    "sound_enabled": True,
    "security_sound_enabled": True,
    "notification_mode": "generic",
}


class SettingsStore:
    """Local-only UI preferences. Never contains message content."""

    def __init__(self, owner_id, directory=None):
        self.owner_id = str(owner_id).strip().lower()
        directory = Path(directory) if directory is not None else Path(__file__).parent
        self.path = directory / f"settings_{self.owner_id}.json"
        self.values = dict(DEFAULT_SETTINGS)
        self.load()

    def load(self):
        self.values = dict(DEFAULT_SETTINGS)
        if not self.path.exists():
            return dict(self.values)

        try:
            document = json.loads(self.path.read_text(encoding="utf-8"))
        except Exception:
            # A corrupt preference file should not block secure messaging.
            return dict(self.values)

        if not isinstance(document, dict):
            return dict(self.values)

        saved = document.get("settings", {})
        if isinstance(saved, dict):
            for key in DEFAULT_SETTINGS:
                if key in saved:
                    self.values[key] = saved[key]

        self._normalize()
        return dict(self.values)

    def _normalize(self):
        appearance = self.values.get("appearance")
        if appearance not in ("light", "dark"):
            self.values["appearance"] = DEFAULT_SETTINGS["appearance"]

        density = self.values.get("density")
        if density not in ("compact", "comfortable"):
            self.values["density"] = DEFAULT_SETTINGS["density"]

        notification_mode = self.values.get("notification_mode")
        if notification_mode not in ("off", "generic", "name"):
            self.values["notification_mode"] = DEFAULT_SETTINGS["notification_mode"]

        try:
            font_size = int(self.values.get("font_size", 10))
        except (TypeError, ValueError):
            font_size = 10
        self.values["font_size"] = min(18, max(8, font_size))

        for key in (
            "enter_to_send",
            "emoji_shortcuts",
            "sound_enabled",
            "security_sound_enabled",
        ):
            self.values[key] = bool(self.values.get(key, DEFAULT_SETTINGS[key]))

    def save(self):
        self._normalize()
        document = {
            "version": SETTINGS_VERSION,
            "settings": self.values,
        }
        temp = self.path.with_suffix(".tmp")
        temp.write_text(
            json.dumps(document, indent=2, sort_keys=True),
            encoding="utf-8",
        )
        temp.replace(self.path)

    def get(self, key, default=None):
        return self.values.get(key, default)

    def update(self, **changes):
        for key, value in changes.items():
            if key in DEFAULT_SETTINGS:
                self.values[key] = value
        self._normalize()
        self.save()
        return dict(self.values)
