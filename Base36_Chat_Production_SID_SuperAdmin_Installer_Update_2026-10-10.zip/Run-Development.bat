@echo off
cd /d "%~dp0"
python app_dev.py
