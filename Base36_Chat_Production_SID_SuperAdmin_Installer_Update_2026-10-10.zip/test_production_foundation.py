import json
import os
import tempfile
import unittest
from pathlib import Path
from unittest import mock

os.environ["BASE36_DEV_MODE"] = "1"

from deployment import initialize_runtime, ProductionBinding
initialize_runtime(force_development=True)

from authority import (
    AuthorityStore,
    ROLE_ADMIN,
    ROLE_USER,
    ROLE_SUPER_ADMIN,
)


def protect_for_test(data: bytes) -> bytes:
    return b"TEST:" + bytes(data)


def unprotect_for_test(data: bytes) -> bytes:
    if not data.startswith(b"TEST:"):
        raise ValueError("bad test protection")
    return data[5:]


class BindingTests(unittest.TestCase):
    def test_binding_rejects_wrong_windows_sid(self):
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "binding.json"
            binding = ProductionBinding(path)
            with mock.patch("deployment.current_windows_sid", return_value="S-1-5-21-JOEL"):
                binding.bind("joel-id")
                self.assertEqual(binding.require_current_user()["user_id"], "joel-id")

            with mock.patch("deployment.current_windows_sid", return_value="S-1-5-21-JAMES"):
                with self.assertRaises(PermissionError):
                    binding.require_current_user()

    def test_binding_cannot_silently_rebind(self):
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "binding.json"
            binding = ProductionBinding(path)
            with mock.patch("deployment.current_windows_sid", return_value="S-1-5-21-ONE"):
                binding.bind("first-id")
                with self.assertRaises(FileExistsError):
                    binding.bind("second-id")


class AuthorityTests(unittest.TestCase):
    def make_store(self, owner, directory):
        return AuthorityStore(
            owner,
            directory=directory,
            protector=protect_for_test,
            unprotector=unprotect_for_test,
        )

    def test_superadmin_environment_and_join(self):
        with tempfile.TemporaryDirectory() as root:
            super_dir = Path(root) / "super"
            user_dir = Path(root) / "user"
            super_store = self.make_store("super-user", super_dir)
            super_store.create_environment()
            self.assertEqual(super_store.role_for_owner(), ROLE_SUPER_ADMIN)

            invite = super_store.export_environment_invitation()
            joined = self.make_store("ordinary-user", user_dir)
            joined.import_environment_invitation(invite)
            self.assertEqual(joined.role_for_owner(), ROLE_USER)
            self.assertFalse(joined.is_super_admin())

    def test_admin_grant_and_revoke_use_monotonic_sequence(self):
        with tempfile.TemporaryDirectory() as root:
            super_dir = Path(root) / "super"
            user_dir = Path(root) / "user"
            super_store = self.make_store("super-user", super_dir)
            super_store.create_environment()

            user_store = self.make_store("target-user", user_dir)
            user_store.import_environment_invitation(
                super_store.export_environment_invitation()
            )

            grant = super_store.issue_role_token("target-user", ROLE_ADMIN)
            grant_body = user_store.apply_role_token(grant)
            self.assertEqual(grant_body["role"], ROLE_ADMIN)
            self.assertEqual(user_store.role_for_owner(), ROLE_ADMIN)

            revoke = super_store.issue_role_token("target-user", ROLE_USER)
            revoke_body = user_store.apply_role_token(revoke)
            self.assertGreater(revoke_body["sequence"], grant_body["sequence"])
            self.assertEqual(user_store.role_for_owner(), ROLE_USER)

            # Replaying the old admin grant cannot undo the newer revocation.
            user_store.apply_role_token(grant)
            self.assertEqual(user_store.role_for_owner(), ROLE_USER)

    def test_role_statement_cannot_be_applied_to_other_user(self):
        with tempfile.TemporaryDirectory() as root:
            super_store = self.make_store("super-user", Path(root) / "super")
            super_store.create_environment()
            invite = super_store.export_environment_invitation()

            james = self.make_store("james", Path(root) / "james")
            james.import_environment_invitation(invite)
            token = super_store.issue_role_token("steve", ROLE_ADMIN)

            with self.assertRaises(ValueError):
                james.apply_role_token(token)

    def test_tampered_role_signature_is_rejected(self):
        with tempfile.TemporaryDirectory() as root:
            super_store = self.make_store("super-user", Path(root) / "super")
            super_store.create_environment()
            invite = super_store.export_environment_invitation()
            target = self.make_store("target", Path(root) / "target")
            target.import_environment_invitation(invite)

            token = super_store.issue_role_token("target", ROLE_ADMIN)
            # Flip the final URL-safe base64 character while keeping token form.
            replacement = "A" if token[-1] != "A" else "B"
            tampered = token[:-1] + replacement
            with self.assertRaises(ValueError):
                target.apply_role_token(tampered)


if __name__ == "__main__":
    unittest.main(verbosity=2)
