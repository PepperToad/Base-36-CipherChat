# Base36 Cipher Chat — No-Queue Relay Deployment

## This update changes the relay contract

The updated client requires **Relay Protocol 2** and explicitly requires `queue_mode = "none"`. It will refuse to operate with an older relay that stores undelivered packet payloads in a RAM queue.

Update **both** relay instances before using the updated GUI. This is intentional: the client must not silently fall back to store-and-forward behavior.

## Relay behavior

The new `relay.py` accepts a connected client ID, forwards an opaque message immediately to an already-connected recipient, and rejects the message if the recipient is offline. There is no offline mailbox and no message-payload queue.

After successful forwarding, the relay temporarily stores only receipt metadata: message ID, sender routing ID, recipient routing ID, and creation time. The recipient's ACK deletes that metadata and produces a `delivered` receipt to the sender. Metadata also expires automatically.

The relay has packet-size limits, malformed-packet checks, duplicate connected-ID rejection, bounded inflight receipt metadata, and a simple per-connection rate limit.

## Current VM ports

The client defaults remain:

```text
Relay A: ws://34.10.22.176:80
Relay B: ws://34.10.22.176:443
```

Example direct starts on the VM are:

```bash
python3 relay.py --host 0.0.0.0 --port 80 --name "Relay A"
python3 relay.py --host 0.0.0.0 --port 443 --name "Relay B"
```

Linux normally restricts ports below 1024, so your service account may require an appropriate systemd/service capability, privilege arrangement, or reverse-proxy configuration. Do not run a broader privileged environment merely for convenience.

Port `443` by itself does **not** make the connection TLS. The current client URI is still `ws://...:443`. If TLS is later added, terminate/configure it deliberately and change the client to authenticated `wss://` endpoints.

## Firewall

Only the intended relay ports should be exposed. Administrative access to the VM should remain separately controlled. The relay does not need database access and should not be granted it.

## Logging

Production relay logging should remain minimal. Do not log payloads, ciphertext, public-key packets, contact requests, message IDs, or routing histories. The supplied relay prints only its startup/listening line during normal operation.

## Deployment check

After replacing the relays, launch a client. The bottom status should reach:

```text
Both relays connected • no-queue mode
```

If the client repeatedly reports that a relay does not advertise no-queue mode or has an incompatible protocol version, one of the old relay processes is still running.
