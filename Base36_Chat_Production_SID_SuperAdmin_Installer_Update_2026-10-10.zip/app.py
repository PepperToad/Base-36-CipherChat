import argparse
import asyncio
import ctypes
import queue
import threading
import tkinter as tk
from datetime import datetime
from tkinter import filedialog, messagebox, simpledialog, ttk

from deployment import initialize_runtime, runtime, ProductionBinding

# app_dev.py sets BASE36_DEV_MODE before importing this module. A frozen
# production EXE ignores that switch and always uses SID-bound production mode.
initialize_runtime()

from authority import AuthorityStore, ROLE_USER, ROLE_ADMIN, ROLE_SUPER_ADMIN
from engine import ChatEngine, MAX_MESSAGE_UTF8_BYTES
from profiles import ProfileStore, normalize_profile_id
from settings import SettingsStore


QUICK_EMOJIS = (
    "☕", "😀", "😄", "😂", "😉", "👍",
    "❤️", "🔥", "🎉", "✅", "😛", "🙁",
)

EMOJI_SHORTCUTS = {
    ":coffee:": "☕",
    "<3": "❤️",
    ":)": "🙂",
    ":(": "🙁",
    ";)": "😉",
    ":D": "😄",
    ":P": "😛",
}


def expand_emoji_shortcuts(text):
    """Expand only the small, explicit shortcut set; text remains case-sensitive."""
    for token in sorted(EMOJI_SHORTCUTS, key=len, reverse=True):
        text = text.replace(token, EMOJI_SHORTCUTS[token])
    return text


class AsyncLoopThread:
    def __init__(self, event_queue):
        self.event_queue = event_queue
        self.loop = asyncio.new_event_loop()
        self.thread = threading.Thread(
            target=self._run,
            name="Base36AsyncLoop",
            daemon=True,
        )
        self.thread.start()

    def _run(self):
        asyncio.set_event_loop(self.loop)
        self.loop.run_forever()

    def submit(self, coro):
        future = asyncio.run_coroutine_threadsafe(coro, self.loop)

        def done_callback(done):
            try:
                done.result()
            except Exception as exc:
                self.event_queue.put({
                    "type": "error",
                    "message": str(exc),
                })

        future.add_done_callback(done_callback)
        return future

    def shutdown(self, engine):
        try:
            future = asyncio.run_coroutine_threadsafe(engine.stop(), self.loop)
            future.result(timeout=3)
        except Exception:
            pass
        self.loop.call_soon_threadsafe(self.loop.stop)


class ChatApp(tk.Tk):
    def __init__(self, client_id, display_name=None, role="user"):
        super().__init__()

        self.client_id = client_id
        self.display_name = display_name or client_id.replace("_", " ").title()
        self.settings_store = SettingsStore(
            client_id,
            directory=(runtime().data_dir if runtime().production else None),
        )
        self.settings = dict(self.settings_store.values)
        self.reopen_chooser = False

        self.title(f"Base36 Chat — {self.display_name}")
        self.geometry("1060x700")
        self.minsize(820, 560)

        self.events = queue.Queue()
        self.bridge = AsyncLoopThread(self.events)
        self.engine = ChatEngine(client_id, event_sink=self.events.put)

        self.selected_peer = None
        self.contacts = {}
        self.contact_order = []
        self.histories = {}
        self.message_status = {}
        self.identity_fingerprint = ""
        self.relay_state = {"Relay A": False, "Relay B": False}
        self.session_state = {}
        self.user_role = role or "user"
        self.admin_window = None
        self.role_admin_window = None
        self.emoji_window = None
        self.settings_window = None
        self.invite_window = None
        self.unread_counts = {}
        self.emoji_recents = []
        self.reply_context = None
        self.rendered_message_tags = {}
        self.relay_reconnecting = {"Relay A": False, "Relay B": False}

        self._configure_style()
        self._build_ui()
        self.protocol("WM_DELETE_WINDOW", self._on_close)

        self.after(75, self._drain_events)
        self.bridge.submit(self.engine.start())

    def _configure_style(self):
        style = ttk.Style(self)
        try:
            style.theme_use("vista")
        except tk.TclError:
            pass

        font_size = int(self.settings.get("font_size", 10))
        style.configure("Sidebar.TFrame", padding=0)
        style.configure("Header.TLabel", font=("Segoe UI", font_size + 6, "bold"))
        style.configure("Subtle.TLabel", foreground="#666666")
        style.configure("Secure.TLabel", foreground="#177245", font=("Segoe UI", max(8, font_size - 1), "bold"))
        style.configure("Warn.TLabel", foreground="#9A6700", font=("Segoe UI", max(8, font_size - 1), "bold"))
        style.configure("Danger.TLabel", foreground="#B42318", font=("Segoe UI", max(8, font_size - 1), "bold"))
        style.configure("Small.TLabel", font=("Segoe UI", max(8, font_size - 2)))

    def _apply_appearance(self):
        font_size = int(self.settings.get("font_size", 10))
        dark = self.settings.get("appearance") == "dark"
        density = self.settings.get("density", "comfortable")

        if dark:
            bg = "#1f2329"
            field = "#15181d"
            fg = "#f0f2f5"
            muted = "#a9b0ba"
            select_bg = "#334155"
        else:
            bg = "#f7f7f7"
            field = "#ffffff"
            fg = "#111111"
            muted = "#666666"
            select_bg = "#dbeafe"

        try:
            self.configure(bg=bg)
        except tk.TclError:
            pass

        # ttk follows the selected theme rather than Tk widget colors. Use
        # clam for dark mode because native Vista controls ignore many custom
        # background settings; switch back to Vista when returning to light.
        style = ttk.Style(self)
        try:
            if dark:
                style.theme_use("clam")
            else:
                style.theme_use("vista")
        except tk.TclError:
            pass

        style.configure("TFrame", background=bg)
        style.configure("Sidebar.TFrame", background=bg)
        style.configure("TLabel", background=bg, foreground=fg)
        style.configure("Header.TLabel", background=bg, foreground=fg)
        style.configure("Subtle.TLabel", background=bg, foreground=muted)
        style.configure("Small.TLabel", background=bg, foreground=muted)
        style.configure("Secure.TLabel", background=bg)
        style.configure("Warn.TLabel", background=bg)
        style.configure("Danger.TLabel", background=bg)
        style.configure("TCheckbutton", background=bg, foreground=fg)
        style.configure("TButton", padding=5)
        if dark:
            style.configure("TButton", background="#2b3139", foreground=fg)
            style.map(
                "TButton",
                background=[("active", "#3a4350"), ("pressed", "#111418")],
                foreground=[("disabled", muted)],
            )
            style.configure(
                "TCombobox",
                fieldbackground=field,
                background="#2b3139",
                foreground=fg,
                arrowcolor=fg,
            )
        else:
            style.configure("TButton", foreground="#111111")

        for widget in (getattr(self, "contact_list", None),):
            if widget is not None:
                widget.configure(
                    bg=field,
                    fg=fg,
                    selectbackground=select_bg,
                    selectforeground=fg,
                    font=("Segoe UI", font_size),
                )

        for widget in (
            getattr(self, "conversation", None),
            getattr(self, "message_entry", None),
        ):
            if widget is not None:
                widget.configure(
                    bg=field,
                    fg=fg,
                    insertbackground=fg,
                    selectbackground=select_bg,
                    selectforeground=fg,
                    font=("Segoe UI", font_size),
                )

        if getattr(self, "conversation", None) is not None:
            self.conversation.tag_configure("meta", foreground=muted, font=("Segoe UI", max(8, font_size - 2)))
            self.conversation.tag_configure("meta_right", foreground=muted, font=("Segoe UI", max(8, font_size - 2)))
            self.conversation.tag_configure("incoming_name", font=("Segoe UI", max(8, font_size - 1), "bold"))
            self.conversation.tag_configure("outgoing_name", font=("Segoe UI", max(8, font_size - 1), "bold"))
            self.conversation.tag_configure("system", foreground=muted, font=("Segoe UI", max(8, font_size - 1), "italic"))

        if getattr(self, "message_entry", None) is not None:
            if density == "compact":
                self.message_entry.configure(padx=5, pady=3)
            else:
                self.message_entry.configure(padx=8, pady=6)

    def _build_ui(self):
        self.columnconfigure(1, weight=1)
        self.rowconfigure(0, weight=1)

        # ---------------- Sidebar ----------------
        sidebar = ttk.Frame(self, style="Sidebar.TFrame", padding=(12, 12))
        sidebar.grid(row=0, column=0, sticky="nsew")
        sidebar.rowconfigure(3, weight=1)

        ttk.Label(sidebar, text="Base36 Chat", style="Header.TLabel").grid(
            row=0, column=0, columnspan=3, sticky="w"
        )
        self.identity_label = ttk.Label(
            sidebar,
            text=f"{self.display_name} • loading identity…",
            style="Subtle.TLabel",
        )
        self.identity_label.grid(row=1, column=0, columnspan=3, sticky="w", pady=(2, 12))

        ttk.Label(sidebar, text="Contacts").grid(row=2, column=0, sticky="w")

        self.contact_list = tk.Listbox(
            sidebar,
            width=30,
            activestyle="none",
            exportselection=False,
            borderwidth=0,
            highlightthickness=1,
            font=("Segoe UI", 10),
        )
        self.contact_list.grid(row=3, column=0, columnspan=3, sticky="nsew", pady=(6, 10))
        self.contact_list.bind("<<ListboxSelect>>", self._on_contact_selected)
        self.contact_list.bind("<Button-3>", self._contact_context_menu)

        ttk.Button(sidebar, text="Add Contact", command=self._add_contact).grid(
            row=4, column=0, sticky="ew", padx=(0, 3)
        )
        ttk.Button(
            sidebar,
            text="Paste Invite",
            command=self._import_invitation_from_clipboard,
        ).grid(row=4, column=1, sticky="ew", padx=3)
        ttk.Button(sidebar, text="My Invite", command=self._show_my_invitation).grid(
            row=4, column=2, sticky="ew", padx=(3, 0)
        )

        ttk.Button(sidebar, text="Contact Details", command=self._show_contact_details).grid(
            row=5, column=0, columnspan=3, sticky="ew", pady=(8, 0)
        )
        ttk.Button(sidebar, text="Settings", command=self._open_settings).grid(
            row=6, column=0, columnspan=3, sticky="ew", pady=(8, 0)
        )
        ttk.Button(sidebar, text="Emergency Lock", command=self._emergency_lock).grid(
            row=7, column=0, columnspan=3, sticky="ew", pady=(8, 0)
        )

        self.admin_button = ttk.Button(
            sidebar, text="Security Admin", command=self._open_admin_panel
        )
        self.admin_button.grid(
            row=8, column=0, columnspan=3, sticky="ew", pady=(8, 0)
        )
        self.role_admin_button = ttk.Button(
            sidebar, text="Role Administration", command=self._open_role_admin_panel
        )
        self.role_admin_button.grid(
            row=9, column=0, columnspan=3, sticky="ew", pady=(8, 0)
        )
        if self.user_role not in (ROLE_ADMIN, ROLE_SUPER_ADMIN):
            self.admin_button.grid_remove()
        if self.user_role != ROLE_SUPER_ADMIN:
            self.role_admin_button.grid_remove()

        # ---------------- Main conversation ----------------
        main = ttk.Frame(self, padding=(14, 12))
        main.grid(row=0, column=1, sticky="nsew")
        main.columnconfigure(0, weight=1)
        main.rowconfigure(1, weight=1)

        header = ttk.Frame(main)
        header.grid(row=0, column=0, sticky="ew", pady=(0, 10))
        header.columnconfigure(0, weight=1)

        self.peer_label = ttk.Label(header, text="Select a contact", style="Header.TLabel")
        self.peer_label.grid(row=0, column=0, sticky="w")

        self.security_label = ttk.Label(header, text="", style="Subtle.TLabel")
        self.security_label.grid(row=1, column=0, sticky="w", pady=(2, 0))

        conversation_frame = ttk.Frame(main)
        conversation_frame.grid(row=1, column=0, sticky="nsew")
        conversation_frame.rowconfigure(0, weight=1)
        conversation_frame.columnconfigure(0, weight=1)

        self.conversation = tk.Text(
            conversation_frame,
            wrap="word",
            state="disabled",
            borderwidth=0,
            highlightthickness=1,
            padx=14,
            pady=12,
            font=("Segoe UI", 10),
        )
        self.conversation.grid(row=0, column=0, sticky="nsew")
        self.conversation.bind("<Button-3>", self._message_context_menu)

        scrollbar = ttk.Scrollbar(
            conversation_frame,
            orient="vertical",
            command=self.conversation.yview,
        )
        scrollbar.grid(row=0, column=1, sticky="ns")
        self.conversation.configure(yscrollcommand=scrollbar.set)

        self.conversation.tag_configure(
            "incoming_name", font=("Segoe UI", 9, "bold"), spacing1=10
        )
        self.conversation.tag_configure(
            "incoming", lmargin1=8, lmargin2=8, rmargin=120, spacing3=4
        )
        self.conversation.tag_configure(
            "outgoing_name", justify="right", font=("Segoe UI", 9, "bold"), spacing1=10
        )
        self.conversation.tag_configure(
            "outgoing", justify="right", lmargin1=120, lmargin2=120, rmargin=8, spacing3=4
        )
        self.conversation.tag_configure(
            "meta", foreground="#777777", font=("Segoe UI", 8), spacing3=6
        )
        self.conversation.tag_configure(
            "meta_right", foreground="#777777", font=("Segoe UI", 8), justify="right", spacing3=6
        )
        self.conversation.tag_configure(
            "system", foreground="#666666", justify="center", font=("Segoe UI", 9, "italic"), spacing1=8, spacing3=8
        )

        composer = ttk.Frame(main)
        composer.grid(row=2, column=0, sticky="ew", pady=(10, 0))
        composer.columnconfigure(0, weight=1)

        self.reply_frame = ttk.Frame(composer)
        self.reply_frame.grid(row=0, column=0, columnspan=3, sticky="ew", pady=(0, 5))
        self.reply_frame.columnconfigure(0, weight=1)
        self.reply_label = ttk.Label(self.reply_frame, text="", style="Subtle.TLabel")
        self.reply_label.grid(row=0, column=0, sticky="w")
        ttk.Button(self.reply_frame, text="×", width=3, command=self._clear_reply).grid(
            row=0, column=1, sticky="e"
        )
        self.reply_frame.grid_remove()

        self.message_entry = tk.Text(
            composer,
            height=3,
            wrap="word",
            font=("Segoe UI", int(self.settings.get("font_size", 10))),
            padx=8,
            pady=6,
            undo=False,
            maxundo=0,
        )
        self.message_entry.grid(row=1, column=0, sticky="ew", padx=(0, 8))
        self.message_entry.bind("<Return>", self._entry_return)
        self.message_entry.bind("<Control-Return>", self._entry_ctrl_return)
        self.message_entry.bind("<<Modified>>", self._composer_modified)

        self.emoji_button = ttk.Button(
            composer, text="☕", width=3, command=self._show_emoji_picker
        )
        self.emoji_button.grid(row=1, column=1, sticky="ns", padx=(0, 8))

        self.send_button = ttk.Button(composer, text="Send", command=self._send)
        self.send_button.grid(row=1, column=2, sticky="ns")

        self.composer_info = ttk.Label(composer, text="", style="Small.TLabel")
        self.composer_info.grid(row=2, column=0, columnspan=3, sticky="e", pady=(3, 0))

        status = ttk.Frame(main)
        status.grid(row=3, column=0, sticky="ew", pady=(8, 0))
        status.columnconfigure(1, weight=1)

        self.relay_label = ttk.Label(status, text="Relay A: ○   Relay B: ○", style="Subtle.TLabel")
        self.relay_label.grid(row=0, column=0, sticky="w")
        self.status_label = ttk.Label(status, text="Starting…", style="Subtle.TLabel")
        self.status_label.grid(row=0, column=1, sticky="e")

        self.bind_all("<Control-f>", lambda _e: self._find_in_conversation())
        self.bind_all("<Control-k>", lambda _e: self._contact_switcher())
        self.bind_all("<Control-comma>", lambda _e: self._open_settings())
        self.bind_all("<Control-Shift-L>", lambda _e: self._emergency_lock())
        self.bind_all("<Escape>", lambda _e: self._clear_reply())

        self._apply_appearance()
        self._set_composer_enabled(False)

    def _set_composer_enabled(self, enabled):
        state = "normal" if enabled else "disabled"
        self.message_entry.configure(state=state)
        self.emoji_button.configure(state=state)
        self.send_button.configure(state=state)

    def _entry_return(self, event):
        if not self.settings.get("enter_to_send", True):
            return None
        if event.state & 0x0001:  # Shift+Enter = newline
            return None
        self._send()
        return "break"

    def _entry_ctrl_return(self, _event):
        if not self.settings.get("enter_to_send", True):
            self._send()
            return "break"
        return None

    def _composer_modified(self, _event=None):
        try:
            if not self.message_entry.edit_modified():
                return
            self.message_entry.edit_modified(False)
            text = self.message_entry.get("1.0", "end-1c")
            lines = max(1, min(6, text.count("\n") + 1))
            self.message_entry.configure(height=max(2, lines))
            used = len(text.encode("utf-8"))
            if used >= int(MAX_MESSAGE_UTF8_BYTES * 0.75):
                self.composer_info.configure(
                    text=f"{used:,} / {MAX_MESSAGE_UTF8_BYTES:,} UTF-8 bytes"
                )
            else:
                self.composer_info.configure(text="")
        except tk.TclError:
            pass

    def _send(self):
        if not self.selected_peer:
            return

        text = self.message_entry.get("1.0", "end-1c")
        if not text.strip():
            return

        if self.settings.get("emoji_shortcuts", True):
            text = expand_emoji_shortcuts(text)

        if self.reply_context:
            quoted = self.reply_context.get("text", "").replace("\n", " ").strip()
            if len(quoted) > 180:
                quoted = quoted[:177] + "…"
            author = self.reply_context.get("author", "Message")
            text = f"↪ {author}: {quoted}\n{text}"

        # Deliberately clear the composer before handing the text to the async
        # engine. A failed send is not restored or queued.
        self.message_entry.delete("1.0", "end")
        self._clear_reply()
        self.bridge.submit(self.engine.send_message(self.selected_peer, text))

    def _show_emoji_picker(self):
        if self.emoji_window is not None and self.emoji_window.winfo_exists():
            self.emoji_window.destroy()

        win = tk.Toplevel(self)
        self.emoji_window = win
        win.title("Emoji")
        win.transient(self)
        win.resizable(False, False)

        frame = ttk.Frame(win, padding=8)
        frame.grid(row=0, column=0, sticky="nsew")

        emojis = ["☕"]
        for emoji in self.emoji_recents:
            if emoji not in emojis:
                emojis.append(emoji)
        for emoji in QUICK_EMOJIS:
            if emoji not in emojis:
                emojis.append(emoji)
        emojis = emojis[:18]

        for index, emoji in enumerate(emojis):
            row, column = divmod(index, 6)
            ttk.Button(
                frame,
                text=emoji,
                width=3,
                command=lambda value=emoji: self._insert_emoji(value),
            ).grid(row=row, column=column, padx=2, pady=2)

        ttk.Label(
            frame,
            text="Shortcuts: :coffee:  :)  :(  ;)  :D  :P  <3",
            style="Subtle.TLabel",
        ).grid(row=3, column=0, columnspan=6, sticky="w", pady=(6, 0))

        win.bind("<Escape>", lambda _event: win.destroy())

    def _insert_emoji(self, emoji):
        try:
            if str(self.message_entry.cget("state")) == "disabled":
                return
            self.message_entry.insert("insert", emoji)
            if emoji != "☕":
                self.emoji_recents = [emoji] + [
                    item for item in self.emoji_recents if item != emoji
                ]
                self.emoji_recents = self.emoji_recents[:8]
            self.message_entry.focus_set()
        except tk.TclError:
            pass

    def _clear_reply(self):
        self.reply_context = None
        if hasattr(self, "reply_frame"):
            self.reply_frame.grid_remove()
        return "break"

    def _begin_reply(self, item):
        if not item or item.get("direction") == "system":
            return
        if item.get("direction") == "incoming":
            author = self._base_contact_label(self.selected_peer)
        else:
            author = "You"
        self.reply_context = {
            "author": author,
            "text": item.get("plaintext", ""),
        }
        preview = self.reply_context["text"].replace("\n", " ").strip()
        if len(preview) > 90:
            preview = preview[:87] + "…"
        self.reply_label.configure(text=f"Replying to {author}: {preview}")
        self.reply_frame.grid()
        self.message_entry.focus_set()

    def _base_contact_label(self, peer):
        entry = self.contacts.get(peer, {})
        return (
            entry.get("local_alias")
            or entry.get("display_name")
            or peer
        )

    def _initials(self, label):
        parts = [part for part in str(label).replace("-", " ").split() if part]
        if not parts:
            return "?"
        if len(parts) == 1:
            return parts[0][:2].upper()
        return (parts[0][0] + parts[1][0]).upper()

    def _contact_label(self, peer, disambiguate=False):
        label = self._base_contact_label(peer)
        if not disambiguate:
            return label

        matches = sum(
            1
            for other_peer in self.contacts
            if self._base_contact_label(other_peer).casefold() == label.casefold()
        )
        if matches > 1:
            suffix = peer[-4:].upper() if len(peer) > 4 else peer.upper()
            return f"{label} • {suffix}"
        return label

    def _on_contact_selected(self, _event=None):
        selection = self.contact_list.curselection()
        if not selection:
            return

        index = selection[0]
        if index >= len(self.contact_order):
            return

        self.selected_peer = self.contact_order[index]
        self.unread_counts[self.selected_peer] = 0
        self._refresh_contacts(list(self.contacts.values()))
        self._render_selected_peer()
        self._render_history()
        self.bridge.submit(self.engine.ensure_session(self.selected_peer))

    def _render_selected_peer(self):
        peer = self.selected_peer
        if not peer:
            self.peer_label.configure(text="Select a contact")
            self.security_label.configure(text="", style="Subtle.TLabel")
            self._set_composer_enabled(False)
            return

        entry = self.contacts.get(peer, {})
        trusted = entry.get("trusted", False)
        status = entry.get("status")
        session = self.session_state.get(peer)
        label = self._base_contact_label(peer)
        remote_name = entry.get("display_name") or peer
        short_id = peer[-4:].upper() if len(peer) > 4 else peer.upper()

        self.peer_label.configure(text=label)

        if entry.get("local_alias") and remote_name != label:
            identity_hint = f"{remote_name} • ID …{short_id} • "
        else:
            identity_hint = f"ID …{short_id} • "

        if status == "locked_key_change":
            self.security_label.configure(
                text=identity_hint + "⚠ IDENTITY KEY CHANGED — secure messaging suspended; administrator required",
                style="Danger.TLabel",
            )
            self._set_composer_enabled(False)
        elif status == "revoked":
            self.security_label.configure(
                text=identity_hint + "✖ Identity revoked — secure messaging disabled",
                style="Danger.TLabel",
            )
            self._set_composer_enabled(False)
        elif not trusted:
            self.security_label.configure(
                text=identity_hint + "Contact is not pinned for secure messaging",
                style="Warn.TLabel",
            )
            self._set_composer_enabled(False)
        elif session == "secure":
            self.security_label.configure(
                text=identity_hint + "● Secure session • identity verified",
                style="Secure.TLabel",
            )
            self._set_composer_enabled(True)
        elif session == "connecting":
            self.security_label.configure(
                text=identity_hint + "◐ Establishing secure session…",
                style="Warn.TLabel",
            )
            self._set_composer_enabled(False)
        else:
            self.security_label.configure(
                text=identity_hint + "✓ Trusted • preparing secure session…",
                style="Warn.TLabel",
            )
            self._set_composer_enabled(False)

    def _refresh_contacts(self, contacts):
        selected = self.selected_peer
        self.contacts = {entry["name"]: entry for entry in contacts}
        self.contact_order = []

        self.contact_list.delete(0, "end")
        selected_index = None

        for entry in contacts:
            peer = entry["name"]
            status = entry.get("status")
            if status == "locked_key_change":
                marker = "⚠"
            elif status == "revoked":
                marker = "✖"
            elif entry.get("session_active"):
                marker = "●"
            elif entry.get("trusted"):
                marker = "✓"
            else:
                marker = "○"

            index = len(self.contact_order)
            self.contact_order.append(peer)
            label = self._contact_label(peer, disambiguate=True)
            initials = self._initials(label)
            unread = int(self.unread_counts.get(peer, 0) or 0)
            unread_text = f"   ({unread})" if unread else ""
            self.contact_list.insert("end", f"{marker}  {initials}  {label}{unread_text}")
            if peer == selected:
                selected_index = index

        if selected and selected not in self.contacts:
            self.selected_peer = None

        if selected_index is not None:
            self.contact_list.selection_set(selected_index)
            self.contact_list.activate(selected_index)

        self._render_selected_peer()

    def _history_for(self, peer):
        return self.histories.setdefault(peer, [])

    def _add_history(self, peer, direction, plaintext, status="", local_id=None):
        record = {
            "direction": direction,
            "plaintext": plaintext,
            "status": status,
            "local_id": local_id,
            "time": datetime.now().strftime("%H:%M"),
        }
        self._history_for(peer).append(record)
        if local_id:
            self.message_status[local_id] = record
        if peer == self.selected_peer:
            self._render_history()

    def _update_message_status(self, local_id, status):
        record = self.message_status.get(local_id)
        if record is not None:
            record["status"] = status
            if self.selected_peer and record in self._history_for(self.selected_peer):
                self._render_history()

    def _add_system(self, peer, text):
        if not peer:
            return
        self._history_for(peer).append({
            "direction": "system",
            "plaintext": text,
            "status": "",
            "local_id": None,
            "time": datetime.now().strftime("%H:%M"),
        })
        if peer == self.selected_peer:
            self._render_history()

    def _render_history(self):
        self.conversation.configure(state="normal")
        self.conversation.delete("1.0", "end")
        self.rendered_message_tags = {}

        if not self.selected_peer:
            self.conversation.insert("end", "Select a contact to start chatting.\n", "system")
        else:
            for counter, item in enumerate(self._history_for(self.selected_peer)):
                direction = item["direction"]
                text = item["plaintext"]
                stamp = item["time"]
                tag = f"message_{counter}"
                self.rendered_message_tags[tag] = item

                if direction == "incoming":
                    self.conversation.insert(
                        "end",
                        f"{self._base_contact_label(self.selected_peer)}\n",
                        ("incoming_name", tag),
                    )
                    self.conversation.insert("end", f"{text}\n", ("incoming", tag))
                    self.conversation.insert("end", f"{stamp} • verified\n", ("meta", tag))

                elif direction == "outgoing":
                    self.conversation.insert("end", "You\n", ("outgoing_name", tag))
                    self.conversation.insert("end", f"{text}\n", ("outgoing", tag))
                    status = item.get("status") or "sent"
                    self.conversation.insert(
                        "end",
                        f"{stamp} • {status}\n",
                        ("meta_right", tag),
                    )

                else:
                    self.conversation.insert("end", f"{text}\n", ("system", tag))

        self.conversation.configure(state="disabled")
        self.conversation.see("end")

    def _purge_failed_message(self, local_id, reason):
        record = self.message_status.pop(local_id, None)
        if record is None:
            return
        peer = None
        for candidate_peer, items in self.histories.items():
            if record in items:
                items.remove(record)
                peer = candidate_peer
                break
        if peer:
            self._add_system(peer, reason or "Message not delivered — message was discarded.")
        if self.selected_peer == peer:
            self._render_history()

    def _add_contact(self):
        value = simpledialog.askstring(
            "Add contact",
            "Paste a permanent User ID or a B36C1 invitation code.\n\n"
            "Invitation codes can pin the shared identity directly without a directory.",
            parent=self,
        )
        if not value:
            return
        value = value.strip()
        if value.startswith("B36C1-"):
            self.bridge.submit(self.engine.import_invitation(value))
        else:
            self.bridge.submit(self.engine.request_contact(value))

    def _import_invitation_from_clipboard(self):
        try:
            value = self.clipboard_get().strip()
        except tk.TclError:
            messagebox.showinfo("Invitation", "Clipboard does not contain text.", parent=self)
            return
        if not value.startswith("B36C1-"):
            messagebox.showerror("Invitation", "Clipboard does not contain a Base36 Chat invitation.", parent=self)
            return
        self.bridge.submit(self.engine.import_invitation(value))

    def _show_my_invitation(self):
        self.bridge.submit(self.engine.create_invitation())

    def _display_invitation(self, event):
        code = event.get("code", "")
        if not code:
            return
        if self.invite_window is not None and self.invite_window.winfo_exists():
            self.invite_window.destroy()

        win = tk.Toplevel(self)
        self.invite_window = win
        win.title("My Base36 Chat Invitation")
        win.transient(self)
        win.resizable(False, False)
        frame = ttk.Frame(win, padding=14)
        frame.grid(row=0, column=0, sticky="nsew")

        ttk.Label(
            frame,
            text=f"{event.get('display_name') or self.display_name}\nUser ID: {event.get('user_id') or self.client_id}",
            justify="left",
        ).grid(row=0, column=0, columnspan=3, sticky="w")

        qr_label = ttk.Label(frame)
        qr_label.grid(row=1, column=0, columnspan=3, pady=(10, 8))
        try:
            import qrcode
            from PIL import Image, ImageTk
            qr = qrcode.make(code)
            image = qr.get_image() if hasattr(qr, "get_image") else qr
            resampling = getattr(Image, "Resampling", Image)
            image = image.resize((260, 260), resample=resampling.NEAREST)
            photo = ImageTk.PhotoImage(image)
            qr_label.configure(image=photo)
            qr_label.image = photo
            win._invite_qr_image = image
        except Exception:
            qr_label.configure(text="QR support unavailable; use the invitation code below.")

        code_box = tk.Text(frame, width=64, height=5, wrap="word")
        code_box.grid(row=2, column=0, columnspan=3, sticky="ew")
        code_box.insert("1.0", code)
        code_box.configure(state="disabled")

        def copy_code():
            self.clipboard_clear()
            self.clipboard_append(code)
            self.update()

        def save_qr():
            image = getattr(win, "_invite_qr_image", None)
            if image is None:
                messagebox.showerror("QR", "QR image is unavailable.", parent=win)
                return
            path = filedialog.asksaveasfilename(
                parent=win,
                title="Save invitation QR",
                defaultextension=".png",
                filetypes=[("PNG image", "*.png")],
            )
            if path:
                image.save(path)

        ttk.Button(frame, text="Copy Code", command=copy_code).grid(row=3, column=0, sticky="ew", pady=(8, 0), padx=(0, 4))
        ttk.Button(frame, text="Save QR", command=save_qr).grid(row=3, column=1, sticky="ew", pady=(8, 0), padx=4)
        ttk.Button(frame, text="Close", command=win.destroy).grid(row=3, column=2, sticky="ew", pady=(8, 0), padx=(4, 0))

    def _show_contact_details(self):
        peer = self.selected_peer
        if not peer:
            return
        entry = self.contacts.get(peer, {})
        label = self._base_contact_label(peer)
        lines = [
            f"Local label: {label}",
            f"Display name: {entry.get('display_name') or peer}",
            f"User ID: {peer}",
            f"Status: {entry.get('status') or 'unknown'}",
            f"Fingerprint:\n{entry.get('fingerprint') or ''}",
        ]
        if entry.get("session_id"):
            lines.append(f"Session ID: {entry['session_id']}")
        messagebox.showinfo("Contact Identity", "\n\n".join(lines), parent=self)

    def _copy_selected_contact_id(self):
        if self.selected_peer:
            self._copy_text(self.selected_peer)

    def _copy_selected_fingerprint(self):
        if self.selected_peer:
            fp = self.contacts.get(self.selected_peer, {}).get("fingerprint")
            if fp:
                self._copy_text(fp)

    def _contact_context_menu(self, event):
        try:
            index = self.contact_list.nearest(event.y)
            if index < 0 or index >= len(self.contact_order):
                return
            self.contact_list.selection_clear(0, "end")
            self.contact_list.selection_set(index)
            self.contact_list.activate(index)
            self.selected_peer = self.contact_order[index]
            self.unread_counts[self.selected_peer] = 0
            self._render_selected_peer()
            self._render_history()
        except Exception:
            return

        menu = tk.Menu(self, tearoff=False)
        menu.add_command(label="Open", command=lambda: self.bridge.submit(self.engine.ensure_session(self.selected_peer)))
        menu.add_command(label="Rename local label", command=self._label_selected_contact)
        menu.add_command(label="View identity details", command=self._show_contact_details)
        menu.add_separator()
        menu.add_command(label="Copy User ID", command=self._copy_selected_contact_id)
        menu.add_command(label="Copy fingerprint", command=self._copy_selected_fingerprint)
        menu.add_separator()
        menu.add_command(label="Remove contact", command=self._remove_contact)
        menu.tk_popup(event.x_root, event.y_root)

    def _message_context_menu(self, event):
        try:
            index = self.conversation.index(f"@{event.x},{event.y}")
            tags = self.conversation.tag_names(index)
        except tk.TclError:
            return
        item = None
        for tag in tags:
            if tag.startswith("message_"):
                item = self.rendered_message_tags.get(tag)
                if item is not None:
                    break

        menu = tk.Menu(self, tearoff=False)
        if item and item.get("direction") != "system":
            menu.add_command(label="Reply", command=lambda record=item: self._begin_reply(record))
            menu.add_command(label="Copy message", command=lambda record=item: self._copy_text(record.get("plaintext", "")))
        try:
            selected = self.conversation.get("sel.first", "sel.last")
        except tk.TclError:
            selected = ""
        if selected:
            menu.add_command(label="Copy selected text", command=lambda: self._copy_text(selected))
        if menu.index("end") is not None:
            menu.tk_popup(event.x_root, event.y_root)

    def _copy_text(self, text):
        self.clipboard_clear()
        self.clipboard_append(str(text))
        self.update()

    def _find_in_conversation(self):
        if not self.selected_peer:
            return "break"
        term = simpledialog.askstring("Find", "Find in this in-memory conversation:", parent=self)
        if not term:
            return "break"
        self.conversation.tag_remove("search_hit", "1.0", "end")
        start = self.conversation.search(term, "1.0", stopindex="end", nocase=True)
        if not start:
            self.status_label.configure(text="Text not found in current conversation")
            return "break"
        end = f"{start}+{len(term)}c"
        self.conversation.tag_configure("search_hit", background="#fff3a3", foreground="#111111")
        self.conversation.tag_add("search_hit", start, end)
        self.conversation.see(start)
        return "break"

    def _contact_switcher(self):
        if not self.contacts:
            return "break"
        term = simpledialog.askstring("Contacts", "Search contacts:", parent=self)
        if term is None:
            return "break"
        term = term.strip().casefold()
        for index, peer in enumerate(self.contact_order):
            label = self._contact_label(peer, disambiguate=True)
            if not term or term in label.casefold() or term in peer.casefold():
                self.contact_list.selection_clear(0, "end")
                self.contact_list.selection_set(index)
                self.contact_list.activate(index)
                self.contact_list.see(index)
                self._on_contact_selected()
                break
        return "break"

    def _open_settings(self):
        if self.settings_window is not None and self.settings_window.winfo_exists():
            self.settings_window.lift()
            return "break"
        self.settings_window = SettingsWindow(self, self.settings)
        return "break"

    def apply_settings(self, changes):
        self.settings = self.settings_store.update(**changes)
        self._configure_style()
        self._apply_appearance()
        self.status_label.configure(text="Settings updated")

    def _notify_new_message(self, peer):
        mode = self.settings.get("notification_mode", "generic")
        if mode == "off":
            return
        if mode == "name":
            self.status_label.configure(text=f"New secure message from {self._base_contact_label(peer)}")
        else:
            self.status_label.configure(text="New secure message")

        if self.settings.get("sound_enabled", True):
            try:
                import winsound
                winsound.MessageBeep(winsound.MB_OK)
            except Exception:
                try:
                    self.bell()
                except Exception:
                    pass
        try:
            ctypes.windll.user32.FlashWindow(self.winfo_id(), True)
        except Exception:
            pass

    def _security_alert_sound(self):
        if not self.settings.get("security_sound_enabled", True):
            return
        try:
            import winsound
            winsound.MessageBeep(winsound.MB_ICONHAND)
        except Exception:
            try:
                self.bell()
            except Exception:
                pass

    def _emergency_lock(self):
        try:
            self.message_entry.configure(state="normal")
            self.message_entry.delete("1.0", "end")
        except Exception:
            pass
        self.histories.clear()
        self.message_status.clear()
        self.unread_counts.clear()
        self.reply_context = None
        self.rendered_message_tags.clear()
        try:
            self.conversation.configure(state="normal")
            self.conversation.delete("1.0", "end")
            self.conversation.configure(state="disabled")
        except Exception:
            pass
        try:
            self.clipboard_clear()
        except Exception:
            pass
        self.reopen_chooser = not runtime().production
        self.bridge.shutdown(self.engine)
        self.destroy()
        return "break"

    def _label_selected_contact(self):
        peer = self.selected_peer
        if not peer:
            return
        self._prompt_contact_label(peer)

    def _prompt_contact_label(self, peer, duplicate_hint=False):
        entry = self.contacts.get(peer, {})
        current = entry.get("local_alias") or ""
        remote = entry.get("display_name") or peer
        hint = (
            "Another contact has the same display name.\n\n"
            if duplicate_hint else ""
        )
        alias = simpledialog.askstring(
            "Local contact label",
            hint
            + f"Local label for {remote}:\n\n"
            + "Examples: Steve - Accounting, Steve Miller, Steve - Warehouse\n\n"
            + "This label stays only on this computer. Leave it blank to clear it.",
            initialvalue=current,
            parent=self,
        )
        if alias is None:
            return
        self.bridge.submit(self.engine.set_contact_alias(peer, alias))

    def _edit_display_name(self):
        new_name = simpledialog.askstring(
            "Edit display name",
            "Display name:\n\nYour permanent user ID and identity key will not change.",
            initialvalue=self.display_name,
            parent=self,
        )
        if new_name is None or new_name == self.display_name:
            return
        self.bridge.submit(self.engine.update_display_name(new_name))

    def _show_my_user_id(self):
        self.clipboard_clear()
        self.clipboard_append(self.client_id)
        self.update()
        messagebox.showinfo(
            "My User ID",
            f"{self.display_name}\n\nPermanent User ID:\n{self.client_id}\n\n"
            "The ID has been copied to the clipboard. Changing your display name does not change this ID.",
            parent=self,
        )

    def _remove_contact(self):
        peer = self.selected_peer
        if not peer:
            return

        entry = self.contacts.get(peer, {})
        label = self._base_contact_label(peer)
        if entry.get("status") in ("locked_key_change", "revoked"):
            messagebox.showerror(
                "Security controlled contact",
                "This identity is security locked or revoked and cannot be cleared by a standard user.",
                parent=self,
            )
            return

        if not messagebox.askyesno(
            "Remove contact",
            f"Hide {label} from your contact list?\n\n"
            "The pinned identity key will be retained to prevent a remove/re-add phishing bypass.",
            parent=self,
        ):
            return

        self.bridge.submit(self.engine.remove_contact(peer))

    def _open_admin_panel(self):
        if self.user_role not in (ROLE_ADMIN, ROLE_SUPER_ADMIN):
            messagebox.showerror(
                "Administrator required",
                "This operation is restricted to an administrator.",
                parent=self,
            )
            return
        if self.admin_window is not None and self.admin_window.winfo_exists():
            self.admin_window.lift()
            self.admin_window.focus_force()
            return
        self.admin_window = SecurityAdminWindow(self, self.bridge, self.engine)
        self.bridge.submit(self.engine.list_security_incidents())

    def _open_role_admin_panel(self):
        if self.user_role != ROLE_SUPER_ADMIN:
            messagebox.showerror(
                "Super Administrator required",
                "Only the Super Administrator can grant or revoke Base36 administrator authority.",
                parent=self,
            )
            return
        if self.role_admin_window is not None and self.role_admin_window.winfo_exists():
            self.role_admin_window.lift()
            self.role_admin_window.focus_force()
            return
        self.role_admin_window = RoleAdminWindow(self, self.bridge, self.engine)

    def _show_my_fingerprint(self):
        if not self.identity_fingerprint:
            messagebox.showinfo("Fingerprint", "Identity is still loading.", parent=self)
            return

        messagebox.showinfo(
            f"{self.display_name} fingerprint",
            self.identity_fingerprint,
            parent=self,
        )

    def _drain_events(self):
        try:
            while True:
                event = self.events.get_nowait()
                self._handle_event(event)
        except queue.Empty:
            pass

        self.after(75, self._drain_events)

    def _handle_event(self, event):
        kind = event.get("type")

        if kind == "identity":
            self.identity_fingerprint = event.get("fingerprint", "")
            if event.get("display_name"):
                self.display_name = event["display_name"]
                self.title(f"Base36 Chat — {self.display_name}")
            short = self.identity_fingerprint.replace(" ", "")[:12]
            self.identity_label.configure(
                text=f"{self.display_name} • {short}…"
            )

        elif kind == "display_name_changed":
            self.display_name = event.get("display_name") or self.display_name
            self.title(f"Base36 Chat — {self.display_name}")
            short = self.identity_fingerprint.replace(" ", "")[:12]
            suffix = f" • {short}…" if short else ""
            self.identity_label.configure(text=f"{self.display_name}{suffix}")
            self.status_label.configure(
                text=f"Display name changed to {self.display_name}"
            )

        elif kind == "contacts":
            self._refresh_contacts(event.get("contacts", []))

        elif kind == "contact_profile_updated":
            peer = event.get("peer")
            if peer in self.contacts:
                self.status_label.configure(
                    text=f"{self._base_contact_label(peer)} updated their display name"
                )
                if not self.contacts[peer].get("local_alias"):
                    base = self._base_contact_label(peer)
                    duplicates = [
                        other
                        for other in self.contacts
                        if self._base_contact_label(other).casefold() == base.casefold()
                    ]
                    if len(duplicates) > 1:
                        self._prompt_contact_label(peer, duplicate_hint=True)

        elif kind == "contact_alias_changed":
            peer = event.get("peer")
            if peer in self.contacts:
                self.status_label.configure(
                    text=f"Contact label updated for {self._base_contact_label(peer)}"
                )

        elif kind == "relay_status":
            relay = event.get("relay")
            self.relay_state[relay] = bool(event.get("connected"))
            self.relay_reconnecting[relay] = bool(event.get("reconnecting"))

            def relay_mark(name):
                if self.relay_state.get(name):
                    return "●"
                if self.relay_reconnecting.get(name):
                    return "◐"
                return "○"

            self.relay_label.configure(
                text=f"Relay A: {relay_mark('Relay A')}   Relay B: {relay_mark('Relay B')}"
            )

        elif kind == "starting":
            self.status_label.configure(text=event.get("message", "Connecting…"))

        elif kind == "transport_notice":
            self.status_label.configure(text=event.get("message", "Transport reconnecting…"))

        elif kind == "ready":
            self.status_label.configure(text="Both relays connected • no-queue mode")

        elif kind == "outgoing_message":
            self._add_history(
                event["peer"],
                "outgoing",
                event["plaintext"],
                event.get("status", "sending"),
                event.get("local_id"),
            )

        elif kind == "message_status":
            self._update_message_status(
                event.get("local_id"), event.get("status", "")
            )

        elif kind == "message_discarded":
            reason = event.get("reason", "Message was not retained.")
            self.status_label.configure(text=reason)
            messagebox.showwarning(
                "Message not sent",
                reason,
                parent=self,
            )

        elif kind == "message_failed":
            reason = event.get("reason") or "Delivery failed — message was discarded."
            self._purge_failed_message(event.get("local_id"), reason)
            self.status_label.configure(text=reason)

        elif kind == "incoming_message":
            peer = event["peer"]
            self._add_history(peer, "incoming", event["plaintext"], "verified")
            try:
                app_active = self.focus_displayof() is not None and self.state() != "iconic"
            except Exception:
                app_active = True
            if self.selected_peer != peer or not app_active:
                self.unread_counts[peer] = int(self.unread_counts.get(peer, 0) or 0) + 1
                self._refresh_contacts(list(self.contacts.values()))
                self._notify_new_message(peer)

        elif kind == "session_status":
            peer = event.get("peer")
            status = event.get("status")
            self.session_state[peer] = status
            if status == "secure":
                self._add_system(peer, "Secure session established.")
            elif status == "failed":
                self._add_system(peer, f"Session failed: {event.get('detail', '')}")
            elif status == "idle":
                self._add_system(peer, "Secure session expired after inactivity.")
            self._render_selected_peer()

        elif kind == "role":
            self.user_role = event.get("role", ROLE_USER)
            if self.user_role in (ROLE_ADMIN, ROLE_SUPER_ADMIN):
                self.admin_button.grid()
            else:
                self.admin_button.grid_remove()
            if self.user_role == ROLE_SUPER_ADMIN:
                self.role_admin_button.grid()
            else:
                self.role_admin_button.grid_remove()

        elif kind == "contact_request_sent":
            self.status_label.configure(
                text=f"Contact request sent to ID …{event.get('peer', '')[-4:].upper()}"
            )

        elif kind == "contact_request":
            peer = event.get("peer")
            display_name = event.get("display_name") or peer
            request_id = event.get("request_id")
            accepted = messagebox.askyesno(
                "Contact request",
                f"{display_name} wants to add you.\n\n"
                f"User ID: {peer}\n\n"
                "The same signed identity request arrived through both independent relays. "
                "If you accept, that identity key will be pinned and cannot be changed by a standard user.\n\n"
                "Accept this contact?",
                parent=self,
            )
            if accepted:
                self.bridge.submit(
                    self.engine.accept_contact_request(request_id)
                )
            else:
                self.bridge.submit(
                    self.engine.reject_contact_request(request_id)
                )

        elif kind == "contact_pinned":
            peer = event.get("peer")
            display_name = event.get("display_name") or self._base_contact_label(peer)
            messagebox.showinfo(
                "Identity pinned",
                f"{display_name} is now a trusted contact.\n\n"
                f"User ID: {peer}\n\n"
                "The identity key has been pinned. Future key changes will cause a hard security lock.",
                parent=self,
            )

            # If this creates a duplicate visible name, immediately offer the
            # human-friendly local label that solves the three-Steves problem.
            if (
                not event.get("existing")
                and peer in self.contacts
                and not self.contacts[peer].get("local_alias")
            ):
                base = self._base_contact_label(peer)
                duplicates = [
                    other
                    for other in self.contacts
                    if self._base_contact_label(other).casefold() == base.casefold()
                ]
                if len(duplicates) > 1:
                    self._prompt_contact_label(peer, duplicate_hint=True)

        elif kind == "contact_rejected":
            peer = event.get("peer")
            self.status_label.configure(
                text=f"Contact ID …{peer[-4:].upper()} rejected the request"
            )

        elif kind == "contact_removed":
            peer = event.get("peer")
            label = self._base_contact_label(peer) if peer in self.contacts else peer
            if self.selected_peer == peer:
                self.selected_peer = None
                self._render_history()
            self.status_label.configure(text=f"Removed {label}")

        elif kind == "security_lock":
            self._security_alert_sound()
            peer = event.get("peer")
            if peer:
                self.session_state[peer] = "locked"
                self._render_selected_peer()
            label = self._base_contact_label(peer) if peer in self.contacts else (peer or "this contact")
            messagebox.showerror(
                "Identity key changed",
                f"Secure messaging with {label} has been suspended.\n\n"
                "The presented identity key does not match the pinned identity. "
                "There is no user override. Contact an administrator.",
                parent=self,
            )

        elif kind == "admin_incidents":
            if self.admin_window is not None and self.admin_window.winfo_exists():
                self.admin_window.set_incidents(event.get("incidents", []))

        elif kind == "admin_action":
            self.status_label.configure(
                text=event.get("message", "Administrator action completed")
            )
            if self.admin_window is not None and self.admin_window.winfo_exists():
                self.bridge.submit(self.engine.list_security_incidents())

        elif kind == "authority_notice":
            role = event.get("role", ROLE_USER)
            readable = {
                ROLE_USER: "User",
                ROLE_ADMIN: "Administrator",
                ROLE_SUPER_ADMIN: "Super Administrator",
            }.get(role, role)
            messagebox.showinfo(
                "Base36 role updated",
                f"Your Base36 role is now: {readable}.\n\n"
                "Role authority changes do not provide access to anyone else's messages or private keys.",
                parent=self,
            )

        elif kind == "security_reject":
            peer = event.get("peer")
            text = event.get("message", "Security check rejected a packet")
            if peer:
                self._add_system(peer, f"Security rejection: {text}")
            self.status_label.configure(
                text="Security check rejected a packet"
            )

        elif kind == "invitation_ready":
            self._display_invitation(event)

        elif kind == "version_warning":
            peer = event.get("peer") or "contact"
            self.status_label.configure(
                text=(
                    f"Version warning for {peer}: peer protocol "
                    f"{event.get('peer_version')} / local {event.get('local_version')}"
                )
            )

        elif kind in ("error", "fatal"):
            text = event.get("message", "Unknown error")
            self.status_label.configure(text=text)
            if kind == "fatal":
                messagebox.showerror("Base36 Chat", text, parent=self)

    def _on_close(self):
        self._set_composer_enabled(False)
        self.status_label.configure(text="Closing…")
        self.update_idletasks()
        self.bridge.shutdown(self.engine)
        self.destroy()


class SettingsWindow(tk.Toplevel):
    def __init__(self, parent, settings):
        super().__init__(parent)
        self.parent = parent
        self.title("Base36 Chat — Settings")
        self.geometry("520x560")
        self.resizable(False, False)
        self.transient(parent)

        self.appearance = tk.StringVar(value=settings.get("appearance", "light"))
        self.font_size = tk.IntVar(value=int(settings.get("font_size", 10)))
        self.density = tk.StringVar(value=settings.get("density", "comfortable"))
        self.enter_to_send = tk.BooleanVar(value=bool(settings.get("enter_to_send", True)))
        self.emoji_shortcuts = tk.BooleanVar(value=bool(settings.get("emoji_shortcuts", True)))
        self.sound_enabled = tk.BooleanVar(value=bool(settings.get("sound_enabled", True)))
        self.security_sound_enabled = tk.BooleanVar(value=bool(settings.get("security_sound_enabled", True)))
        self.notification_mode = tk.StringVar(value=settings.get("notification_mode", "generic"))

        outer = ttk.Frame(self, padding=16)
        outer.pack(fill="both", expand=True)

        ttk.Label(outer, text="Profile", font=("Segoe UI", 12, "bold")).pack(anchor="w")
        ttk.Label(
            outer,
            text=f"{parent.display_name}\nUser ID: {parent.client_id}",
            justify="left",
        ).pack(anchor="w", pady=(4, 8))

        profile_buttons = ttk.Frame(outer)
        profile_buttons.pack(fill="x", pady=(0, 14))
        ttk.Button(profile_buttons, text="Edit Display Name", command=parent._edit_display_name).pack(side="left")
        ttk.Button(profile_buttons, text="Copy User ID", command=parent._show_my_user_id).pack(side="left", padx=6)
        ttk.Button(profile_buttons, text="Fingerprint", command=parent._show_my_fingerprint).pack(side="left")

        ttk.Separator(outer).pack(fill="x", pady=8)
        ttk.Label(outer, text="Appearance", font=("Segoe UI", 12, "bold")).pack(anchor="w")

        row = ttk.Frame(outer)
        row.pack(fill="x", pady=5)
        ttk.Label(row, text="Theme", width=18).pack(side="left")
        ttk.Combobox(row, textvariable=self.appearance, values=("light", "dark"), state="readonly", width=18).pack(side="left")

        row = ttk.Frame(outer)
        row.pack(fill="x", pady=5)
        ttk.Label(row, text="Font size", width=18).pack(side="left")
        tk.Spinbox(row, from_=8, to=18, textvariable=self.font_size, width=6).pack(side="left")

        row = ttk.Frame(outer)
        row.pack(fill="x", pady=5)
        ttk.Label(row, text="Spacing", width=18).pack(side="left")
        ttk.Combobox(row, textvariable=self.density, values=("compact", "comfortable"), state="readonly", width=18).pack(side="left")

        ttk.Separator(outer).pack(fill="x", pady=8)
        ttk.Label(outer, text="Composer & Notifications", font=("Segoe UI", 12, "bold")).pack(anchor="w")
        ttk.Checkbutton(outer, text="Enter sends (Shift+Enter inserts newline)", variable=self.enter_to_send).pack(anchor="w", pady=3)
        ttk.Checkbutton(outer, text="Expand emoji shortcuts (:coffee:, :), :D, :P)", variable=self.emoji_shortcuts).pack(anchor="w", pady=3)
        ttk.Checkbutton(outer, text="Normal message sound", variable=self.sound_enabled).pack(anchor="w", pady=3)
        ttk.Checkbutton(outer, text="Distinct security-warning sound", variable=self.security_sound_enabled).pack(anchor="w", pady=3)

        row = ttk.Frame(outer)
        row.pack(fill="x", pady=5)
        ttk.Label(row, text="New message notice", width=18).pack(side="left")
        ttk.Combobox(
            row,
            textvariable=self.notification_mode,
            values=("off", "generic", "name"),
            state="readonly",
            width=18,
        ).pack(side="left")

        ttk.Label(
            outer,
            text=(
                "Generic notifications show no sender or plaintext. The Windows taskbar may flash, "
                "but Base36 Chat does not write message previews into OS notification history."
            ),
            wraplength=475,
            style="Subtle.TLabel",
        ).pack(anchor="w", pady=(5, 14))

        buttons = ttk.Frame(outer)
        buttons.pack(fill="x", side="bottom")
        ttk.Button(buttons, text="Apply", command=self._apply).pack(side="right")
        ttk.Button(buttons, text="Close", command=self.destroy).pack(side="right", padx=6)

    def _apply(self):
        self.parent.apply_settings({
            "appearance": self.appearance.get(),
            "font_size": self.font_size.get(),
            "density": self.density.get(),
            "enter_to_send": self.enter_to_send.get(),
            "emoji_shortcuts": self.emoji_shortcuts.get(),
            "sound_enabled": self.sound_enabled.get(),
            "security_sound_enabled": self.security_sound_enabled.get(),
            "notification_mode": self.notification_mode.get(),
        })


class SecurityAdminWindow(tk.Toplevel):
    def __init__(self, parent, bridge, engine):
        super().__init__(parent)
        self.title("Base36 Chat — Security Administration")
        self.geometry("820x500")
        self.minsize(720, 420)
        self.bridge = bridge
        self.engine = engine
        self.incidents = []

        self.columnconfigure(0, weight=1)
        self.rowconfigure(1, weight=1)

        ttk.Label(
            self,
            text="Identity Key Change Incidents",
            font=("Segoe UI", 16, "bold"),
        ).grid(row=0, column=0, sticky="w", padx=16, pady=(16, 8))

        frame = ttk.Frame(self, padding=(16, 0, 16, 0))
        frame.grid(row=1, column=0, sticky="nsew")
        frame.columnconfigure(0, weight=1)
        frame.rowconfigure(0, weight=1)

        self.listbox = tk.Listbox(frame, font=("Consolas", 10), exportselection=False)
        self.listbox.grid(row=0, column=0, sticky="nsew")
        self.listbox.bind("<<ListboxSelect>>", self._selection_changed)

        scroll = ttk.Scrollbar(frame, orient="vertical", command=self.listbox.yview)
        scroll.grid(row=0, column=1, sticky="ns")
        self.listbox.configure(yscrollcommand=scroll.set)

        self.detail = ttk.Label(self, text="", wraplength=780, justify="left")
        self.detail.grid(row=2, column=0, sticky="ew", padx=16, pady=10)

        buttons = ttk.Frame(self, padding=(16, 0, 16, 16))
        buttons.grid(row=3, column=0, sticky="ew")
        ttk.Button(buttons, text="Refresh", command=self._refresh).pack(side="left")
        ttk.Button(buttons, text="Reject New Key / Keep Old Pin", command=self._reject).pack(side="right", padx=(6, 0))
        ttk.Button(buttons, text="Authorize Replacement", command=self._authorize).pack(side="right")

    def _refresh(self):
        self.bridge.submit(self.engine.list_security_incidents())

    def set_incidents(self, incidents):
        self.incidents = list(incidents)
        self.listbox.delete(0, "end")
        for item in self.incidents:
            self.listbox.insert("end", f"{item['owner']}  ->  {item['peer']}")
        if self.incidents:
            self.listbox.selection_set(0)
            self._selection_changed()
        else:
            self.detail.configure(text="No identity-key change incidents are pending.")

    def _selected(self):
        selection = self.listbox.curselection()
        if not selection:
            return None
        return self.incidents[selection[0]]

    def _selection_changed(self, _event=None):
        item = self._selected()
        if not item:
            return
        self.detail.configure(
            text=(
                f"Owner: {item['owner']}    Contact: {item['peer']}\n\n"
                f"PINNED KEY:\n{item.get('old_fingerprint') or ''}\n\n"
                f"PRESENTED KEY:\n{item.get('new_fingerprint') or ''}\n\n"
                "Ordinary users cannot override this mismatch."
            )
        )

    def _reason(self, title):
        return simpledialog.askstring(
            title,
            "Administrator reason (required):",
            parent=self,
        )

    def _authorize(self):
        item = self._selected()
        if not item:
            return
        reason = self._reason("Authorize identity replacement")
        if not reason:
            return
        if not messagebox.askyesno(
            "Authorize replacement",
            f"Replace the pinned identity for {item['owner']} → {item['peer']} with the presented key?\n\n"
            "Use this only for a legitimate lost/compromised identity reset.",
            parent=self,
        ):
            return
        self.bridge.submit(
            self.engine.admin_authorize_replacement(item["owner"], item["peer"], reason)
        )

    def _reject(self):
        item = self._selected()
        if not item:
            return
        reason = self._reason("Reject presented identity")
        if not reason:
            return
        self.bridge.submit(
            self.engine.admin_reject_presented_key(item["owner"], item["peer"], reason)
        )




class RoleAdminWindow(tk.Toplevel):
    """Super Administrator role grant/revoke console.

    Role control packets are signed by the environment authority and sent over
    both relays. They contain authorization metadata only; no message keys.
    """

    def __init__(self, parent, bridge, engine):
        super().__init__(parent)
        self.parent = parent
        self.bridge = bridge
        self.engine = engine
        self.title("Base36 Chat — Role Administration")
        self.geometry("680x470")
        self.minsize(600, 400)

        outer = ttk.Frame(self, padding=16)
        outer.pack(fill="both", expand=True)
        outer.columnconfigure(0, weight=1)
        outer.rowconfigure(2, weight=1)

        ttk.Label(
            outer,
            text="Super Administrator",
            font=("Segoe UI", 16, "bold"),
        ).grid(row=0, column=0, sticky="w")
        ttk.Label(
            outer,
            text=(
                "Grant or revoke Base36 administrator authority. This never grants "
                "access to another user's private key or conversations. Role changes "
                "are not queued; the recipient must be online."
            ),
            wraplength=630,
            style="Subtle.TLabel",
        ).grid(row=1, column=0, sticky="ew", pady=(4, 12))

        self.listbox = tk.Listbox(outer, exportselection=False, font=("Segoe UI", 10))
        self.listbox.grid(row=2, column=0, sticky="nsew")
        self.peer_ids = []
        self._refresh_contacts()

        buttons = ttk.Frame(outer)
        buttons.grid(row=3, column=0, sticky="ew", pady=(12, 0))
        ttk.Button(buttons, text="Grant Administrator", command=self._grant).pack(side="left")
        ttk.Button(buttons, text="Revoke Administrator", command=self._revoke).pack(side="left", padx=6)
        ttk.Button(buttons, text="Copy Environment Invite", command=self._copy_environment).pack(side="right")

        self.status = ttk.Label(outer, text="", style="Subtle.TLabel", wraplength=630)
        self.status.grid(row=4, column=0, sticky="ew", pady=(10, 0))

    def _refresh_contacts(self):
        self.listbox.delete(0, "end")
        self.peer_ids = []
        for peer in self.parent.contact_order:
            entry = self.parent.contacts.get(peer, {})
            if not entry.get("trusted"):
                continue
            label = self.parent._base_contact_label(peer)
            self.peer_ids.append(peer)
            self.listbox.insert("end", f"{label}    • {peer[-4:].upper()}")
        if self.peer_ids:
            self.listbox.selection_set(0)

    def _selected_peer(self):
        selection = self.listbox.curselection()
        if not selection:
            return None
        index = selection[0]
        if index >= len(self.peer_ids):
            return None
        return self.peer_ids[index]

    def _grant(self):
        peer = self._selected_peer()
        if not peer:
            messagebox.showinfo("Role Administration", "Select a trusted contact first.", parent=self)
            return
        label = self.parent._base_contact_label(peer)
        if not messagebox.askyesno(
            "Grant Administrator",
            f"Grant Base36 Administrator authority to {label}?\n\n"
            "This does not grant message-reading or impersonation capability.",
            parent=self,
        ):
            return
        self.bridge.submit(self.engine.grant_administrator(peer))
        self.status.configure(text=f"Administrator grant sent to {label}. No offline copy is retained.")

    def _revoke(self):
        peer = self._selected_peer()
        if not peer:
            messagebox.showinfo("Role Administration", "Select a trusted contact first.", parent=self)
            return
        label = self.parent._base_contact_label(peer)
        if not messagebox.askyesno(
            "Revoke Administrator",
            f"Revoke Base36 Administrator authority from {label}?",
            parent=self,
        ):
            return
        self.bridge.submit(self.engine.revoke_administrator(peer))
        self.status.configure(text=f"Administrator revocation sent to {label}. No offline copy is retained.")

    def _copy_environment(self):
        try:
            token = self.engine.environment_invitation()
        except Exception as exc:
            messagebox.showerror("Environment Invite", str(exc), parent=self)
            return
        self.clipboard_clear()
        self.clipboard_append(token)
        self.update()
        messagebox.showinfo(
            "Environment Invite",
            "The signed Base36 environment invitation was copied to the clipboard.\n\n"
            "Transfer it to the joining user through a trusted out-of-band path. It contains "
            "the authority public key and no message content.",
            parent=self,
        )


class ProfileChooser(tk.Tk):
    """First-run/local-user chooser. No command-line identity creation needed."""

    def __init__(self):
        if runtime().production:
            raise RuntimeError("The production client does not expose the development profile chooser")
        super().__init__()
        self.title("Base36 Chat — Choose User")
        self.geometry("560x430")
        self.minsize(500, 360)
        self.resizable(True, True)

        self.profile_store = ProfileStore()
        self.selected_profile = None
        self.profiles = []

        self.columnconfigure(0, weight=1)
        self.rowconfigure(2, weight=1)

        ttk.Label(
            self,
            text="Base36 Chat",
            font=("Segoe UI", 20, "bold"),
        ).grid(row=0, column=0, sticky="w", padx=22, pady=(20, 2))

        ttk.Label(
            self,
            text="Choose a local user, or create one. New users get a permanent random user ID and unique identity keypair.",
            foreground="#666666",
        ).grid(row=1, column=0, sticky="w", padx=22, pady=(0, 14))

        frame = ttk.Frame(self, padding=(22, 0, 22, 0))
        frame.grid(row=2, column=0, sticky="nsew")
        frame.columnconfigure(0, weight=1)
        frame.rowconfigure(0, weight=1)

        self.user_list = tk.Listbox(
            frame,
            activestyle="none",
            exportselection=False,
            font=("Segoe UI", 11),
            borderwidth=0,
            highlightthickness=1,
        )
        self.user_list.grid(row=0, column=0, sticky="nsew")
        self.user_list.bind("<Double-Button-1>", lambda _event: self._open_selected())
        self.user_list.bind("<<ListboxSelect>>", self._selection_changed)

        scroll = ttk.Scrollbar(frame, orient="vertical", command=self.user_list.yview)
        scroll.grid(row=0, column=1, sticky="ns")
        self.user_list.configure(yscrollcommand=scroll.set)

        self.fingerprint_label = ttk.Label(
            self,
            text="",
            foreground="#666666",
            wraplength=500,
        )
        self.fingerprint_label.grid(row=3, column=0, sticky="w", padx=22, pady=(10, 4))

        buttons = ttk.Frame(self, padding=(22, 8, 22, 20))
        buttons.grid(row=4, column=0, sticky="ew")
        buttons.columnconfigure(0, weight=1)
        buttons.columnconfigure(1, weight=1)
        buttons.columnconfigure(2, weight=1)

        self.open_button = ttk.Button(buttons, text="Open User", command=self._open_selected)
        self.open_button.grid(row=0, column=0, sticky="ew", padx=(0, 5))

        ttk.Button(buttons, text="Create New User", command=self._create_user).grid(
            row=0, column=1, sticky="ew", padx=5
        )

        ttk.Button(buttons, text="Exit", command=self.destroy).grid(
            row=0, column=2, sticky="ew", padx=(5, 0)
        )

        self._refresh()

    def _refresh(self, select_id=None):
        try:
            self.profiles = self.profile_store.list_profiles()
        except Exception as exc:
            messagebox.showerror("Users", str(exc), parent=self)
            self.profiles = []

        self.user_list.delete(0, "end")
        selected_index = None

        for index, profile in enumerate(self.profiles):
            self.user_list.insert(
                "end",
                f"{profile['display_name']}    • {profile['id'][-4:].upper()}"
                + ("    [ADMIN]" if profile.get("role") == "administrator" else ""),
            )
            if profile["id"] == select_id:
                selected_index = index

        if selected_index is not None:
            self.user_list.selection_set(selected_index)
            self.user_list.activate(selected_index)
            self.user_list.see(selected_index)
        elif self.profiles:
            self.user_list.selection_set(0)
            self.user_list.activate(0)

        self._selection_changed()

    def _selection_changed(self, _event=None):
        selection = self.user_list.curselection()
        if not selection:
            self.open_button.configure(state="disabled")
            self.fingerprint_label.configure(text="No local users yet. Click Create New User.")
            return

        self.open_button.configure(state="normal")
        profile = self.profiles[selection[0]]
        fp = profile.get("fingerprint", "")
        self.fingerprint_label.configure(
            text=(
                f"{profile['display_name']}\n"
                f"User ID: {profile['id']}\n"
                f"Fingerprint: {fp}"
            )
        )

    def _create_user(self):
        name = simpledialog.askstring(
            "Create user",
            "Display name:\n\nExample: Joel or Frank",
            parent=self,
        )
        if not name:
            return

        try:
            profile = self.profile_store.create_profile(name)
        except Exception as exc:
            messagebox.showerror("Create user", str(exc), parent=self)
            return

        messagebox.showinfo(
            "User created",
            f"Created {profile['display_name']}.\n\n"
            f"User ID: {profile['id']}\n"
            f"Role: {profile.get('role', 'user')}\n\n"
            f"Unique identity fingerprint:\n{profile['fingerprint']}\n\n"
            "The private identity key stays on this computer.",
            parent=self,
        )
        self._refresh(select_id=profile["id"])

    def _open_selected(self):
        selection = self.user_list.curselection()
        if not selection:
            return

        self.selected_profile = self.profiles[selection[0]]
        self.destroy()



class ProductionProvisioner(tk.Tk):
    """First-run provisioning for exactly one identity under one Windows SID."""

    def __init__(self):
        super().__init__()
        self.title("Base36 Chat — First Run")
        self.geometry("640x470")
        self.resizable(False, False)
        self.profile_store = ProfileStore()
        self.binding = ProductionBinding()
        self.selected_profile = None

        outer = ttk.Frame(self, padding=22)
        outer.pack(fill="both", expand=True)

        ttk.Label(outer, text="Set Up Base36 Chat", font=("Segoe UI", 20, "bold")).pack(anchor="w")
        ttk.Label(
            outer,
            text=(
                "This production client will bind one Base36 identity to the Windows account "
                "that is currently signed in. Other Windows users on this computer get their "
                "own separate Base36 identity and local state."
            ),
            wraplength=590,
            style="Subtle.TLabel",
        ).pack(anchor="w", pady=(5, 18))

        ttk.Label(outer, text="Display name").pack(anchor="w")
        self.name_var = tk.StringVar()
        self.name_entry = ttk.Entry(outer, textvariable=self.name_var, width=48)
        self.name_entry.pack(fill="x", pady=(4, 18))
        self.name_entry.focus_set()

        ttk.Label(outer, text="Choose how this Windows user joins Base36:", font=("Segoe UI", 11, "bold")).pack(anchor="w")
        ttk.Button(
            outer,
            text="Create New Environment — This User Is Super Administrator",
            command=self._create_environment,
        ).pack(fill="x", pady=(10, 6))
        ttk.Button(
            outer,
            text="Join Existing Environment — Paste Signed Environment Invite",
            command=self._join_environment,
        ).pack(fill="x", pady=6)

        ttk.Label(
            outer,
            text=(
                "Creating a new environment creates a separate administrative trust root. "
                "Joining an existing environment requires the signed authority invitation from "
                "that environment's Super Administrator."
            ),
            wraplength=590,
            style="Subtle.TLabel",
        ).pack(anchor="w", pady=(14, 0))

        ttk.Button(outer, text="Exit", command=self.destroy).pack(side="bottom", anchor="e")

    def _name(self):
        value = self.name_var.get().strip()
        if not value:
            raise ValueError("Enter your display name")
        return value

    def _finalize(self, profile):
        self.binding.bind(profile["id"])
        self.selected_profile = profile
        messagebox.showinfo(
            "Base36 Chat",
            f"This Windows account is now bound to {profile['display_name']}.\n\n"
            f"Permanent User ID: {profile['id']}\n\n"
            "Base36 Chat will not offer a profile chooser in production.",
            parent=self,
        )
        self.destroy()

    def _create_environment(self):
        try:
            if self.profile_store.list_profiles():
                raise RuntimeError("Production state already contains a Base36 identity")
            profile = self.profile_store.create_profile(self._name())
            authority = AuthorityStore(profile["id"])
            authority.create_environment()
            self._finalize(profile)
        except Exception as exc:
            messagebox.showerror("Create Environment", str(exc), parent=self)

    def _join_environment(self):
        token = simpledialog.askstring(
            "Join Base36 Environment",
            "Paste the signed environment invitation supplied by the Super Administrator:",
            parent=self,
        )
        if not token:
            return
        try:
            # Validate before creating local identity state.
            AuthorityStore.inspect_environment_invitation(token)
            if self.profile_store.list_profiles():
                raise RuntimeError("Production state already contains a Base36 identity")
            profile = self.profile_store.create_profile(self._name())
            authority = AuthorityStore(profile["id"])
            authority.import_environment_invitation(token)
            self._finalize(profile)
        except Exception as exc:
            messagebox.showerror("Join Environment", str(exc), parent=self)


def production_profile():
    """Resolve the only profile allowed for the currently signed-in Windows user."""
    if not runtime().production:
        raise RuntimeError("production_profile called in development mode")

    binding = ProductionBinding()
    doc = binding.load()
    if doc is None:
        provisioner = ProductionProvisioner()
        provisioner.mainloop()
        return provisioner.selected_profile

    doc = binding.require_current_user()
    store = ProfileStore()
    profile = store.get_profile(doc["user_id"])
    if profile is None:
        raise RuntimeError(
            "This Windows account is bound to a Base36 user whose local identity is missing. "
            "Do not create a replacement identity with the same name; use the recovery process."
        )

    # Production must never silently expose a second identity even if stray
    # development files were copied into the user data directory.
    ids = [p["id"] for p in store.list_profiles()]
    if len(ids) != 1 or ids[0] != profile["id"]:
        raise RuntimeError(
            "Multiple Base36 identities were found in production state. Startup is blocked "
            "rather than offering an identity chooser."
        )

    authority = AuthorityStore(profile["id"])
    profile = dict(profile)
    profile["role"] = authority.role_for_owner()
    return profile


def choose_profile():
    chooser = ProfileChooser()
    chooser.mainloop()
    return chooser.selected_profile


def main():
    parser = argparse.ArgumentParser(description="Base36 Cipher Chat desktop app")
    parser.add_argument(
        "--id",
        required=False,
        help="Development build only: open a specific local test identity",
    )
    args = parser.parse_args()

    if runtime().production:
        if args.id:
            raise SystemExit(
                "The production client does not allow command-line identity selection. "
                "Sign in to Windows with the account that owns the Base36 identity."
            )
        profile = production_profile()
        if profile is None:
            return
    else:
        if args.id:
            profile_id = normalize_profile_id(args.id)
            store = ProfileStore()
            profile = store.get_profile(profile_id)
            if profile is None:
                available = {p["id"]: p for p in store.list_profiles()}
                profile = available.get(profile_id)
            if profile is None:
                raise SystemExit(
                    f"Local test user '{profile_id}' does not exist. Run app_dev.py without --id and create it in the GUI."
                )
        else:
            profile = choose_profile()
            if profile is None:
                return

    while profile is not None:
        app = ChatApp(
            profile["id"],
            display_name=profile.get("display_name"),
            role=profile.get("role", ROLE_USER),
        )
        app.mainloop()

        # Only the development harness ever returns to a multi-profile chooser.
        if runtime().production or not getattr(app, "reopen_chooser", False):
            break
        profile = choose_profile()


if __name__ == "__main__":
    main()
