# Base36 Cipher Chat — Secure Comfort Update

This package builds on the working 19 August 2026 Unicode/display-name update and adds the security hardening and user-comfort features requested afterward.

The most important architectural change is **no message queue anywhere in the normal GUI/relay path**. The client sends now or discards; the relay forwards now or rejects. Automatic relay reconnection reconnects transport only and never resends old messages.

The package also adds unread counters, privacy-oriented local notifications, generated initials, contact/message context menus, reply-to-message, current-session search, contact search, emoji recents, light/dark mode, font and density settings, sound controls, auto-growing composer, keyboard shortcuts, signed invitation codes/QR generation, clipboard invitation import, contact/security details, delivery receipts, session idle expiry, message-size/malformed-packet limits, rate limiting, version compatibility checks, and Emergency Lock.

## Required deployment order

1. Back up the current project folder and relay server copies.
2. Replace **both VM relay instances** with the included `relay.py` and restart them on ports 80 and 443.
3. Replace the matching desktop files with this package (`app.py`, `engine.py`, `cipher.py`, `profiles.py`, `contacts.py`) and add `settings.py`.
4. Start two clients and confirm both show `Both relays connected • no-queue mode`.
5. Run the functional checks in `UPDATE_NOTES.md`.

The client intentionally refuses an older queue-capable relay, so a partially updated deployment will show reconnect/protocol errors rather than silently using the old behavior.
