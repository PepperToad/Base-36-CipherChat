import secrets


# ============================================================
# BASE-36
# ============================================================

ALPHABET = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"

CHAR_TO_VALUE = {
    char: value
    for value, char in enumerate(ALPHABET)
}

VALUE_TO_CHAR = {
    value: char
    for value, char in enumerate(ALPHABET)
}

MODULUS = 36


# ============================================================
# PROTOCOL VERSION
# ============================================================

CIPHER_VERSION = 2
LEGACY_CIPHER_VERSION = 1
CODEC_ID = "utf8-b36-v1"


# ============================================================
# ESCAPE SYSTEM
# ============================================================
#
# Z is the escape character.
#
# Existing rules:
#
#   SPACE -> ZS
#   Z     -> ZZ
#   0     -> Z0
#   1     -> Z1
#   ...
#   9     -> Z9
#
# We also reserve additional Z codes for common punctuation
# so the test chat can behave more like normal messaging.
#
# ============================================================

ESCAPE_TABLE = {
    " ": "ZS",
    "Z": "ZZ",

    "0": "Z0",
    "1": "Z1",
    "2": "Z2",
    "3": "Z3",
    "4": "Z4",
    "5": "Z5",
    "6": "Z6",
    "7": "Z7",
    "8": "Z8",
    "9": "Z9",

    ".": "ZA",
    ",": "ZB",
    "?": "ZC",
    "!": "ZD",
    "'": "ZE",
    '"': "ZF",
    ":": "ZG",
    ";": "ZH",
    "-": "ZI",
    "_": "ZJ",
    "(": "ZK",
    ")": "ZL",
    "/": "ZM",
    "\\": "ZN",
    "@": "ZO",
    "#": "ZP",
    "$": "ZQ",
    "%": "ZR",
    "&": "ZT",
    "+": "ZU",
    "=": "ZV",
    "*": "ZW",
    "<": "ZX",
    ">": "ZY",
}


REVERSE_ESCAPE_TABLE = {
    encoded[1]: plaintext
    for plaintext, encoded in ESCAPE_TABLE.items()
}


# ============================================================
# PLAINTEXT PREPARATION
# ============================================================

def legacy_prepare_plaintext(text):
    """
    Convert plaintext into the Base-36-safe prepared format.

    Plain letters A-Y remain unchanged.

    Z, spaces, digits, and supported punctuation are escaped.

    Text is converted to uppercase.
    """

    if not isinstance(text, str):
        raise TypeError("Plaintext must be a string")

    text = text.upper()

    output = []

    for char in text:

        if char in ESCAPE_TABLE:
            output.append(
                ESCAPE_TABLE[char]
            )

        elif "A" <= char <= "Y":
            output.append(char)

        else:
            raise ValueError(
                f"Unsupported plaintext character: {repr(char)}"
            )

    return "".join(output)


def legacy_decode_prepared(text):
    """
    Reverse the plaintext escape system.
    """

    output = []

    index = 0

    while index < len(text):

        char = text[index]

        # Normal A-Y character.
        if char != "Z":

            if not ("A" <= char <= "Y"):
                raise ValueError(
                    f"Invalid prepared plaintext character: {char}"
                )

            output.append(char)

            index += 1
            continue

        # Z means an escape sequence must follow.
        if index + 1 >= len(text):
            raise ValueError(
                "Dangling Z escape at end of plaintext"
            )

        escape_code = text[index + 1]

        if escape_code not in REVERSE_ESCAPE_TABLE:
            raise ValueError(
                f"Unknown escape sequence: Z{escape_code}"
            )

        output.append(
            REVERSE_ESCAPE_TABLE[escape_code]
        )

        index += 2

    return "".join(output)


# ============================================================
# UTF-8 / BASE-36 CODEC (V2)
# ============================================================
#
# Each UTF-8 byte (0..255) is encoded as exactly two Base-36
# symbols. 36^2 = 1296, so every byte fits without changing
# the cipher alphabet or the mod-36 arithmetic.
#
# This preserves case, punctuation, line breaks, accented text,
# non-Latin scripts, and emoji while the cipher core remains:
#
#     C = P + K mod 36
#
# ============================================================

_BYTE_TO_PAIR = tuple(
    ALPHABET[value // MODULUS] + ALPHABET[value % MODULUS]
    for value in range(256)
)


def prepare_plaintext(text):
    """Encode arbitrary Unicode plaintext into Base-36-safe UTF-8 pairs."""
    if not isinstance(text, str):
        raise TypeError("Plaintext must be a string")

    raw = text.encode("utf-8", errors="strict")
    return "".join(_BYTE_TO_PAIR[value] for value in raw)


def decode_prepared(text):
    """Decode fixed-width Base-36 byte pairs back into exact Unicode text."""
    validate_base36(text, "prepared plaintext")

    if len(text) % 2 != 0:
        raise ValueError("Prepared UTF-8/Base36 text must have an even length")

    raw = bytearray()

    for index in range(0, len(text), 2):
        value = (
            CHAR_TO_VALUE[text[index]] * MODULUS
            + CHAR_TO_VALUE[text[index + 1]]
        )
        if value > 255:
            raise ValueError(
                f"Invalid UTF-8/Base36 byte pair: {text[index:index + 2]}"
            )
        raw.append(value)

    try:
        return bytes(raw).decode("utf-8", errors="strict")
    except UnicodeDecodeError as exc:
        raise ValueError("Decoded plaintext bytes are not valid UTF-8") from exc


# ============================================================
# RANDOM BASE-36 DATA
# ============================================================

def random_base36(length):
    """
    Generate cryptographically secure random Base-36 data.
    """

    if length < 0:
        raise ValueError(
            "Length cannot be negative"
        )

    return "".join(
        ALPHABET[
            secrets.randbelow(MODULUS)
        ]
        for _ in range(length)
    )


# ============================================================
# MOD-36 ARITHMETIC
# ============================================================

def validate_base36(text, name="value"):
    """
    Verify that a string contains only Base-36 characters.
    """

    if not isinstance(text, str):
        raise TypeError(
            f"{name} must be a string"
        )

    for char in text:

        if char not in CHAR_TO_VALUE:
            raise ValueError(
                f"{name} contains invalid Base-36 character: {char}"
            )


def add_mod36(left, right):
    """
    Character-by-character Base-36 modular addition.

        result[i] = (left[i] + right[i]) mod 36
    """

    validate_base36(left, "left")
    validate_base36(right, "right")

    if len(left) != len(right):
        raise ValueError(
            "Base-36 values must have equal lengths"
        )

    output = []

    for a, b in zip(left, right):

        value = (
            CHAR_TO_VALUE[a]
            + CHAR_TO_VALUE[b]
        ) % MODULUS

        output.append(
            VALUE_TO_CHAR[value]
        )

    return "".join(output)


def subtract_mod36(left, right):
    """
    Character-by-character Base-36 modular subtraction.

        result[i] = (left[i] - right[i]) mod 36
    """

    validate_base36(left, "left")
    validate_base36(right, "right")

    if len(left) != len(right):
        raise ValueError(
            "Base-36 values must have equal lengths"
        )

    output = []

    for a, b in zip(left, right):

        value = (
            CHAR_TO_VALUE[a]
            - CHAR_TO_VALUE[b]
        ) % MODULUS

        output.append(
            VALUE_TO_CHAR[value]
        )

    return "".join(output)


# ============================================================
# ONE-TIME KEY
# ============================================================

def generate_key(length):
    """
    Generate a fresh random Base-36 key.

    The key length equals the padded prepared plaintext length.
    """

    return random_base36(length)


# ============================================================
# RANDOM PADDING
# ============================================================

def add_padding(prepared_text):
    """
    Add random Base-36 padding.

    The total message length is always divisible by 3 so the
    three-column transposition is simple and exactly reversible.

    At least one complete random row of padding is added.

    Returns:

        padded_text
        pad_count
    """

    length = len(prepared_text)

    # Number required to reach next multiple of 3.
    alignment_padding = (-length) % 3

    # Add between 1 and 4 additional complete 3-character rows.
    extra_rows = 1 + secrets.randbelow(4)

    pad_count = (
        alignment_padding
        + (extra_rows * 3)
    )

    padding = random_base36(
        pad_count
    )

    return (
        prepared_text + padding,
        pad_count,
    )


def remove_padding(text, pad_count):
    """
    Remove exactly the number of padding characters recorded
    during encryption.
    """

    if not isinstance(pad_count, int):
        raise TypeError(
            "pad_count must be an integer"
        )

    if pad_count < 0:
        raise ValueError(
            "pad_count cannot be negative"
        )

    if pad_count > len(text):
        raise ValueError(
            "pad_count exceeds plaintext length"
        )

    if pad_count == 0:
        return text

    return text[:-pad_count]


# ============================================================
# THREE-COLUMN TRANSPOSITION
# ============================================================

TRANSPOSITION_ORDERS = (
    "123",
    "132",
    "213",
    "231",
    "312",
    "321",
)


def generate_transposition_order():
    """
    Randomly choose one of the six possible three-column orders.
    """

    return secrets.choice(
        TRANSPOSITION_ORDERS
    )


def transpose_three_columns(text, order):
    """
    Write text across rows of three columns.

    Example:

        ABC
        DEF
        GHI

    order 231 produces:

        BEH
        CFI
        ADG

    Result:

        BEHCFIADG
    """

    validate_base36(
        text,
        "transposition input"
    )

    if order not in TRANSPOSITION_ORDERS:
        raise ValueError(
            f"Invalid transposition order: {order}"
        )

    if len(text) % 3 != 0:
        raise ValueError(
            "Transposition input length must be divisible by 3"
        )

    columns = [
        text[0::3],
        text[1::3],
        text[2::3],
    ]

    output = []

    for digit in order:

        column_index = int(digit) - 1

        output.append(
            columns[column_index]
        )

    return "".join(output)


def reverse_three_columns(text, order):
    """
    Reverse the three-column transposition.
    """

    validate_base36(
        text,
        "transposed ciphertext"
    )

    if order not in TRANSPOSITION_ORDERS:
        raise ValueError(
            f"Invalid transposition order: {order}"
        )

    if len(text) % 3 != 0:
        raise ValueError(
            "Transposed ciphertext length must be divisible by 3"
        )

    rows = len(text) // 3

    columns = [
        None,
        None,
        None,
    ]

    position = 0

    # Split transmitted ciphertext back into columns
    # according to the transmitted order.
    for digit in order:

        column_index = int(digit) - 1

        columns[column_index] = text[
            position:
            position + rows
        ]

        position += rows

    output = []

    # Rebuild original row order.
    for row in range(rows):

        output.append(
            columns[0][row]
        )

        output.append(
            columns[1][row]
        )

        output.append(
            columns[2][row]
        )

    return "".join(output)


# ============================================================
# KEY SPLITTING
# ============================================================

def split_key(key):
    """
    Split K into two additive Base-36 shares.

        Y1 = random

        Y2 = K - Y1 mod 36

    Therefore:

        K = Y1 + Y2 mod 36
    """

    validate_base36(
        key,
        "key"
    )

    y1 = random_base36(
        len(key)
    )

    y2 = subtract_mod36(
        key,
        y1,
    )

    return y1, y2


def reconstruct_key(y1, y2):
    """
    Reconstruct K from the two additive shares.

        K = Y1 + Y2 mod 36
    """

    return add_mod36(
        y1,
        y2,
    )


# ============================================================
# ENCRYPTION
# ============================================================

def encrypt_message(plaintext):
    """
    Complete encryption pipeline.

        plaintext
            |
            v
        prepare
            |
            v
        random padding
            |
            v
        fresh key K
            |
            v
        P + K mod 36
            |
            v
        3-column transposition
            |
            v
        split K into Y1 + Y2

    Returns:

        payload_a
        payload_b
    """

    # --------------------------------------------------------
    # Prepare plaintext
    # --------------------------------------------------------

    prepared = prepare_plaintext(
        plaintext
    )

    # --------------------------------------------------------
    # Random padding
    # --------------------------------------------------------

    padded, pad_count = add_padding(
        prepared
    )

    # --------------------------------------------------------
    # Fresh full-length key
    # --------------------------------------------------------

    key = generate_key(
        len(padded)
    )

    # --------------------------------------------------------
    # Mod-36 encryption
    #
    # C = P + K mod 36
    # --------------------------------------------------------

    raw_ciphertext = add_mod36(
        padded,
        key,
    )

    # --------------------------------------------------------
    # Random transposition
    # --------------------------------------------------------

    order = generate_transposition_order()

    ciphertext = transpose_three_columns(
        raw_ciphertext,
        order,
    )

    # --------------------------------------------------------
    # Split key
    # --------------------------------------------------------

    y1, y2 = split_key(
        key
    )

    # --------------------------------------------------------
    # Relay A payload
    # --------------------------------------------------------

    payload_a = {
        "version": CIPHER_VERSION,
        "codec": CODEC_ID,
        "ciphertext": ciphertext,
        "y1": y1,
        "order": order,
        "pad": pad_count,
    }

    # --------------------------------------------------------
    # Relay B payload
    # --------------------------------------------------------

    payload_b = {
        "version": CIPHER_VERSION,
        "codec": CODEC_ID,
        "y2": y2,
    }

    return payload_a, payload_b


# ============================================================
# DECRYPTION
# ============================================================

def decrypt_message(payload_a, payload_b):
    """
    Complete receive pipeline.

        A + B
          |
          v
      reconstruct K
          |
          v
      reverse transposition
          |
          v
      C - K mod 36
          |
          v
      remove padding
          |
          v
      decode escapes
          |
          v
       plaintext
    """

    if not isinstance(payload_a, dict):
        raise TypeError(
            "payload_a must be a dictionary"
        )

    if not isinstance(payload_b, dict):
        raise TypeError(
            "payload_b must be a dictionary"
        )

    # --------------------------------------------------------
    # Protocol version
    # --------------------------------------------------------

    version_a = payload_a.get(
        "version"
    )

    version_b = payload_b.get(
        "version"
    )

    if version_a != version_b:
        raise ValueError(
            f"Cipher version mismatch between relays: {version_a} vs {version_b}"
        )

    if version_a not in (LEGACY_CIPHER_VERSION, CIPHER_VERSION):
        raise ValueError(
            f"Unsupported cipher version: {version_a}"
        )

    if version_a == CIPHER_VERSION:
        codec_a = payload_a.get("codec")
        codec_b = payload_b.get("codec")
        if codec_a != CODEC_ID or codec_b != CODEC_ID:
            raise ValueError(
                f"Unsupported or mismatched plaintext codec: {codec_a!r} / {codec_b!r}"
            )

    # --------------------------------------------------------
    # Extract fields
    # --------------------------------------------------------

    ciphertext = payload_a.get(
        "ciphertext"
    )

    y1 = payload_a.get(
        "y1"
    )

    order = payload_a.get(
        "order"
    )

    pad_count = payload_a.get(
        "pad"
    )

    y2 = payload_b.get(
        "y2"
    )

    # --------------------------------------------------------
    # Basic validation
    # --------------------------------------------------------

    if ciphertext is None:
        raise ValueError(
            "Relay A payload missing ciphertext"
        )

    if y1 is None:
        raise ValueError(
            "Relay A payload missing Y1"
        )

    if order is None:
        raise ValueError(
            "Relay A payload missing transposition order"
        )

    if pad_count is None:
        raise ValueError(
            "Relay A payload missing padding count"
        )

    if y2 is None:
        raise ValueError(
            "Relay B payload missing Y2"
        )

    validate_base36(
        ciphertext,
        "ciphertext"
    )

    validate_base36(
        y1,
        "Y1"
    )

    validate_base36(
        y2,
        "Y2"
    )

    if not (
        len(ciphertext)
        == len(y1)
        == len(y2)
    ):
        raise ValueError(
            "Ciphertext, Y1, and Y2 lengths do not match"
        )

    # --------------------------------------------------------
    # Reconstruct full one-time key
    #
    # K = Y1 + Y2 mod 36
    # --------------------------------------------------------

    key = reconstruct_key(
        y1,
        y2,
    )

    # --------------------------------------------------------
    # Reverse transposition
    # --------------------------------------------------------

    raw_ciphertext = reverse_three_columns(
        ciphertext,
        order,
    )

    # --------------------------------------------------------
    # Decrypt
    #
    # P = C - K mod 36
    # --------------------------------------------------------

    padded_plaintext = subtract_mod36(
        raw_ciphertext,
        key,
    )

    # --------------------------------------------------------
    # Remove random padding
    # --------------------------------------------------------

    prepared_plaintext = remove_padding(
        padded_plaintext,
        pad_count,
    )

    # --------------------------------------------------------
    # Decode plaintext representation
    #
    # V2: UTF-8 bytes encoded as fixed-width Base-36 pairs.
    # V1: legacy uppercase/escape codec, accepted for migration.
    # --------------------------------------------------------

    if version_a == CIPHER_VERSION:
        plaintext = decode_prepared(
            prepared_plaintext
        )
    else:
        plaintext = legacy_decode_prepared(
            prepared_plaintext
        )

    return plaintext


# ============================================================
# PUBLIC WRAPPERS
# ============================================================

def encode_message(plaintext):
    """
    Public sender interface.

    Client.py should call:

        payload_a, payload_b = encode_message(message)
    """

    return encrypt_message(
        plaintext
    )


def decode_message(payload_a, payload_b):
    """
    Public receiver interface.

    Client.py should call:

        message = decode_message(payload_a, payload_b)
    """

    return decrypt_message(
        payload_a,
        payload_b,
    )


# ============================================================
# SELF TEST
# ============================================================

if __name__ == "__main__":

    print()
    print("=" * 60)
    print(" Base36 Cipher Engine Self-Test")
    print("=" * 60)
    print()

    test_messages = [
        "Hello Bob",
        "Meet me at 8:30.",
        "Steve != steve",
        "Coffee first ☕",
        "José — hello!",
        "こんにちは 👍🏽",
        "Family 👨‍👩‍👧‍👦",
    ]

    for original in test_messages:

        print(
            f"PLAINTEXT : {original}"
        )

        payload_a, payload_b = encode_message(
            original
        )

        print(
            f"ORDER     : {payload_a['order']}"
        )

        print(
            f"PAD       : {payload_a['pad']}"
        )

        print(
            f"CIPHERTEXT: {payload_a['ciphertext']}"
        )

        print(
            f"Y1        : {payload_a['y1']}"
        )

        print(
            f"Y2        : {payload_b['y2']}"
        )

        recovered = decode_message(
            payload_a,
            payload_b,
        )

        print(
            f"RECOVERED : {recovered}"
        )

        if recovered == original:

            print(
                "STATUS    : PASS"
            )

        else:

            print(
                "STATUS    : FAIL"
            )

        print("-" * 60)

    print()