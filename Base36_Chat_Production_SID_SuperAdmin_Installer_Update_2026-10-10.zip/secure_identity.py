"""Identity compatibility layer with Windows-user DPAPI protection.

Development builds use the existing identity.py storage unchanged.
Production builds migrate/create the private Ed25519 key as a DPAPI blob tied
to the signed-in Windows user. Public keys remain ordinary public PEM files.
"""

from __future__ import annotations

from pathlib import Path

from cryptography.hazmat.primitives import serialization

import identity as legacy_identity
from deployment import runtime
from dpapi import protect_bytes, unprotect_bytes

IDENTITY_DIR = legacy_identity.IDENTITY_DIR


def _refresh_dir() -> Path:
    global IDENTITY_DIR
    IDENTITY_DIR = runtime().identity_dir
    legacy_identity.IDENTITY_DIR = IDENTITY_DIR
    IDENTITY_DIR.mkdir(parents=True, exist_ok=True)
    return IDENTITY_DIR


def _legacy_private_path(profile_id: str) -> Path:
    return _refresh_dir() / f"{profile_id}_private.pem"


def _protected_private_path(profile_id: str) -> Path:
    return _refresh_dir() / f"{profile_id}_private.dpapi"


def _public_path(profile_id: str) -> Path:
    return _refresh_dir() / f"{profile_id}_public.pem"


def private_identity_exists(profile_id: str) -> bool:
    if runtime().production:
        return _protected_private_path(profile_id).exists() or _legacy_private_path(profile_id).exists()
    return _legacy_private_path(profile_id).exists()


def public_identity_exists(profile_id: str) -> bool:
    return _public_path(profile_id).exists()


def list_identity_ids() -> list[str]:
    root = _refresh_dir()
    result = set()
    for path in root.glob("*_public.pem"):
        profile_id = path.name[:-len("_public.pem")]
        if private_identity_exists(profile_id):
            result.add(profile_id)
    return sorted(result)


def _serialize_private(private_key) -> bytes:
    return private_key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption(),
    )


def _protect_private_key(profile_id: str, private_key) -> None:
    raw = _serialize_private(private_key)
    protected = protect_bytes(raw)
    target = _protected_private_path(profile_id)
    temp = target.with_suffix(target.suffix + ".tmp")
    temp.write_bytes(protected)
    temp.replace(target)

    legacy_path = _legacy_private_path(profile_id)
    if legacy_path.exists():
        legacy_path.unlink()


def create_identity(profile_id):
    _refresh_dir()
    private_key, public_key = legacy_identity.create_identity(profile_id)
    if runtime().production:
        _protect_private_key(profile_id, private_key)
    return private_key, public_key


def load_private_identity(profile_id):
    _refresh_dir()

    if runtime().production:
        protected_path = _protected_private_path(profile_id)
        if protected_path.exists():
            raw = unprotect_bytes(protected_path.read_bytes())
            try:
                return serialization.load_pem_private_key(raw, password=None)
            finally:
                # Python cannot guarantee forensic zeroization, but avoid
                # retaining an intentional extra reference longer than needed.
                del raw

        # One-time production migration of a legacy unprotected private PEM.
        legacy_path = _legacy_private_path(profile_id)
        if legacy_path.exists():
            private_key = legacy_identity.load_private_identity(profile_id)
            _protect_private_key(profile_id, private_key)
            return private_key

        raise FileNotFoundError(f"Private identity not found for {profile_id}")

    return legacy_identity.load_private_identity(profile_id)


def load_public_identity(profile_id):
    _refresh_dir()
    return legacy_identity.load_public_identity(profile_id)


# Pass-through helpers used elsewhere in the project.
fingerprint = legacy_identity.fingerprint
format_fingerprint = legacy_identity.format_fingerprint
public_key_b64 = legacy_identity.public_key_b64
public_key_from_b64 = legacy_identity.public_key_from_b64
