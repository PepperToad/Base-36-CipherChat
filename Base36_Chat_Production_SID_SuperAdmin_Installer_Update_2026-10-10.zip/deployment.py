"""Deployment/runtime boundary for Base36 Chat.

Production:
- one Base36 identity is bound to the currently signed-in Windows SID;
- state lives under that Windows user's LocalAppData;
- the packaged EXE never exposes the development profile chooser.

Development:
- existing multi-profile behavior is retained for local testing.
"""

from __future__ import annotations

import ctypes
import hashlib
import json
import os
import sys
from dataclasses import dataclass
from pathlib import Path
from ctypes import wintypes

APP_DIR_NAME = "Base36Chat"
BINDING_VERSION = 1


@dataclass(frozen=True)
class RuntimeState:
    production: bool
    data_dir: Path
    identity_dir: Path
    profile_file: Path
    binding_file: Path
    authority_dir: Path


_RUNTIME: RuntimeState | None = None


def is_frozen() -> bool:
    return bool(getattr(sys, "frozen", False))


def development_requested() -> bool:
    # A frozen production EXE intentionally ignores environment switches.
    if is_frozen():
        return False
    return os.environ.get("BASE36_DEV_MODE") == "1"


def _source_dir() -> Path:
    return Path(__file__).resolve().parent


def _local_app_data() -> Path:
    value = os.environ.get("LOCALAPPDATA")
    if not value:
        if os.name == "nt":
            raise RuntimeError("LOCALAPPDATA is unavailable")
        return Path.home() / ".local" / "share"
    return Path(value)


def initialize_runtime(force_development: bool | None = None) -> RuntimeState:
    global _RUNTIME
    if _RUNTIME is not None:
        return _RUNTIME

    if force_development is None:
        development = development_requested()
    else:
        # Never permit a caller to turn a frozen production binary into dev mode.
        development = bool(force_development) and not is_frozen()

    production = not development

    if production:
        data_dir = _local_app_data() / APP_DIR_NAME
    else:
        # Preserve the current loose-file development layout.
        data_dir = _source_dir()

    identity_dir = data_dir / "identity"
    authority_dir = data_dir / "authority"
    data_dir.mkdir(parents=True, exist_ok=True)
    identity_dir.mkdir(parents=True, exist_ok=True)
    authority_dir.mkdir(parents=True, exist_ok=True)

    _RUNTIME = RuntimeState(
        production=production,
        data_dir=data_dir,
        identity_dir=identity_dir,
        profile_file=data_dir / "profiles.json",
        binding_file=data_dir / "binding.json",
        authority_dir=authority_dir,
    )

    # Patch the legacy identity module before profiles/engine import constants
    # from it. Existing identity functions normally reference this module global.
    try:
        import identity
        identity.IDENTITY_DIR = identity_dir
    except Exception:
        # app.py may be syntax-checked in a partial source bundle without the
        # legacy identity module. The actual application still requires it.
        pass

    return _RUNTIME


def runtime() -> RuntimeState:
    return _RUNTIME or initialize_runtime()


def current_windows_sid() -> str:
    """Return the current process token SID as a stable Windows account identity."""
    if os.name != "nt":
        # Development/testing only. Production startup rejects non-Windows.
        return f"NONWINDOWS:{os.getuid() if hasattr(os, 'getuid') else 'unknown'}"

    TOKEN_QUERY = 0x0008
    TokenUser = 1

    advapi32 = ctypes.windll.advapi32
    kernel32 = ctypes.windll.kernel32

    token = wintypes.HANDLE()
    if not advapi32.OpenProcessToken(
        kernel32.GetCurrentProcess(), TOKEN_QUERY, ctypes.byref(token)
    ):
        raise ctypes.WinError()

    try:
        needed = wintypes.DWORD(0)
        advapi32.GetTokenInformation(token, TokenUser, None, 0, ctypes.byref(needed))
        if not needed.value:
            raise ctypes.WinError()

        buf = ctypes.create_string_buffer(needed.value)
        if not advapi32.GetTokenInformation(
            token, TokenUser, buf, needed, ctypes.byref(needed)
        ):
            raise ctypes.WinError()

        # TOKEN_USER begins with SID_AND_ATTRIBUTES; its first field is PSID.
        sid_ptr = ctypes.cast(buf, ctypes.POINTER(ctypes.c_void_p))[0]
        sid_string = wintypes.LPWSTR()
        if not advapi32.ConvertSidToStringSidW(sid_ptr, ctypes.byref(sid_string)):
            raise ctypes.WinError()
        try:
            return sid_string.value
        finally:
            kernel32.LocalFree(sid_string)
    finally:
        kernel32.CloseHandle(token)


def sid_fingerprint(sid: str | None = None) -> str:
    sid = sid or current_windows_sid()
    return hashlib.sha256(sid.encode("utf-8")).hexdigest()[:16]


class ProductionBinding:
    """Local SID -> immutable Base36 user binding.

    This file is local endpoint state only and is never sent to a relay.
    """

    def __init__(self, path: Path | None = None):
        self.path = Path(path or runtime().binding_file)

    def load(self) -> dict | None:
        if not self.path.exists():
            return None
        try:
            doc = json.loads(self.path.read_text(encoding="utf-8"))
        except Exception as exc:
            raise ValueError("Base36 installation binding is unreadable") from exc
        if doc.get("version") != BINDING_VERSION:
            raise ValueError("Unsupported Base36 installation binding version")
        if not isinstance(doc.get("windows_sid"), str) or not isinstance(doc.get("user_id"), str):
            raise ValueError("Invalid Base36 installation binding")
        return doc

    def require_current_user(self) -> dict:
        doc = self.load()
        if doc is None:
            raise FileNotFoundError("This Windows user has not provisioned Base36 Chat")
        current = current_windows_sid()
        if doc["windows_sid"] != current:
            raise PermissionError(
                "This Base36 identity belongs to a different Windows account. "
                "Sign in to Windows with the account that owns this identity."
            )
        return doc

    def bind(self, user_id: str, *, overwrite: bool = False) -> dict:
        if runtime().production and os.name != "nt":
            raise RuntimeError("Production identity binding requires Windows")
        existing = self.load()
        if existing is not None and not overwrite:
            raise FileExistsError("This Windows account is already bound to a Base36 identity")

        doc = {
            "version": BINDING_VERSION,
            "windows_sid": current_windows_sid(),
            "sid_tag": sid_fingerprint(),
            "user_id": str(user_id).strip().lower(),
        }
        self.path.parent.mkdir(parents=True, exist_ok=True)
        temp = self.path.with_suffix(".tmp")
        temp.write_text(json.dumps(doc, indent=2, sort_keys=True), encoding="utf-8")
        temp.replace(self.path)
        return doc
