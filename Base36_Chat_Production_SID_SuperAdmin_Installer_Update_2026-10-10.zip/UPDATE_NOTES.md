# Base36 Cipher Chat — Secure Comfort Update — 2026-08-19

This package extends the working Unicode/display-name build with the security hardening and user-comfort features selected after live testing.

## Critical architecture change: no message queue

The GUI engine no longer contains `PendingSendQueue`, `pending_sends`, or a queued-message flush path. A message is sent immediately or discarded. If a secure session is not ready, Base36 Chat starts the session but tells the user to send the message again after the contact shows **Secure**. If either relay is unavailable or the immediate network send fails, the message is not retained for retry.

The included `relay.py` is Relay Protocol 2 with `queue_mode = "none"`. It does not keep payloads for offline recipients. An offline recipient causes immediate rejection. For a connected recipient, the relay forwards the opaque payload immediately and temporarily retains only receipt metadata (message ID, sender routing ID, recipient routing ID, monotonic creation time) until ACK/timeout.

The updated client refuses an older relay that does not advertise Relay Protocol 2 and no-queue mode. **Both VM relay instances must be updated before the desktop clients are used.**

## Transport and protocol hardening

- Automatic reconnection for Relay A and Relay B with bounded exponential backoff.
- Reconnection never resends an old message.
- Maximum plaintext size: 32 KiB UTF-8.
- Maximum WebSocket packet size: 512 KiB.
- Strict registration capability check for no-queue mode.
- Malformed JSON, invalid packet types, invalid user/message IDs, channel substitution, oversized packets, and incomplete dual-relay state are rejected/bounded.
- Incomplete A/B assemblers expire after 30 seconds and are capped at 256 entries.
- Relay has a simple per-connection rate limit and bounded inflight receipt metadata.
- Duplicate simultaneous connections using the same user ID are rejected by the relay.
- Active secure sessions expire after 30 minutes of inactivity and are re-established when needed.
- Client/peer protocol version differences surface as a UI warning.

## Delivery status

Outgoing messages may show:

- `sending` — visible ephemeral GUI record created while immediate transport is attempted.
- `sent` — both transport sends completed / relay acceptance is being tracked.
- `delivered` — both relay paths received the recipient protocol ACK.
- `sent • delivery unconfirmed` — receipt state expired without a complete dual-relay delivery confirmation.

A relay rejection or transport failure removes the failed outgoing plaintext from the in-memory conversation and leaves only a system failure notice. There is no automatic retry.

## Signed contact invitations

- **My Invite** generates a signed `B36C1-...` invitation code.
- The invitation contains only user ID, display name, Ed25519 public identity, client protocol version, and signature.
- Optional QR rendering/saving is supported when `qrcode` and Pillow are installed.
- **Paste Invite** imports a code from the clipboard.
- Add Contact accepts either a permanent user ID or invitation code.
- Invitation signatures are verified before pinning.
- A conflicting identity for an already-pinned user ID triggers the existing hard security lock.
- No central user directory/database was added.

## Contact/UI comfort features

- In-memory unread counters.
- Generated two-character initials in the sidebar.
- Duplicate names continue to get a short ID suffix; local aliases remain local-only.
- Right-click contact menu: Open, Rename local label, View identity details, Copy User ID, Copy fingerprint, Remove contact.
- Contact Details shows local/remote names, user ID, trust state, fingerprint, and current session ID when active.
- `Ctrl+K` contact search/switcher.
- Remote editable display-name behavior from the previous update remains signed and bound to the immutable user ID/key.

## Conversation/composer comfort features

- Right-click message menu: Reply, Copy message, Copy selected text.
- Reply-to-message adds a short quote inside the new encrypted message.
- `Ctrl+F` searches only the current in-memory conversation.
- Auto-growing composer from 2 to 6 rows.
- Message-size indicator appears near the 32 KiB limit.
- Enter-to-send preference; Shift+Enter inserts newline. When Enter-to-send is disabled, Ctrl+Enter sends.
- Memory-only recently used emoji; ☕ remains the first permanent quick emoji.
- Existing `:coffee:`, `:)`, `:(`, `;)`, `:D`, `:P`, `<3` shortcuts can be disabled in Settings.

## Appearance, notifications, and settings

New `settings.py` stores local-only UI preferences in `settings_<user_id>.json`. No message text is stored there.

Settings include:

- light/dark appearance;
- font size;
- compact/comfortable spacing;
- Enter-to-send;
- emoji shortcuts;
- normal message sound;
- distinct security-warning sound;
- notification privacy: off, generic, or sender-name.

The app deliberately does not write plaintext previews into Windows notification history. It uses local status text, taskbar flashing, and optional sound instead.

## Emergency Lock

**Emergency Lock** / `Ctrl+Shift+L`:

- clears the composer;
- clears current in-memory conversation structures and unread counts;
- clears the app clipboard where possible;
- disconnects/stops the engine;
- closes the chat window;
- closes the production client; only the development harness returns to its test profile chooser.

This minimizes deliberate application retention but is not a forensic RAM-zeroization guarantee. Python, the OS pagefile, screenshots, crash infrastructure, and compromised endpoints remain outside deterministic application control.

## Features intentionally not added

- No plaintext retry queue.
- No relay offline mailbox/store-and-forward.
- No persistent conversation database.
- No read receipts or last-seen history.
- No typing indicator.
- No persistent presence history.
- No analytics/advertising telemetry.
- No central email/phone/user directory.
- No built-in VPN/Tor/IP-hiding claim.
- No local PIN lock yet; a GUI PIN would create misleading protection until long-term identity-key-at-rest protection is addressed separately.

## Existing security behavior retained

- UTF-8/Base36 v2 case/punctuation/emoji support.
- Fresh full-length Base36 per-message key.
- Mod-36 cipher math unchanged.
- Three-column transposition and additive Y1/Y2 split unchanged.
- Ed25519 identities and X25519/HKDF authenticated sessions.
- HMAC channel/integrity binding.
- Replay protection.
- Immutable user ID and editable signed display name.
- Local-only contact aliases.
- Pinned-key continuity and hard lock on unexpected key changes.
- Administrator-only identity replacement/revocation.

## Automated tests run in this package

`security_self_test.py` passed all tests in `TEST_RESULTS.txt`, including syntax compilation, Unicode/case/emoji cipher round trips, settings persistence with no test message content, static absence of the old GUI plaintext queue, offline relay rejection with zero inflight payload state, metadata-only ACK tracking, online immediate forwarding, delivered receipts, duplicate-ID rejection, and malformed-JSON rejection.

## Live tests to run after deployment

1. Replace/restart both VM relays and confirm the client shows `Both relays connected • no-queue mode`.
2. With Frank offline, try to send. The relay should reject delivery and the message must not appear later when Frank connects.
3. With both users online and Secure, send `Coffee at 06:30? ☕` and verify `delivered`.
4. Stop Relay A, confirm automatic reconnect begins, and verify the app refuses a new send while both relays are not available.
5. Restart Relay A, wait for both relay indicators, re-establish Secure if required, then manually send a new message. The earlier failed message must not reappear.
6. Test invitation code/QR exchange, duplicate display names/local aliases, display-name changes, unread counts, reply, search, settings, and Emergency Lock.
7. Repeat the intentional identity-key-change test and confirm standard users still have no override.

## Important `client.py` note

The desktop engine imports only `SessionManager` from the existing `client.py`. The current `client.py` file was not supplied as part of this update, and older development CLI versions contain their own plaintext queue code. **Do not use the old command-line `/send` client if no-queue behavior is a hard requirement.** Upload the current `client.py` if you want the development CLI brought under the same no-queue policy.
