@echo off
setlocal
cd /d "%~dp0"

echo ============================================================
echo  Base36 Chat - Production Windows Build
echo ============================================================
echo.

where py >nul 2>nul
if errorlevel 1 (
  echo ERROR: Python launcher "py" was not found.
  exit /b 1
)

if not exist identity.py (
  echo ERROR: This update bundle contains replacement/new files only.
  echo Copy it into the COMPLETE Base36 Chat source tree first.
  echo Missing required source file: identity.py
  exit /b 1
)
if not exist session.py (
  echo ERROR: Missing required source file: session.py
  exit /b 1
)
if not exist client.py (
  echo ERROR: Missing required source file: client.py
  exit /b 1
)
if not exist auth.py (
  echo ERROR: Missing required source file: auth.py
  exit /b 1
)
if not exist replay.py (
  echo ERROR: Missing required source file: replay.py
  exit /b 1
)
if not exist security_admin.py (
  echo ERROR: Missing required source file: security_admin.py
  exit /b 1
)

echo [1/4] Creating build environment...
py -m venv .build-venv
if errorlevel 1 exit /b 1
call .build-venv\Scripts\activate.bat

python -m pip install --upgrade pip
if errorlevel 1 exit /b 1
python -m pip install -r requirements-build.txt
if errorlevel 1 exit /b 1

echo [2/4] Running security/foundation tests...
python -m unittest -v test_production_foundation.py
if errorlevel 1 exit /b 1
if exist security_self_test.py (
  python security_self_test.py
  if errorlevel 1 exit /b 1
)

echo [3/4] Building windowed production application...
if exist build rmdir /s /q build
if exist dist\Base36Chat rmdir /s /q dist\Base36Chat
pyinstaller --noconfirm --clean --windowed --onedir --name Base36Chat app.py
if errorlevel 1 exit /b 1

echo [4/4] Building installer...
set "ISCC=%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe"
if not exist "%ISCC%" set "ISCC=%ProgramFiles%\Inno Setup 6\ISCC.exe"
if not exist "%ISCC%" (
  echo.
  echo PyInstaller build succeeded:
  echo   %CD%\dist\Base36Chat\Base36Chat.exe
  echo.
  echo Inno Setup 6 was not found. Install Inno Setup, then run:
  echo   installer\build_installer.bat
  exit /b 0
)

"%ISCC%" installer\Base36Chat.iss
if errorlevel 1 exit /b 1

echo.
echo BUILD COMPLETE
echo Production EXE: dist\Base36Chat\Base36Chat.exe
echo Installer:      installer_output\Base36Chat-Setup.exe
exit /b 0
