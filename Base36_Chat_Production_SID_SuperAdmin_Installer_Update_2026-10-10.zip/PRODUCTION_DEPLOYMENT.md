# Base36 Chat Production Deployment Foundation

## Production identity boundary

The installed application is machine-wide, but identity state is **per signed-in Windows user**.

- Program: `C:\Program Files\Base36 Chat\Base36Chat.exe`
- User state: `%LOCALAPPDATA%\Base36Chat\`
- Binding: `%LOCALAPPDATA%\Base36Chat\binding.json`
- Identity keys: `%LOCALAPPDATA%\Base36Chat\identity\`
- Authority state: `%LOCALAPPDATA%\Base36Chat\authority\`

The binding records the immutable Base36 user ID and the Windows SID that owns it. The Windows account name is not used as the security identifier and does not need to leave the endpoint.

A production client does not expose the development profile chooser and rejects `--id`. If James signs in to Windows as `James.Smith`, he receives James's LocalAppData and Base36 binding. He cannot select Joel's Base36 identity from the application.

## Private-key protection

Production private Ed25519 identity material is stored as a Windows DPAPI blob tied to the current Windows user. A legacy private PEM encountered during production startup is migrated to DPAPI storage and the legacy private PEM is removed.

DPAPI and SID binding are endpoint controls. They do not claim to defeat malware or an attacker that already has sufficient Windows privileges.

## Development build

The development harness remains available as:

```bat
Run-Development.bat
```

or:

```bat
python app_dev.py
```

Development mode retains the multi-profile chooser for test traffic. `app_dev.py` is deliberately not included as an entry point in the production installer.

## Administrative authority

Production roles are not trusted from editable profile JSON.

Roles are:

- `user`
- `administrator`
- `super_administrator`

The first person creating a **new Base36 environment** creates a dedicated Ed25519 administrative authority key. Its private key is DPAPI-protected on the Super Administrator endpoint. Other users join the environment by importing a signed environment invitation containing the authority public key.

Only the Super Administrator can issue signed role statements. Granting Administrator sends a signed statement through both relays. Revoking Administrator sends a newer signed `user` statement. Old/replayed statements cannot replace a newer local sequence.

Role authority never grants access to chat private keys or message plaintext and never permits impersonation of another Base36 identity.

Because Base36 intentionally has no central account database or offline role mailbox, a recipient must be online to receive a role update through the relays. The environment invitation itself is designed for trusted out-of-band transfer.

## Installer build

Copy this update into the **complete current source tree** first. The build script checks for required modules such as `identity.py`, `session.py`, `client.py`, `auth.py`, `replay.py`, and `security_admin.py` rather than pretending the replacement bundle is a full repository.

On Windows:

```bat
build_windows.bat
```

This creates a PyInstaller windowed onedir build and, when Inno Setup 6 is installed, creates:

```text
installer_output\Base36Chat-Setup.exe
```

The installer installs one application machine-wide. Each Windows user provisions only their own Base36 identity on first launch.
