import asyncio
import base64
import json
import re
import time
import uuid

from websockets.asyncio.client import connect
from websockets.exceptions import ConnectionClosed

from cipher import encode_message, decode_message
from auth import authenticate_payload, verify_authenticated_payload
from replay import ReplayProtector, create_replay_metadata, validate_replay_metadata
from secure_identity import (
    load_private_identity,
    format_fingerprint,
    public_key_b64,
    public_key_from_b64,
    fingerprint,
)
from session import (
    make_confirmation,
    verify_confirmation,
    sign_document,
    verify_document,
    validate_timestamp,
)
from contacts import (
    ContactStore,
    format_fingerprint_text,
    STATUS_PINNED,
    STATUS_LOCKED,
    STATUS_REVOKED,
)
from profiles import ProfileStore, normalize_display_name
from deployment import runtime
from authority import (
    AuthorityStore,
    ROLE_USER,
    ROLE_ADMIN,
    ROLE_SUPER_ADMIN,
)
from security_admin import SecurityAdmin
from endpoint_admin import EndpointSecurityAdmin
from client import SessionManager


RELAY_A = "ws://34.10.22.176:80"
RELAY_B = "ws://34.10.22.176:443"

CLIENT_PROTOCOL_VERSION = 3
RELAY_PROTOCOL_VERSION = 2
INVITE_PROTOCOL = "BASE36-INVITE-V1"
INVITE_PREFIX = "B36C1-"
MAX_MESSAGE_UTF8_BYTES = 32 * 1024
MAX_WS_MESSAGE_BYTES = 512 * 1024
ASSEMBLY_TTL_SECONDS = 30
MAX_PENDING_ASSEMBLIES = 256
SESSION_IDLE_SECONDS = 30 * 60
RECEIPT_TTL_SECONDS = 90
RECONNECT_MIN_SECONDS = 1
RECONNECT_MAX_SECONDS = 30
CLIENT_ID_RE = re.compile(r"^[a-z0-9_-]{1,64}$")


class ExpiringDualAssembler:
    """Pair A/B copies in RAM briefly, then discard incomplete state."""

    def __init__(self, ttl_seconds=ASSEMBLY_TTL_SECONDS, max_pending=MAX_PENDING_ASSEMBLIES):
        self.pending = {}
        self.lock = asyncio.Lock()
        self.ttl_seconds = ttl_seconds
        self.max_pending = max_pending

    async def _purge_locked(self):
        now = time.monotonic()
        stale = [
            message_id
            for message_id, entry in self.pending.items()
            if now - entry.get("created", now) >= self.ttl_seconds
        ]
        for message_id in stale:
            self.pending.pop(message_id, None)

    async def purge(self):
        async with self.lock:
            await self._purge_locked()

    async def add(self, channel, message_id, value):
        async with self.lock:
            await self._purge_locked()

            if message_id not in self.pending and len(self.pending) >= self.max_pending:
                raise ValueError("Too many incomplete dual-relay packets")

            entry = self.pending.setdefault(
                message_id,
                {"created": time.monotonic(), "halves": {}},
            )
            halves = entry["halves"]
            if channel in halves:
                return None
            halves[channel] = value

            if "A" not in halves or "B" not in halves:
                return None

            self.pending.pop(message_id, None)
            return halves


class MessageAssembler(ExpiringDualAssembler):
    async def add_half(
        self,
        channel,
        websocket,
        message_id,
        sender,
        session_id,
        cipher_body,
        replay_metadata,
    ):
        return await self.add(
            channel,
            message_id,
            {
                "websocket": websocket,
                "sender": sender,
                "session_id": session_id,
                "cipher": cipher_body,
                "replay": replay_metadata,
            },
        )


class DualControlAssembler(ExpiringDualAssembler):
    """Require identical copies of onboarding/profile controls from both relays."""

    async def add(self, channel, websocket, message_id, sender, payload):
        return await super().add(
            channel,
            message_id,
            {
                "websocket": websocket,
                "sender": sender,
                "payload": payload,
            },
        )


class ControlTracker:
    def __init__(self):
        self.processing = set()
        self.completed = {}
        self.lock = asyncio.Lock()

    async def _purge_locked(self):
        cutoff = time.monotonic() - ASSEMBLY_TTL_SECONDS
        for message_id, completed_at in list(self.completed.items()):
            if completed_at < cutoff:
                self.completed.pop(message_id, None)

    async def claim(self, message_id):
        async with self.lock:
            await self._purge_locked()
            if message_id in self.completed or message_id in self.processing:
                return False
            self.processing.add(message_id)
            return True

    async def finish(self, message_id, success):
        async with self.lock:
            self.processing.discard(message_id)
            if success:
                self.completed[message_id] = time.monotonic()

    async def purge(self):
        async with self.lock:
            await self._purge_locked()


class ChatEngine:
    """Async protocol engine with no GUI dependencies."""

    def __init__(
        self,
        client_id,
        event_sink=None,
        relay_a_uri=RELAY_A,
        relay_b_uri=RELAY_B,
    ):
        self.client_id = client_id.strip().lower()
        self.display_name = self.client_id
        self.event_sink = event_sink or (lambda event: None)
        self.relay_a_uri = relay_a_uri
        self.relay_b_uri = relay_b_uri

        self.identity_private = None
        self.identity_public = None
        self.contacts = None
        self.replay_protector = None
        self.session_manager = None

        self.relay_a = None
        self.relay_b = None
        self.listener_a = None
        self.listener_b = None
        self.relay_capabilities = {}

        self.assembler = MessageAssembler()
        self.contact_assembler = DualControlAssembler()
        self.control_tracker = ControlTracker()
        self.outbound_receipts = {}
        self.session_activity = {}
        self._all_relays_announced = False

        self.incoming_contact_requests = {}
        self.outgoing_contact_requests = {}
        self.profile_store = None
        self.authority_store = None
        self.user_role = ROLE_USER
        self.is_admin = False
        self.security_admin = None
        self.contact_watch_task = None
        self.maintenance_task = None

        self.started = False
        self.closing = False

    def emit(self, event_type, **data):
        event = {"type": event_type, **data}
        try:
            self.event_sink(event)
        except Exception:
            # UI/event reporting must never take down the protocol engine.
            pass

    def _contact_snapshot(self):
        if self.contacts is None:
            return []

        result = []
        for entry in self.contacts.list_contacts():
            status = entry.get(
                "status",
                STATUS_PINNED if entry.get("trusted") else "removed",
            )
            result.append({
                "name": entry["name"],
                "display_name": entry.get("display_name") or entry["name"],
                "local_alias": entry.get("local_alias"),
                "trusted": bool(entry.get("trusted")) and status == STATUS_PINNED,
                "status": status,
                "locked": status == STATUS_LOCKED,
                "revoked": status == STATUS_REVOKED,
                "fingerprint": format_fingerprint_text(entry["fingerprint"]),
                "presented_fingerprint": (
                    format_fingerprint_text(entry["presented_fingerprint"])
                    if entry.get("presented_fingerprint") else None
                ),
                "session_active": (
                    status == STATUS_PINNED
                    and self.session_manager is not None
                    and self.session_manager.session_for_peer(entry["name"]) is not None
                ),
                "session_id": (
                    self.session_manager.session_for_peer(entry["name"]).session_id
                    if status == STATUS_PINNED
                    and self.session_manager is not None
                    and self.session_manager.session_for_peer(entry["name"]) is not None
                    else None
                ),
            })
        return result

    def emit_contacts(self):
        self.emit("contacts", contacts=self._contact_snapshot())

    async def _register(self, uri, relay_name):
        websocket = await connect(
            uri,
            max_size=MAX_WS_MESSAGE_BYTES,
            ping_interval=20,
            ping_timeout=20,
            close_timeout=5,
            compression=None,
        )
        await websocket.send(json.dumps({
            "type": "register",
            "client_id": self.client_id,
            "client_protocol": CLIENT_PROTOCOL_VERSION,
            "requires_queue_mode": "none",
        }))

        raw = await asyncio.wait_for(websocket.recv(), timeout=10)
        response = json.loads(raw)
        if response.get("type") != "registered":
            await websocket.close()
            raise RuntimeError(f"{relay_name} registration failed: {response}")

        if response.get("queue_mode") != "none":
            await websocket.close()
            raise RuntimeError(
                f"{relay_name} does not advertise no-queue mode. "
                "Update relay.py before using this client."
            )

        relay_protocol = response.get("relay_protocol")
        if relay_protocol != RELAY_PROTOCOL_VERSION:
            await websocket.close()
            raise RuntimeError(
                f"{relay_name} protocol {relay_protocol!r} is incompatible "
                f"with required relay protocol {RELAY_PROTOCOL_VERSION}"
            )

        self.relay_capabilities[relay_name] = dict(response)
        return websocket

    def _both_relays_connected(self):
        return self.relay_a is not None and self.relay_b is not None

    async def _relay_supervisor(self, uri, relay_name, channel):
        attr = "relay_a" if channel == "A" else "relay_b"
        delay = RECONNECT_MIN_SECONDS

        while not self.closing:
            websocket = None
            try:
                self.emit(
                    "relay_status",
                    relay=relay_name,
                    connected=False,
                    reconnecting=True,
                )
                websocket = await self._register(uri, relay_name)
                setattr(self, attr, websocket)
                delay = RECONNECT_MIN_SECONDS
                self.emit(
                    "relay_status",
                    relay=relay_name,
                    connected=True,
                    reconnecting=False,
                )

                if self._both_relays_connected():
                    self.emit("ready")
                    if not self._all_relays_announced:
                        self._all_relays_announced = True
                        for entry in self.contacts.list_contacts():
                            if entry.get("status") == STATUS_PINNED and entry.get("trusted"):
                                asyncio.create_task(
                                    self._best_effort_profile_update(entry["name"])
                                )

                await self._listen(websocket, relay_name, channel)

            except asyncio.CancelledError:
                raise
            except Exception as exc:
                if not self.closing:
                    self.emit(
                        "relay_status",
                        relay=relay_name,
                        connected=False,
                        reconnecting=True,
                    )
                    self.emit(
                        "transport_notice",
                        message=f"{relay_name} unavailable; reconnecting automatically",
                        detail=str(exc),
                    )
            finally:
                if getattr(self, attr) is websocket:
                    setattr(self, attr, None)
                if websocket is not None:
                    try:
                        await websocket.close()
                    except Exception:
                        pass
                if not self.closing:
                    self.emit(
                        "relay_status",
                        relay=relay_name,
                        connected=False,
                        reconnecting=True,
                    )

            if self.closing:
                break
            await asyncio.sleep(delay)
            delay = min(delay * 2, RECONNECT_MAX_SECONDS)

    async def start(self):
        if self.started:
            return

        self.closing = False
        try:
            self.profile_store = ProfileStore()
            profile = self.profile_store.get_profile(self.client_id)
            if profile is None:
                raise ValueError(f"Unknown local profile: {self.client_id}")

            self.display_name = profile.get("display_name") or self.client_id
            self.identity_private = load_private_identity(self.client_id)
            self.identity_public = self.identity_private.public_key()
            contact_dir = runtime().data_dir if runtime().production else None
            self.contacts = ContactStore(self.client_id, directory=contact_dir)
            self.authority_store = AuthorityStore(self.client_id)
            if runtime().production:
                self.user_role = self.authority_store.role_for_owner()
            else:
                self.user_role = (
                    ROLE_ADMIN if self.profile_store.is_admin(self.client_id) else ROLE_USER
                )
            self.is_admin = self.user_role in (ROLE_ADMIN, ROLE_SUPER_ADMIN)
            self.security_admin = (
                (EndpointSecurityAdmin(self.client_id) if runtime().production else SecurityAdmin(self.client_id))
                if self.is_admin else None
            )
            self.replay_protector = ReplayProtector(self.client_id)
            self.session_manager = SessionManager(
                self.client_id,
                self.identity_private,
                self.contacts,
            )
        except Exception as exc:
            self.emit("fatal", message=f"Startup state error: {exc}")
            raise

        self.emit(
            "identity",
            client_id=self.client_id,
            display_name=self.display_name,
            fingerprint=format_fingerprint(self.identity_public),
        )
        self.emit_contacts()
        self.emit("role", role=self.user_role)

        self.started = True
        self.emit("starting", message="Connecting to both no-queue relays…")

        self.listener_a = asyncio.create_task(
            self._relay_supervisor(self.relay_a_uri, "Relay A", "A")
        )
        self.listener_b = asyncio.create_task(
            self._relay_supervisor(self.relay_b_uri, "Relay B", "B")
        )
        self.contact_watch_task = asyncio.create_task(self._contact_watch_loop())
        self.maintenance_task = asyncio.create_task(self._maintenance_loop())

    async def stop(self):
        if self.closing:
            return
        self.closing = True

        tasks = [
            task
            for task in (
                self.listener_a,
                self.listener_b,
                self.contact_watch_task,
                self.maintenance_task,
            )
            if task
        ]

        for websocket in (self.relay_a, self.relay_b):
            if websocket is not None:
                try:
                    await websocket.close()
                except Exception:
                    pass

        for task in tasks:
            task.cancel()

        if tasks:
            await asyncio.gather(*tasks, return_exceptions=True)

        # Deliberately discard all ephemeral transport/session bookkeeping.
        self.outbound_receipts.clear()
        self.session_activity.clear()
        try:
            await self.assembler.purge()
            await self.contact_assembler.purge()
            await self.control_tracker.purge()
        except Exception:
            pass

        self.relay_a = None
        self.relay_b = None
        self.emit("relay_status", relay="Relay A", connected=False, reconnecting=False)
        self.emit("relay_status", relay="Relay B", connected=False, reconnecting=False)
        self.started = False

    async def _send_control_both(self, recipient, payload):
        recipient = str(recipient).strip().lower()
        if not CLIENT_ID_RE.fullmatch(recipient):
            raise ValueError("Invalid recipient user ID")
        if not isinstance(payload, dict):
            raise TypeError("Control payload must be a dictionary")

        relay_a = self.relay_a
        relay_b = self.relay_b
        if relay_a is None or relay_b is None:
            raise RuntimeError("Both relays must be connected")

        message_id = uuid.uuid4().hex
        packet = {
            "type": "message",
            "message_id": message_id,
            "to": recipient,
            "payload": payload,
        }
        raw = json.dumps(packet, ensure_ascii=False, separators=(",", ":"))
        if len(raw.encode("utf-8")) > MAX_WS_MESSAGE_BYTES:
            raise ValueError("Control packet exceeds transport limit")

        await asyncio.gather(
            relay_a.send(raw),
            relay_b.send(raw),
        )
        return message_id

    async def _ack_one(self, websocket, message_id):
        await websocket.send(json.dumps({
            "type": "ack",
            "message_id": message_id,
        }))

    def _contact_body(self, message_type, peer, request_id):
        return {
            "protocol": "BASE36-CONTACT-V1",
            "type": message_type,
            "request_id": request_id,
            "sender": self.client_id,
            "recipient": peer,
            "created_at": int(time.time()),
            "identity": public_key_b64(self.identity_public),
            "display_name": self.display_name,
            "client_protocol": CLIENT_PROTOCOL_VERSION,
        }

    def _verify_contact_packet(self, sender, packet, expected_type):
        if not isinstance(packet, dict):
            raise ValueError("Invalid contact packet")
        body = packet.get("body")
        if not isinstance(body, dict):
            raise ValueError("Missing contact body")
        if body.get("protocol") != "BASE36-CONTACT-V1":
            raise ValueError("Wrong contact protocol")
        if body.get("type") != expected_type:
            raise ValueError("Wrong contact control type")
        if body.get("sender") != sender:
            raise ValueError("Contact sender mismatch")
        if body.get("recipient") != self.client_id:
            raise ValueError("Contact request addressed to another user")
        validate_timestamp(body.get("created_at"))
        public_key = public_key_from_b64(body.get("identity", ""))
        verify_document(public_key, packet)

        display_name = body.get("display_name")
        if display_name is None:
            # Compatibility with older contact packets.
            display_name = sender.replace("_", " ").title()
        display_name = normalize_display_name(display_name)
        peer_version = body.get("client_protocol", 1)
        if peer_version != CLIENT_PROTOCOL_VERSION:
            self.emit(
                "version_warning",
                peer=sender,
                peer_version=peer_version,
                local_version=CLIENT_PROTOCOL_VERSION,
            )
        return body, public_key, display_name

    def _profile_body(self, peer):
        return {
            "protocol": "BASE36-PROFILE-V1",
            "type": "profile_update",
            "sender": self.client_id,
            "recipient": peer,
            "created_at": int(time.time()),
            "display_name": self.display_name,
            "client_protocol": CLIENT_PROTOCOL_VERSION,
        }

    async def _send_profile_update(self, peer):
        if self.identity_private is None:
            return False
        body = self._profile_body(peer)
        packet = sign_document(self.identity_private, body)
        await self._send_control_both(peer, {
            "kind": "profile_update",
            "packet": packet,
        })
        return True

    async def _best_effort_profile_update(self, peer):
        try:
            return await self._send_profile_update(peer)
        except Exception:
            return False

    def _verify_profile_packet(self, sender, packet):
        if not isinstance(packet, dict):
            raise ValueError("Invalid profile packet")
        body = packet.get("body")
        if not isinstance(body, dict):
            raise ValueError("Missing profile body")
        if body.get("protocol") != "BASE36-PROFILE-V1":
            raise ValueError("Wrong profile protocol")
        if body.get("type") != "profile_update":
            raise ValueError("Wrong profile control type")
        if body.get("sender") != sender:
            raise ValueError("Profile sender mismatch")
        if body.get("recipient") != self.client_id:
            raise ValueError("Profile update addressed to another user")

        validate_timestamp(body.get("created_at"))
        display_name = normalize_display_name(body.get("display_name"))
        peer_version = body.get("client_protocol", 1)
        if peer_version != CLIENT_PROTOCOL_VERSION:
            self.emit(
                "version_warning",
                peer=sender,
                peer_version=peer_version,
                local_version=CLIENT_PROTOCOL_VERSION,
            )

        # Unlike first contact, profile changes are accepted only from the
        # already-pinned identity key. A display name can never change trust.
        public_key = self.contacts.get_public_key(sender, require_trusted=True)
        verify_document(public_key, packet)
        return body, display_name

    async def request_contact(self, peer):
        peer = peer.strip().lower()
        if not peer or peer == self.client_id:
            raise ValueError("Choose another user")

        existing = self.contacts.get(peer)
        if existing and existing.get("status") == STATUS_LOCKED:
            self.emit("security_lock", peer=peer, message="Identity key change is locked for administrator review")
            return False
        if existing and existing.get("status") == STATUS_REVOKED:
            self.emit("security_lock", peer=peer, message="Identity is revoked")
            return False
        if self.contacts.is_trusted(peer):
            self.emit(
                "contact_pinned",
                peer=peer,
                display_name=existing.get("display_name") or peer,
                fingerprint=format_fingerprint_text(existing["fingerprint"]),
                existing=True,
            )
            return True

        request_id = uuid.uuid4().hex
        body = self._contact_body("contact_request", peer, request_id)
        packet = sign_document(self.identity_private, body)
        self.outgoing_contact_requests[request_id] = peer
        await self._send_control_both(peer, {
            "kind": "contact_request",
            "request_id": request_id,
            "packet": packet,
        })
        self.emit("contact_request_sent", peer=peer, request_id=request_id)
        return True

    async def accept_contact_request(self, request_id):
        state = self.incoming_contact_requests.pop(request_id, None)
        if state is None:
            raise ValueError("Contact request is no longer available")

        peer = state["peer"]
        entry, _created, changed = self.contacts.pin_first_seen(
            peer,
            state["public_key"],
            source="accepted-dual-relay-request",
            display_name=state.get("display_name"),
        )
        if changed or entry.get("status") == STATUS_LOCKED:
            self.session_manager.remove_peer(peer)
            self.emit_contacts()
            self.emit("security_lock", peer=peer, message="Identity key changed; administrator action required")
            return False

        body = self._contact_body("contact_accept", peer, request_id)
        packet = sign_document(self.identity_private, body)
        await self._send_control_both(peer, {
            "kind": "contact_accept",
            "request_id": request_id,
            "packet": packet,
        })
        self.emit_contacts()
        self.emit(
            "contact_pinned",
            peer=peer,
            display_name=entry.get("display_name") or peer,
            fingerprint=format_fingerprint_text(entry["fingerprint"]),
            existing=False,
        )
        return True

    async def reject_contact_request(self, request_id):
        state = self.incoming_contact_requests.pop(request_id, None)
        if state is None:
            return False
        peer = state["peer"]
        body = self._contact_body("contact_reject", peer, request_id)
        packet = sign_document(self.identity_private, body)
        await self._send_control_both(peer, {
            "kind": "contact_reject",
            "request_id": request_id,
            "packet": packet,
        })
        return True

    async def remove_contact(self, peer):
        peer = peer.strip().lower()
        removed = self.contacts.hide_contact(peer)
        if removed:
            self.session_manager.remove_peer(peer)
            self.emit("contact_removed", peer=peer)
            self.emit_contacts()
        return removed

    async def set_contact_alias(self, peer, alias):
        peer = peer.strip().lower()
        entry = self.contacts.set_local_alias(peer, alias)
        self.emit_contacts()
        self.emit(
            "contact_alias_changed",
            peer=peer,
            alias=entry.get("local_alias"),
        )
        return entry

    async def update_display_name(self, display_name):
        display_name = normalize_display_name(display_name)
        profile = self.profile_store.set_display_name(
            self.client_id, display_name
        )
        self.display_name = profile["display_name"]

        self.emit(
            "display_name_changed",
            client_id=self.client_id,
            display_name=self.display_name,
        )

        # Best effort: display metadata is not security state and failure to
        # reach one contact must not roll back the local profile change.
        for entry in self.contacts.list_contacts():
            if entry.get("status") != STATUS_PINNED or not entry.get("trusted"):
                continue
            try:
                await self._send_profile_update(entry["name"])
            except Exception as exc:
                self.emit(
                    "error",
                    peer=entry["name"],
                    message=f"Display-name update could not reach {entry['name']}: {exc}",
                )

        return profile

    def _invitation_body(self):
        return {
            "protocol": INVITE_PROTOCOL,
            "user_id": self.client_id,
            "display_name": self.display_name,
            "identity": public_key_b64(self.identity_public),
            "client_protocol": CLIENT_PROTOCOL_VERSION,
        }

    async def create_invitation(self):
        """Create a signed, PII-minimal contact invitation code."""
        if self.identity_private is None or self.identity_public is None:
            raise RuntimeError("Identity is not loaded")
        packet = sign_document(self.identity_private, self._invitation_body())
        raw = json.dumps(
            packet,
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
        ).encode("utf-8")
        code = INVITE_PREFIX + base64.urlsafe_b64encode(raw).decode("ascii").rstrip("=")
        self.emit(
            "invitation_ready",
            code=code,
            user_id=self.client_id,
            display_name=self.display_name,
            fingerprint=format_fingerprint(self.identity_public),
        )
        return code

    async def import_invitation(self, code):
        """Import an out-of-band signed contact card without a directory/database."""
        if not isinstance(code, str):
            raise TypeError("Invitation code must be text")
        code = code.strip()
        if not code.startswith(INVITE_PREFIX):
            raise ValueError("Not a Base36 Chat invitation code")

        encoded = code[len(INVITE_PREFIX):]
        if not encoded or len(encoded) > 8192:
            raise ValueError("Invalid invitation length")
        encoded += "=" * (-len(encoded) % 4)
        try:
            raw = base64.urlsafe_b64decode(encoded.encode("ascii"))
            packet = json.loads(raw.decode("utf-8"))
        except Exception as exc:
            raise ValueError("Invitation code is malformed") from exc

        if not isinstance(packet, dict) or not isinstance(packet.get("body"), dict):
            raise ValueError("Invitation packet is invalid")
        body = packet["body"]
        if body.get("protocol") != INVITE_PROTOCOL:
            raise ValueError("Unsupported invitation protocol")

        peer = str(body.get("user_id", "")).strip().lower()
        if not CLIENT_ID_RE.fullmatch(peer):
            raise ValueError("Invitation contains an invalid user ID")
        if peer == self.client_id:
            raise ValueError("Cannot add yourself as a contact")

        display_name = normalize_display_name(body.get("display_name"))
        public_key = public_key_from_b64(body.get("identity", ""))
        verify_document(public_key, packet)

        peer_version = body.get("client_protocol", 1)
        if peer_version != CLIENT_PROTOCOL_VERSION:
            self.emit(
                "version_warning",
                peer=peer,
                peer_version=peer_version,
                local_version=CLIENT_PROTOCOL_VERSION,
            )

        entry, created, changed = self.contacts.pin_first_seen(
            peer,
            public_key,
            source="signed-out-of-band-invitation",
            display_name=display_name,
        )
        if changed or entry.get("status") == STATUS_LOCKED:
            self.session_manager.remove_peer(peer)
            self.emit_contacts()
            self.emit(
                "security_lock",
                peer=peer,
                message="Invitation identity conflicts with the pinned key; administrator action required",
            )
            return False

        self.emit_contacts()
        self.emit(
            "contact_pinned",
            peer=peer,
            display_name=entry.get("display_name") or peer,
            fingerprint=format_fingerprint_text(entry["fingerprint"]),
            existing=not created,
            source="invitation",
        )
        return True

    def environment_invitation(self):
        if self.authority_store is None or self.user_role != ROLE_SUPER_ADMIN:
            raise PermissionError("Super Administrator role required")
        return self.authority_store.export_environment_invitation()

    async def grant_administrator(self, peer):
        peer = peer.strip().lower()
        if self.authority_store is None or self.user_role != ROLE_SUPER_ADMIN:
            raise PermissionError("Super Administrator role required")
        token = self.authority_store.issue_role_token(peer, ROLE_ADMIN)
        await self._send_control_both(peer, {
            "kind": "authority_update",
            "token": token,
        })
        self.emit(
            "admin_action",
            message=f"Administrator grant sent to {peer}. Recipient must be online; no role message is queued.",
        )
        return token

    async def revoke_administrator(self, peer):
        peer = peer.strip().lower()
        if self.authority_store is None or self.user_role != ROLE_SUPER_ADMIN:
            raise PermissionError("Super Administrator role required")
        if peer == self.client_id:
            raise ValueError("The Super Administrator authority cannot revoke itself")
        token = self.authority_store.issue_role_token(peer, ROLE_USER)
        await self._send_control_both(peer, {
            "kind": "authority_update",
            "token": token,
        })
        self.emit(
            "admin_action",
            message=f"Administrator revocation sent to {peer}. Recipient must be online; no role message is queued.",
        )
        return token

    async def list_security_incidents(self):
        if not self.is_admin or self.security_admin is None:
            raise PermissionError("Administrator role required")
        incidents = self.security_admin.list_locked_incidents()
        self.emit("admin_incidents", incidents=incidents)
        return incidents

    async def admin_authorize_replacement(self, owner, peer, reason):
        if not self.is_admin or self.security_admin is None:
            raise PermissionError("Administrator role required")
        self.security_admin.authorize_replacement(owner, peer, reason)
        self.emit("admin_action", message=f"Authorized identity replacement for {owner} → {peer}")
        return await self.list_security_incidents()

    async def admin_reject_presented_key(self, owner, peer, reason):
        if not self.is_admin or self.security_admin is None:
            raise PermissionError("Administrator role required")
        self.security_admin.reject_presented_key(owner, peer, reason)
        self.emit("admin_action", message=f"Rejected presented identity for {owner} → {peer}")
        return await self.list_security_incidents()

    async def admin_revoke_contact(self, owner, peer, reason):
        if not self.is_admin or self.security_admin is None:
            raise PermissionError("Administrator role required")
        self.security_admin.revoke_contact(owner, peer, reason)
        self.emit("admin_action", message=f"Revoked identity for {owner} → {peer}")
        return await self.list_security_incidents()

    async def _contact_watch_loop(self):
        previous = {}
        while True:
            await asyncio.sleep(1)
            try:
                self.contacts.reload()
                current = {
                    entry["name"]: (
                        entry.get("status"),
                        entry.get("fingerprint"),
                        entry.get("presented_fingerprint"),
                        entry.get("display_name"),
                        entry.get("local_alias"),
                    )
                    for entry in self.contacts.list_contacts(include_removed=True)
                }
                if current != previous:
                    for peer, state in current.items():
                        status = state[0]
                        if status != STATUS_PINNED:
                            self.session_manager.remove_peer(peer)
                        if status == STATUS_LOCKED and previous.get(peer) != state:
                            self.emit("security_lock", peer=peer, message="Identity key change detected. Secure messaging suspended; administrator action required.")
                    self.emit_contacts()
                    previous = current
            except asyncio.CancelledError:
                raise
            except Exception as exc:
                self.emit("error", message=f"Contact security-state refresh failed: {exc}")

    async def _maintenance_loop(self):
        while True:
            await asyncio.sleep(5)
            try:
                await self.assembler.purge()
                await self.contact_assembler.purge()
                await self.control_tracker.purge()

                now = time.monotonic()
                for message_id, state in list(self.outbound_receipts.items()):
                    if now - state.get("created", now) >= RECEIPT_TTL_SECONDS:
                        local_id = state.get("local_id")
                        peer = state.get("peer")
                        self.outbound_receipts.pop(message_id, None)
                        if local_id:
                            self.emit(
                                "message_status",
                                peer=peer,
                                local_id=local_id,
                                status="sent • delivery unconfirmed",
                            )

                for peer, last_active in list(self.session_activity.items()):
                    if now - last_active >= SESSION_IDLE_SECONDS:
                        self.session_activity.pop(peer, None)
                        if self.session_manager.session_for_peer(peer) is not None:
                            self.session_manager.remove_peer(peer)
                            self.emit(
                                "session_status",
                                peer=peer,
                                status="idle",
                                detail="Idle secure session expired",
                            )
                            self.emit_contacts()
            except asyncio.CancelledError:
                raise
            except Exception:
                # Maintenance is deliberately best-effort and never logs message data.
                pass

    def _handle_outbound_receipt(self, message_id, channel, receipt_type):
        state = self.outbound_receipts.get(message_id)
        if state is None:
            return

        state[receipt_type].add(channel)
        local_id = state.get("local_id")
        peer = state.get("peer")

        if receipt_type == "accepted" and state["accepted"] == {"A", "B"}:
            if local_id:
                self.emit(
                    "message_status",
                    peer=peer,
                    local_id=local_id,
                    status="sent",
                )

        if receipt_type == "delivered" and state["delivered"] == {"A", "B"}:
            if local_id:
                self.emit(
                    "message_status",
                    peer=peer,
                    local_id=local_id,
                    status="delivered",
                )
            self.outbound_receipts.pop(message_id, None)

    def _fail_outbound_message(self, message_id, reason):
        state = self.outbound_receipts.pop(message_id, None)
        if state is None:
            return False
        self.emit(
            "message_failed",
            peer=state.get("peer"),
            local_id=state.get("local_id"),
            message_id=message_id,
            reason=reason or "Delivery failed; message was not retained by the relay",
        )
        return True

    async def ensure_session(self, peer):
        """Start a secure session without retaining any user message."""
        peer = str(peer).strip().lower()
        if not peer:
            return False
        try:
            self.contacts.get_public_key(peer, require_trusted=True)
        except Exception as exc:
            self.emit("error", message=str(exc), peer=peer)
            return False

        if self.session_manager.session_for_peer(peer) is not None:
            self.session_activity[peer] = time.monotonic()
            self.emit(
                "session_status",
                peer=peer,
                status="secure",
                detail="Secure session already active",
            )
            return True

        if not self._both_relays_connected():
            self.emit(
                "session_status",
                peer=peer,
                status="failed",
                detail="Both relays must be connected",
            )
            return False

        return await self._start_session(peer)

    async def send_message(self, peer, plaintext):
        """Send immediately or discard. Plaintext is never placed in a retry queue."""
        peer = str(peer).strip().lower()
        plaintext = str(plaintext).rstrip("\r\n")

        if not plaintext or not plaintext.strip():
            return False

        utf8_length = len(plaintext.encode("utf-8"))
        if utf8_length > MAX_MESSAGE_UTF8_BYTES:
            self.emit(
                "message_discarded",
                peer=peer,
                reason=(
                    f"Message is {utf8_length} UTF-8 bytes; maximum is "
                    f"{MAX_MESSAGE_UTF8_BYTES}. Message was not retained."
                ),
            )
            return False

        try:
            self.contacts.get_public_key(peer, require_trusted=True)
        except Exception as exc:
            self.emit(
                "message_discarded",
                peer=peer,
                reason=f"{exc}. Message was not retained.",
            )
            return False

        if not self._both_relays_connected():
            self.emit(
                "message_discarded",
                peer=peer,
                reason="Both relays are not connected. Message was not retained.",
            )
            return False

        if self.session_manager.session_for_peer(peer) is None:
            await self._start_session(peer)
            self.emit(
                "message_discarded",
                peer=peer,
                reason=(
                    "A secure session was not ready. Session setup has started, "
                    "but the message was not retained. Send it again after Secure appears."
                ),
            )
            return False

        local_id = uuid.uuid4().hex

        # Put the text only into the visible, ephemeral GUI history before the
        # network attempt. This is not a retry queue: the protocol engine does
        # not store it, and the GUI removes it immediately if delivery fails.
        # Enqueuing this UI event first also guarantees a fast relay rejection
        # cannot race ahead of the record that must be purged.
        self.emit(
            "outgoing_message",
            peer=peer,
            plaintext=plaintext,
            local_id=local_id,
            status="sending",
        )

        message_id = await self._send_secure_message(peer, plaintext, local_id)
        if message_id is None:
            self.emit(
                "message_failed",
                peer=peer,
                local_id=local_id,
                reason="Immediate send failed. Message was not retained.",
            )
            return False

        self.emit(
            "message_status",
            peer=peer,
            local_id=local_id,
            status="sent",
            message_id=message_id,
        )
        return True

    async def _send_secure_message(self, recipient, plaintext, local_id=None):
        session_keys = self.session_manager.session_for_peer(recipient)
        if session_keys is None or not self._both_relays_connected():
            return None

        message_id = uuid.uuid4().hex
        replay_metadata = create_replay_metadata()

        try:
            cipher_a, cipher_b = encode_message(plaintext)
        except Exception as exc:
            self.emit("error", message=f"Encryption error: {exc}", peer=recipient)
            return None

        protected_a = {
            "session_id": session_keys.session_id,
            "replay": replay_metadata,
            "cipher": cipher_a,
        }
        protected_b = {
            "session_id": session_keys.session_id,
            "replay": replay_metadata,
            "cipher": cipher_b,
        }

        auth_a = authenticate_payload(
            session_keys.send_auth_key,
            message_id,
            self.client_id,
            recipient,
            "A",
            protected_a,
        )
        auth_b = authenticate_payload(
            session_keys.send_auth_key,
            message_id,
            self.client_id,
            recipient,
            "B",
            protected_b,
        )

        packet_a = {
            "type": "message",
            "message_id": message_id,
            "to": recipient,
            "payload": {
                "kind": "data",
                "session_id": session_keys.session_id,
                "auth": auth_a,
            },
        }
        packet_b = {
            "type": "message",
            "message_id": message_id,
            "to": recipient,
            "payload": {
                "kind": "data",
                "session_id": session_keys.session_id,
                "auth": auth_b,
            },
        }

        raw_a = json.dumps(packet_a, separators=(",", ":"))
        raw_b = json.dumps(packet_b, separators=(",", ":"))
        if (
            len(raw_a.encode("utf-8")) > MAX_WS_MESSAGE_BYTES
            or len(raw_b.encode("utf-8")) > MAX_WS_MESSAGE_BYTES
        ):
            self.emit("error", message="Encrypted packet exceeds transport limit", peer=recipient)
            return None

        self.outbound_receipts[message_id] = {
            "peer": recipient,
            "local_id": local_id,
            "created": time.monotonic(),
            "accepted": set(),
            "delivered": set(),
        }

        try:
            relay_a = self.relay_a
            relay_b = self.relay_b
            if relay_a is None or relay_b is None:
                self.outbound_receipts.pop(message_id, None)
                return None
            await asyncio.gather(relay_a.send(raw_a), relay_b.send(raw_b))
        except Exception as exc:
            self.outbound_receipts.pop(message_id, None)
            self.emit("transport_notice", message="Immediate send failed", detail=str(exc))
            return None

        self.session_activity[recipient] = time.monotonic()
        return message_id

    async def _start_session(self, peer):
        if self.session_manager.session_for_peer(peer) is not None:
            return True

        if self.session_manager.has_pending_for_peer(peer):
            return True

        try:
            session_id, offer_packet, peer_public = (
                await self.session_manager.create_offer(peer)
            )
            try:
                await self._send_profile_update(peer)
            except Exception:
                pass
            await self._send_control_both(
                peer,
                {
                    "kind": "session_offer",
                    "session_id": session_id,
                    "packet": offer_packet,
                },
            )
        except Exception as exc:
            self.emit(
                "session_status",
                peer=peer,
                status="failed",
                detail=str(exc),
            )
            return False

        self.emit(
            "session_status",
            peer=peer,
            status="connecting",
            detail="Signed session offer sent",
            fingerprint=format_fingerprint(peer_public),
            session_id=session_id,
        )
        return True

    async def _handle_contact_control_bundle(self, message_id, bundle):
        half_a = bundle["A"]
        half_b = bundle["B"]

        if (
            half_a["sender"] != half_b["sender"]
            or half_a["payload"] != half_b["payload"]
        ):
            self.emit(
                "security_reject",
                message=(
                    "Dual-relay control copies from Relay A and Relay B "
                    "did not match"
                ),
            )
            return False

        sender = half_a["sender"]
        payload = half_a["payload"]
        kind = payload.get("kind")

        try:
            if kind == "contact_request":
                body, public_key, display_name = self._verify_contact_packet(
                    sender, payload.get("packet"), "contact_request"
                )
                self.replay_protector.require_unused(message_id)
                request_id = body.get("request_id")
                existing = self.contacts.get(sender)

                if existing is not None:
                    entry, _created, changed = self.contacts.pin_first_seen(
                        sender,
                        public_key,
                        source="dual-relay-contact-request",
                        display_name=display_name,
                    )
                    if changed or entry.get("status") == STATUS_LOCKED:
                        self.session_manager.remove_peer(sender)
                        self.emit_contacts()
                        self.emit(
                            "security_lock",
                            peer=sender,
                            message=(
                                "Presented identity does not match the pinned key. "
                                "No user override is permitted."
                            ),
                        )
                        return False
                    if entry.get("status") == STATUS_REVOKED:
                        self.emit(
                            "security_lock",
                            peer=sender,
                            message="Presented identity is revoked",
                        )
                        return False

                    # Already pinned: respond without asking the user again.
                    accept_body = self._contact_body(
                        "contact_accept", sender, request_id
                    )
                    accept_packet = sign_document(
                        self.identity_private, accept_body
                    )
                    await self._send_control_both(sender, {
                        "kind": "contact_accept",
                        "request_id": request_id,
                        "packet": accept_packet,
                    })
                    self.emit_contacts()
                else:
                    self.incoming_contact_requests[request_id] = {
                        "peer": sender,
                        "public_key": public_key,
                        "display_name": display_name,
                    }
                    self.emit(
                        "contact_request",
                        peer=sender,
                        display_name=display_name,
                        request_id=request_id,
                        fingerprint=format_fingerprint(public_key),
                    )

            elif kind == "contact_accept":
                body, public_key, display_name = self._verify_contact_packet(
                    sender, payload.get("packet"), "contact_accept"
                )
                self.replay_protector.require_unused(message_id)
                request_id = body.get("request_id")
                expected_peer = self.outgoing_contact_requests.get(request_id)
                if expected_peer != sender:
                    raise ValueError("Unexpected contact acceptance")

                entry, _created, changed = self.contacts.pin_first_seen(
                    sender,
                    public_key,
                    source="dual-relay-contact-accept",
                    display_name=display_name,
                )
                if changed or entry.get("status") == STATUS_LOCKED:
                    self.session_manager.remove_peer(sender)
                    self.emit_contacts()
                    self.emit(
                        "security_lock",
                        peer=sender,
                        message=(
                            "Presented identity does not match the pinned key. "
                            "No user override is permitted."
                        ),
                    )
                    return False

                self.outgoing_contact_requests.pop(request_id, None)
                self.emit_contacts()
                self.emit(
                    "contact_pinned",
                    peer=sender,
                    display_name=entry.get("display_name") or sender,
                    fingerprint=format_fingerprint_text(entry["fingerprint"]),
                    existing=False,
                )

            elif kind == "contact_reject":
                body, _public_key, _display_name = self._verify_contact_packet(
                    sender, payload.get("packet"), "contact_reject"
                )
                self.replay_protector.require_unused(message_id)
                request_id = body.get("request_id")
                if self.outgoing_contact_requests.get(request_id) == sender:
                    self.outgoing_contact_requests.pop(request_id, None)
                self.emit("contact_rejected", peer=sender)

            elif kind == "profile_update":
                body, display_name = self._verify_profile_packet(
                    sender, payload.get("packet")
                )
                self.replay_protector.require_unused(message_id)
                entry = self.contacts.set_display_name(sender, display_name)
                self.emit_contacts()
                self.emit(
                    "contact_profile_updated",
                    peer=sender,
                    display_name=entry.get("display_name") or sender,
                )

            elif kind == "authority_update":
                self.replay_protector.require_unused(message_id)
                if self.authority_store is None:
                    raise ValueError("No administrative authority is configured")
                role_body = self.authority_store.apply_role_token(
                    payload.get("token", ""),
                    expected_subject=self.client_id,
                )
                self.user_role = self.authority_store.role_for_owner()
                self.is_admin = self.user_role in (ROLE_ADMIN, ROLE_SUPER_ADMIN)
                self.security_admin = (
                    (EndpointSecurityAdmin(self.client_id) if runtime().production else SecurityAdmin(self.client_id))
                    if self.is_admin else None
                )
                self.emit("role", role=self.user_role)
                self.emit(
                    "authority_notice",
                    role=self.user_role,
                    issuer=role_body.get("issuer_id"),
                    sequence=role_body.get("sequence"),
                )
                body = {"created_at": int(role_body.get("issued_at", time.time()))}

            else:
                raise ValueError("Unknown dual-relay control")

            self.replay_protector.mark_completed(
                message_id, body["created_at"]
            )
            ack = json.dumps({"type": "ack", "message_id": message_id})
            await asyncio.gather(
                half_a["websocket"].send(ack),
                half_b["websocket"].send(ack),
            )
            return True
        except Exception as exc:
            self.emit(
                "security_reject",
                peer=sender,
                message=f"Dual-relay control rejected: {exc}",
            )
            return False

    async def _handle_session_control(
        self,
        websocket,
        message_id,
        sender,
        payload,
    ):
        kind = payload.get("kind")

        if not self.contacts.is_trusted(sender):
            self.emit(
                "security_reject",
                peer=sender,
                message=f"Session control from untrusted contact {sender}",
            )
            return False

        if kind == "session_offer":
            try:
                session_id, reply_packet, keys, duplicate = (
                    await self.session_manager.receive_offer(
                        sender,
                        payload.get("packet"),
                    )
                )
                await self._send_control_both(
                    sender,
                    {
                        "kind": "session_reply",
                        "session_id": session_id,
                        "packet": reply_packet,
                    },
                )
                try:
                    await self._send_profile_update(sender)
                except Exception:
                    pass
                await self._ack_one(websocket, message_id)
                self.emit(
                    "session_status",
                    peer=sender,
                    status="connecting",
                    detail="Verified signed offer; reply sent",
                    session_id=session_id,
                )
                return True
            except Exception as exc:
                self.emit("security_reject", peer=sender, message=str(exc))
                return False

        if kind == "session_reply":
            try:
                session_id, keys, confirmation = (
                    await self.session_manager.receive_reply(
                        sender,
                        payload.get("packet"),
                    )
                )
                await self._send_control_both(
                    sender,
                    {
                        "kind": "session_confirm",
                        "session_id": session_id,
                        "role": "initiator",
                        "tag": confirmation,
                    },
                )
                await self._ack_one(websocket, message_id)
                self.emit(
                    "session_status",
                    peer=sender,
                    status="connecting",
                    detail="Signed reply verified; confirming derived key",
                    session_id=session_id,
                )
                return True
            except Exception as exc:
                self.emit("security_reject", peer=sender, message=str(exc))
                return False

        if kind == "session_confirm":
            try:
                result = await self.session_manager.receive_confirmation(
                    sender,
                    payload.get("session_id"),
                    payload.get("role"),
                    payload.get("tag"),
                )
                keys = result["keys"]

                if result["send_responder_confirmation"]:
                    await self._send_control_both(
                        sender,
                        {
                            "kind": "session_confirm",
                            "session_id": keys.session_id,
                            "role": "responder",
                            "tag": result["tag"],
                        },
                    )

                if result["newly_active"]:
                    self.emit(
                        "session_status",
                        peer=keys.peer_id,
                        status="secure",
                        detail="Identity and key confirmation verified",
                        session_id=keys.session_id,
                    )
                    self.session_activity[keys.peer_id] = time.monotonic()
                    self.emit_contacts()

                await self._ack_one(websocket, message_id)
                return True
            except Exception as exc:
                self.emit("security_reject", peer=sender, message=str(exc))
                return False

        return False

    async def _process_complete_message(self, message_id, bundle):
        half_a = bundle["A"]
        half_b = bundle["B"]

        sender = half_a["sender"]
        if sender != half_b["sender"]:
            self.emit("security_reject", peer=sender, message="Sender mismatch")
            return

        session_id = half_a["session_id"]
        if session_id != half_b["session_id"]:
            self.emit("security_reject", peer=sender, message="Session mismatch")
            return

        replay_a = half_a["replay"]
        if replay_a != half_b["replay"]:
            self.emit("security_reject", peer=sender, message="Replay metadata mismatch")
            return

        session_keys = self.session_manager.session_by_id(session_id)
        if session_keys is None or session_keys.peer_id != sender:
            self.emit("security_reject", peer=sender, message="Inactive session")
            return

        try:
            self.replay_protector.require_unused(message_id)
            plaintext = decode_message(half_a["cipher"], half_b["cipher"])
            self.replay_protector.mark_completed(
                message_id,
                replay_a["created_at"],
            )
        except Exception as exc:
            self.emit("security_reject", peer=sender, message=str(exc))
            return

        ack = json.dumps({
            "type": "ack",
            "message_id": message_id,
        })
        await asyncio.gather(
            half_a["websocket"].send(ack),
            half_b["websocket"].send(ack),
            return_exceptions=True,
        )

        self.session_activity[sender] = time.monotonic()
        self.emit(
            "incoming_message",
            peer=sender,
            plaintext=plaintext,
            message_id=message_id,
            session_id=session_id,
            security="verified",
        )

    async def _handle_data_message(
        self,
        websocket,
        relay_name,
        expected_channel,
        message_id,
        sender,
        payload,
    ):
        session_id = payload.get("session_id")
        wrapped = payload.get("auth")

        session_keys = self.session_manager.session_by_id(session_id)
        if session_keys is None or session_keys.peer_id != sender:
            self.emit("security_reject", peer=sender, message="Unknown session")
            return

        try:
            channel, protected = verify_authenticated_payload(
                session_keys.receive_auth_key,
                message_id,
                sender,
                self.client_id,
                wrapped,
            )
        except Exception as exc:
            self.emit("security_reject", peer=sender, message=f"{relay_name}: {exc}")
            return

        if channel != expected_channel:
            self.emit("security_reject", peer=sender, message="Channel substitution")
            return

        if not isinstance(protected, dict):
            self.emit("security_reject", peer=sender, message="Invalid protected payload")
            return

        if protected.get("session_id") != session_id:
            self.emit("security_reject", peer=sender, message="Authenticated session mismatch")
            return

        replay_metadata = protected.get("replay")
        cipher_body = protected.get("cipher")
        if cipher_body is None:
            self.emit("security_reject", peer=sender, message="Missing cipher body")
            return

        try:
            validate_replay_metadata(replay_metadata)
            self.replay_protector.require_unused(message_id)
        except Exception as exc:
            self.emit("security_reject", peer=sender, message=str(exc))
            return

        try:
            complete = await self.assembler.add_half(
                expected_channel,
                websocket,
                message_id,
                sender,
                session_id,
                cipher_body,
                replay_metadata,
            )
        except Exception as exc:
            self.emit("security_reject", peer=sender, message=str(exc))
            return

        if complete is not None:
            await self._process_complete_message(message_id, complete)

    async def _listen(self, websocket, relay_name, expected_channel):
        async for raw in websocket:
            if isinstance(raw, bytes):
                if len(raw) > MAX_WS_MESSAGE_BYTES:
                    raise ValueError(f"{relay_name} sent an oversized packet")
                try:
                    raw = raw.decode("utf-8")
                except UnicodeDecodeError:
                    self.emit("security_reject", message=f"Invalid UTF-8 packet from {relay_name}")
                    continue
            elif not isinstance(raw, str):
                self.emit("security_reject", message=f"Invalid packet type from {relay_name}")
                continue

            if len(raw.encode("utf-8")) > MAX_WS_MESSAGE_BYTES:
                raise ValueError(f"{relay_name} sent an oversized packet")

            try:
                packet = json.loads(raw)
            except json.JSONDecodeError:
                self.emit("security_reject", message=f"Malformed JSON from {relay_name}")
                continue

            if not isinstance(packet, dict):
                self.emit("security_reject", message=f"Invalid packet from {relay_name}")
                continue

            packet_type = packet.get("type")
            message_id = packet.get("message_id")

            if packet_type in ("accepted", "delivered", "delivery_timeout"):
                try:
                    uuid.UUID(str(message_id))
                except (ValueError, TypeError, AttributeError):
                    continue

                if packet_type == "accepted":
                    self._handle_outbound_receipt(message_id, expected_channel, "accepted")
                elif packet_type == "delivered":
                    self._handle_outbound_receipt(message_id, expected_channel, "delivered")
                else:
                    state = self.outbound_receipts.pop(message_id, None)
                    if state and state.get("local_id"):
                        self.emit(
                            "message_status",
                            peer=state.get("peer"),
                            local_id=state.get("local_id"),
                            status="sent • delivery unconfirmed",
                        )
                continue

            if packet_type == "error":
                reason = packet.get("error") or packet.get("code") or f"{relay_name} rejected a packet"
                if message_id and self._fail_outbound_message(message_id, str(reason)):
                    continue
                self.emit("error", message=f"{relay_name}: {reason}")
                continue

            if packet_type != "message":
                self.emit("security_reject", message=f"Unknown packet type from {relay_name}")
                continue

            sender = packet.get("from")
            recipient = packet.get("to")
            payload = packet.get("payload")

            try:
                uuid.UUID(str(message_id))
            except (ValueError, TypeError, AttributeError):
                self.emit("security_reject", message=f"Invalid message ID from {relay_name}")
                continue

            if not isinstance(sender, str):
                self.emit("security_reject", message=f"Invalid sender from {relay_name}")
                continue
            sender = sender.strip().lower()

            if (
                not CLIENT_ID_RE.fullmatch(sender)
                or recipient != self.client_id
                or not isinstance(payload, dict)
            ):
                self.emit("security_reject", message=f"Invalid packet from {relay_name}")
                continue

            kind = payload.get("kind")

            if kind in (
                "contact_request",
                "contact_accept",
                "contact_reject",
                "profile_update",
                "authority_update",
            ):
                try:
                    complete = await self.contact_assembler.add(
                        expected_channel, websocket, message_id, sender, payload
                    )
                except Exception as exc:
                    self.emit("security_reject", peer=sender, message=str(exc))
                    continue
                if complete is not None:
                    await self._handle_contact_control_bundle(message_id, complete)
                continue

            if kind in ("session_offer", "session_reply", "session_confirm"):
                claimed = await self.control_tracker.claim(message_id)
                if not claimed:
                    # Same control packet is intentionally sent through both relays.
                    try:
                        await self._ack_one(websocket, message_id)
                    except Exception:
                        pass
                    continue

                success = False
                try:
                    success = await self._handle_session_control(
                        websocket,
                        message_id,
                        sender,
                        payload,
                    )
                finally:
                    await self.control_tracker.finish(message_id, success)
                continue

            if kind == "data":
                await self._handle_data_message(
                    websocket,
                    relay_name,
                    expected_channel,
                    message_id,
                    sender,
                    payload,
                )
                continue

            self.emit(
                "security_reject",
                peer=sender,
                message=f"Unknown payload kind: {kind}",
            )

