import json
import re
import secrets
import unicodedata
from datetime import datetime, timezone
from pathlib import Path

from deployment import runtime
from secure_identity import (
    create_identity,
    format_fingerprint,
    load_public_identity,
    list_identity_ids,
)


PROFILE_FILE = None  # Resolved at runtime; production uses per-Windows-user LocalAppData.
PROFILE_VERSION = 3
ROLE_ADMIN = "administrator"
ROLE_USER = "user"
USER_ID_LENGTH = 16
USER_ID_ALPHABET = "23456789abcdefghjkmnpqrstuvwxyz"


def normalize_profile_id(profile_id):
    """Normalize/validate an immutable protocol user ID.

    Existing legacy IDs remain valid. New IDs are generated randomly by
    ProfileStore.create_profile() and never derived from display names.
    """
    if not isinstance(profile_id, str):
        raise TypeError("User ID must be text")

    profile_id = profile_id.strip().lower()
    if not profile_id:
        raise ValueError("User ID cannot be empty")

    if not re.fullmatch(r"[a-z0-9_-]{1,64}", profile_id):
        raise ValueError(
            "User ID may contain only letters, numbers, underscore, and hyphen"
        )

    return profile_id


def normalize_display_name(display_name):
    """Validate human-facing display text without changing case or punctuation."""
    if not isinstance(display_name, str):
        raise TypeError("Display name must be text")

    display_name = unicodedata.normalize("NFC", display_name.strip())
    if not display_name:
        raise ValueError("Display name cannot be empty")
    if len(display_name) > 64:
        raise ValueError("Display name is too long")
    if any(not ch.isprintable() for ch in display_name):
        raise ValueError("Display name contains an unsupported control character")

    return display_name


def generate_profile_id(length=USER_ID_LENGTH):
    """Generate a human-copyable, cryptographically random user ID."""
    if not isinstance(length, int) or length < 8 or length > 64:
        raise ValueError("User ID length must be between 8 and 64")

    return "".join(secrets.choice(USER_ID_ALPHABET) for _ in range(length))


class ProfileStore:
    """Local profile registry and application-level role assignment.

    The profile ID is the immutable routing/security identifier. The display
    name is editable local profile metadata and may be shared as signed profile
    metadata without changing the ID or Ed25519 identity.

    Development mode retains the historical first-local-profile administrator
    bootstrap so the multi-profile test harness is not stranded. Production
    authorization is supplied by cryptographic authority statements instead.
    """

    def __init__(self, profile_file=PROFILE_FILE):
        self.profile_file = Path(profile_file) if profile_file is not None else runtime().profile_file
        self.metadata = {}
        self._load()
        self._ensure_metadata_and_admin()

    def _load(self):
        if not self.profile_file.exists():
            self.metadata = {}
            return

        try:
            document = json.loads(
                self.profile_file.read_text(encoding="utf-8")
            )
        except Exception as exc:
            raise ValueError(
                f"Unable to read {self.profile_file.name}: {exc}"
            ) from exc

        profiles = document.get("profiles", {})
        if not isinstance(profiles, dict):
            raise ValueError("profiles.json has an invalid format")
        self.metadata = profiles

    def _save(self):
        document = {
            "version": PROFILE_VERSION,
            "profiles": self.metadata,
        }
        temp = self.profile_file.with_suffix(".tmp")
        temp.write_text(
            json.dumps(
                document,
                indent=2,
                sort_keys=True,
                ensure_ascii=False,
            ),
            encoding="utf-8",
        )
        temp.replace(self.profile_file)

    def _discovered_profile_ids(self):
        return list_identity_ids()

    def _ensure_metadata_and_admin(self):
        ids = self._discovered_profile_ids()
        changed = False

        for profile_id in ids:
            if profile_id not in self.metadata:
                # Legacy identities had display-name-derived IDs. Preserve the
                # ID exactly rather than renaming key files or contact stores.
                self.metadata[profile_id] = {
                    "display_name": profile_id.replace("_", " ").title(),
                    "created_at": None,
                    "role": ROLE_USER,
                }
                changed = True
                continue

            metadata = self.metadata[profile_id]
            if not isinstance(metadata, dict):
                metadata = {}
                self.metadata[profile_id] = metadata
                changed = True

            if "display_name" not in metadata:
                metadata["display_name"] = profile_id.replace("_", " ").title()
                changed = True
            else:
                try:
                    normalized = normalize_display_name(metadata["display_name"])
                except Exception:
                    normalized = profile_id.replace("_", " ").title()
                if metadata.get("display_name") != normalized:
                    metadata["display_name"] = normalized
                    changed = True

            if "created_at" not in metadata:
                metadata["created_at"] = None
                changed = True

            if metadata.get("role") not in (ROLE_ADMIN, ROLE_USER):
                metadata["role"] = ROLE_USER
                changed = True

        admins = [
            profile_id for profile_id in ids
            if self.metadata.get(profile_id, {}).get("role") == ROLE_ADMIN
        ]

        if ids and not admins and not runtime().production:
            # Development-only migration/bootstrap rule. Production roles are
            # cryptographic authority statements, never local editable metadata.
            def sort_key(profile_id):
                created = self.metadata.get(profile_id, {}).get("created_at")
                return (created is None, created or "", profile_id)

            admin_id = sorted(ids, key=sort_key)[0]
            self.metadata[admin_id]["role"] = ROLE_ADMIN
            changed = True

        if changed:
            self._save()

    def list_profiles(self):
        self._ensure_metadata_and_admin()
        result = []

        for profile_id in self._discovered_profile_ids():
            metadata = self.metadata.get(profile_id, {})
            display_name = (
                metadata.get("display_name")
                or profile_id.replace("_", " ").title()
            )

            try:
                public_key = load_public_identity(profile_id)
                fp = format_fingerprint(public_key)
            except Exception:
                fp = "Identity error"

            result.append({
                "id": profile_id,
                "display_name": display_name,
                "fingerprint": fp,
                "created_at": metadata.get("created_at"),
                "role": metadata.get("role", ROLE_USER),
            })

        return result

    def get_profile(self, profile_id):
        profile_id = normalize_profile_id(profile_id)
        for profile in self.list_profiles():
            if profile["id"] == profile_id:
                return profile
        return None

    def is_admin(self, profile_id):
        profile = self.get_profile(profile_id)
        return bool(profile and profile.get("role") == ROLE_ADMIN)

    def _new_unique_profile_id(self):
        existing = set(self.metadata) | set(self._discovered_profile_ids())
        for _ in range(100):
            candidate = generate_profile_id()
            if candidate not in existing:
                return candidate
        raise RuntimeError("Unable to generate a unique user ID")

    def create_profile(self, display_name):
        """Create a local user with immutable random ID + Ed25519 identity."""
        display_name = normalize_display_name(display_name)
        profile_id = self._new_unique_profile_id()

        existing_profiles = self.list_profiles()
        role = (
            ROLE_ADMIN
            if (not runtime().production and not existing_profiles)
            else ROLE_USER
        )

        _private_key, public_key = create_identity(profile_id)

        self.metadata[profile_id] = {
            "display_name": display_name,
            "created_at": datetime.now(timezone.utc).isoformat(),
            "role": role,
        }
        self._save()

        return {
            "id": profile_id,
            "display_name": display_name,
            "fingerprint": format_fingerprint(public_key),
            "created_at": self.metadata[profile_id]["created_at"],
            "role": role,
        }

    def set_display_name(self, profile_id, display_name):
        """Change only the human-facing display name for an existing user."""
        profile_id = normalize_profile_id(profile_id)
        display_name = normalize_display_name(display_name)

        if profile_id not in self._discovered_profile_ids():
            raise ValueError(f"Unknown local user: {profile_id}")

        metadata = self.metadata.setdefault(profile_id, {})
        metadata.setdefault("created_at", None)
        metadata.setdefault("role", ROLE_USER)
        metadata["display_name"] = display_name
        self._save()

        return self.get_profile(profile_id)
