"""Development launcher retaining the multi-profile test chooser.

Do not ship this entry point in the production installer.
"""
import os
os.environ["BASE36_DEV_MODE"] = "1"

from app import main

if __name__ == "__main__":
    main()
