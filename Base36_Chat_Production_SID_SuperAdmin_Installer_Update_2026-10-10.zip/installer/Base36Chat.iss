#define MyAppName "Base36 Chat"
#define MyAppVersion "0.5.0"
#define MyAppPublisher "Base36 Chat Project"
#define MyAppExeName "Base36Chat.exe"

[Setup]
AppId={{E5DCD146-0B88-46D9-9D49-CF7D7FE66836}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
DefaultDirName={autopf}\Base36 Chat
DefaultGroupName=Base36 Chat
DisableProgramGroupPage=yes
OutputDir=..\installer_output
OutputBaseFilename=Base36Chat-Setup
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
PrivilegesRequired=admin
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
UninstallDisplayIcon={app}\{#MyAppExeName}

[Files]
Source: "..\dist\Base36Chat\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs

[Icons]
Name: "{autoprograms}\Base36 Chat"; Filename: "{app}\{#MyAppExeName}"
Name: "{autodesktop}\Base36 Chat"; Filename: "{app}\{#MyAppExeName}"; Tasks: desktopicon

[Tasks]
Name: "desktopicon"; Description: "Create a &desktop shortcut"; GroupDescription: "Additional icons:"; Flags: unchecked

[Run]
Filename: "{app}\{#MyAppExeName}"; Description: "Launch Base36 Chat"; Flags: nowait postinstall skipifsilent

[Code]
function InitializeSetup(): Boolean;
begin
  Result := True;
end;
