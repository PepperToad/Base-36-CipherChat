@echo off
setlocal
cd /d "%~dp0\.."
set "ISCC=%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe"
if not exist "%ISCC%" set "ISCC=%ProgramFiles%\Inno Setup 6\ISCC.exe"
if not exist "%ISCC%" (
  echo ERROR: Inno Setup 6 was not found.
  exit /b 1
)
if not exist dist\Base36Chat\Base36Chat.exe (
  echo ERROR: Build dist\Base36Chat first with build_windows.bat.
  exit /b 1
)
"%ISCC%" installer\Base36Chat.iss
