"""Windows DPAPI helpers for Base36 Chat.

Production private-key blobs are encrypted for the currently signed-in Windows
user with CryptProtectData / CryptUnprotectData.  This is endpoint protection,
not a replacement for Windows account security and not a claim against a fully
compromised administrator or malware running as the user.
"""

from __future__ import annotations

import ctypes
import os
from ctypes import wintypes

CRYPTPROTECT_UI_FORBIDDEN = 0x1
DEFAULT_ENTROPY = b"Base36Chat/DPAPI/v1"


class DATA_BLOB(ctypes.Structure):
    _fields_ = [
        ("cbData", wintypes.DWORD),
        ("pbData", ctypes.POINTER(ctypes.c_ubyte)),
    ]


def _blob(data: bytes):
    if not data:
        return DATA_BLOB(0, None), None
    buf = ctypes.create_string_buffer(data, len(data))
    return (
        DATA_BLOB(
            len(data),
            ctypes.cast(buf, ctypes.POINTER(ctypes.c_ubyte)),
        ),
        buf,
    )


def _require_windows():
    if os.name != "nt":
        raise RuntimeError("Windows DPAPI is only available on Windows")


def protect_bytes(data: bytes, entropy: bytes = DEFAULT_ENTROPY) -> bytes:
    """Encrypt bytes so only the current Windows user context can unprotect them."""
    _require_windows()
    if not isinstance(data, (bytes, bytearray)):
        raise TypeError("data must be bytes")

    crypt32 = ctypes.windll.crypt32
    kernel32 = ctypes.windll.kernel32

    in_blob, in_keepalive = _blob(bytes(data))
    entropy_blob, entropy_keepalive = _blob(bytes(entropy))
    out_blob = DATA_BLOB()

    ok = crypt32.CryptProtectData(
        ctypes.byref(in_blob),
        "Base36 Chat protected data",
        ctypes.byref(entropy_blob),
        None,
        None,
        CRYPTPROTECT_UI_FORBIDDEN,
        ctypes.byref(out_blob),
    )
    # Keep buffers alive through the call.
    _ = (in_keepalive, entropy_keepalive)
    if not ok:
        raise ctypes.WinError()

    try:
        return ctypes.string_at(out_blob.pbData, out_blob.cbData)
    finally:
        if out_blob.pbData:
            kernel32.LocalFree(out_blob.pbData)


def unprotect_bytes(blob: bytes, entropy: bytes = DEFAULT_ENTROPY) -> bytes:
    """Decrypt a current-Windows-user DPAPI blob."""
    _require_windows()
    if not isinstance(blob, (bytes, bytearray)):
        raise TypeError("blob must be bytes")

    crypt32 = ctypes.windll.crypt32
    kernel32 = ctypes.windll.kernel32

    in_blob, in_keepalive = _blob(bytes(blob))
    entropy_blob, entropy_keepalive = _blob(bytes(entropy))
    out_blob = DATA_BLOB()

    ok = crypt32.CryptUnprotectData(
        ctypes.byref(in_blob),
        None,
        ctypes.byref(entropy_blob),
        None,
        None,
        CRYPTPROTECT_UI_FORBIDDEN,
        ctypes.byref(out_blob),
    )
    _ = (in_keepalive, entropy_keepalive)
    if not ok:
        raise ctypes.WinError()

    try:
        return ctypes.string_at(out_blob.pbData, out_blob.cbData)
    finally:
        if out_blob.pbData:
            kernel32.LocalFree(out_blob.pbData)
