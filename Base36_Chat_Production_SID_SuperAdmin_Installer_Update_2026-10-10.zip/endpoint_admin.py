"""Production-safe local security incident operations.

This adapter intentionally operates only on the signed-in Windows user's own
contact pin store. It never opens another Windows user's Base36 data and never
provides impersonation capability.

Cross-endpoint administrator approval can be layered later as a signed remote
authorization control; it must not be implemented by reading another user's
local files.
"""

from __future__ import annotations

from contacts import ContactStore, STATUS_LOCKED
from deployment import runtime


class EndpointSecurityAdmin:
    def __init__(self, owner_id):
        self.owner_id = str(owner_id).strip().lower()
        self.directory = runtime().data_dir

    def _store(self):
        return ContactStore(self.owner_id, directory=self.directory)

    def list_locked_incidents(self):
        store = self._store()
        incidents = []
        for entry in store.list_locked():
            incidents.append({
                "owner": self.owner_id,
                "peer": entry.get("name"),
                "old_fingerprint": entry.get("fingerprint"),
                "new_fingerprint": entry.get("presented_fingerprint"),
                "status": entry.get("status"),
            })
        return incidents

    def _require_owner(self, owner):
        if str(owner).strip().lower() != self.owner_id:
            raise PermissionError(
                "Production administrators cannot open another Windows user's local Base36 state"
            )

    def authorize_replacement(self, owner, peer, reason):
        self._require_owner(owner)
        return self._store().admin_authorize_replacement(
            peer, self.owner_id, reason
        )

    def reject_presented_key(self, owner, peer, reason):
        self._require_owner(owner)
        return self._store().admin_reject_presented_key(
            peer, self.owner_id, reason
        )

    def revoke_contact(self, owner, peer, reason):
        self._require_owner(owner)
        return self._store().admin_revoke(
            peer, self.owner_id, reason
        )
