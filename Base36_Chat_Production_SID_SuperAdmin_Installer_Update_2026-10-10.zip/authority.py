"""Cryptographic Base36 administrative authority.

There is no central role database. A Base36 environment has one authority
public key. The super administrator possesses the DPAPI-protected authority
private key. Administrator grants/revocations are signed role statements.

Role statements are deliberately about authorization only. They confer no
message-decryption capability and no ability to impersonate another user.
"""

from __future__ import annotations

import base64
import json
import os
import secrets
import time
from pathlib import Path

from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import ed25519

from deployment import runtime
from dpapi import protect_bytes, unprotect_bytes

ROLE_USER = "user"
ROLE_ADMIN = "administrator"
ROLE_SUPER_ADMIN = "super_administrator"
VALID_ISSUED_ROLES = {ROLE_USER, ROLE_ADMIN}

ENV_PROTOCOL = "BASE36-ENV-V1"
ROLE_PROTOCOL = "BASE36-ROLE-V1"
ENV_PREFIX = "B36ENV1."
ROLE_PREFIX = "B36ROLE1."
AUTHORITY_VERSION = 1


def _b64e(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).decode("ascii").rstrip("=")


def _b64d(text: str) -> bytes:
    if not isinstance(text, str):
        raise TypeError("Encoded value must be text")
    return base64.urlsafe_b64decode(text + "=" * (-len(text) % 4))


def _canonical(obj: dict) -> bytes:
    return json.dumps(
        obj,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")


def _public_bytes(public_key) -> bytes:
    return public_key.public_bytes(
        encoding=serialization.Encoding.Raw,
        format=serialization.PublicFormat.Raw,
    )


def _private_bytes(private_key) -> bytes:
    return private_key.private_bytes(
        encoding=serialization.Encoding.Raw,
        format=serialization.PrivateFormat.Raw,
        encryption_algorithm=serialization.NoEncryption(),
    )


def _public_from_text(value: str):
    raw = _b64d(value)
    if len(raw) != 32:
        raise ValueError("Invalid authority public key")
    return ed25519.Ed25519PublicKey.from_public_bytes(raw)


def _pack(prefix: str, envelope: dict) -> str:
    return prefix + _b64e(_canonical(envelope))


def _unpack(prefix: str, token: str) -> dict:
    if not isinstance(token, str) or not token.startswith(prefix):
        raise ValueError("Wrong Base36 authority token type")
    try:
        obj = json.loads(_b64d(token[len(prefix):]).decode("utf-8"))
    except Exception as exc:
        raise ValueError("Invalid Base36 authority token") from exc
    if not isinstance(obj, dict):
        raise ValueError("Invalid Base36 authority token")
    return obj


class AuthorityStore:
    def __init__(self, owner_id: str, directory=None, protector=None, unprotector=None):
        self.owner_id = str(owner_id).strip().lower()
        self.directory = Path(directory) if directory is not None else runtime().authority_dir
        self.directory.mkdir(parents=True, exist_ok=True)
        self.trust_file = self.directory / "authority_trust.json"
        self.private_file = self.directory / "authority_private.dpapi"
        self.sequence_file = self.directory / "authority_sequences.json"
        self.role_file = self.directory / f"role_{self.owner_id}.json"
        self._protect = protector or protect_bytes
        self._unprotect = unprotector or unprotect_bytes

    # ---------- environment bootstrap / trust ----------

    def has_environment(self) -> bool:
        return self.trust_file.exists()

    def load_trust(self) -> dict | None:
        if not self.trust_file.exists():
            return None
        try:
            doc = json.loads(self.trust_file.read_text(encoding="utf-8"))
        except Exception as exc:
            raise ValueError("Authority trust file is unreadable") from exc
        required = ("version", "environment_id", "authority_public_key", "super_admin_id")
        if doc.get("version") != AUTHORITY_VERSION or any(not doc.get(k) for k in required[1:]):
            raise ValueError("Authority trust file is invalid")
        _public_from_text(doc["authority_public_key"])
        return doc

    def _write_trust(self, body: dict):
        doc = {
            "version": AUTHORITY_VERSION,
            "environment_id": body["environment_id"],
            "authority_public_key": body["authority_public_key"],
            "super_admin_id": body["super_admin_id"],
        }
        temp = self.trust_file.with_suffix(".tmp")
        temp.write_text(json.dumps(doc, indent=2, sort_keys=True), encoding="utf-8")
        temp.replace(self.trust_file)

    def create_environment(self) -> dict:
        if self.has_environment() or self.private_file.exists():
            raise FileExistsError("A Base36 administrative environment already exists")

        private = ed25519.Ed25519PrivateKey.generate()
        public = private.public_key()
        environment_id = secrets.token_hex(16)
        public_text = _b64e(_public_bytes(public))

        protected = self._protect(_private_bytes(private))
        temp = self.private_file.with_suffix(".tmp")
        temp.write_bytes(protected)
        temp.replace(self.private_file)

        body = {
            "protocol": ENV_PROTOCOL,
            "environment_id": environment_id,
            "authority_public_key": public_text,
            "super_admin_id": self.owner_id,
            "created_at": int(time.time()),
        }
        self._write_trust(body)
        return body

    def _load_authority_private(self):
        trust = self.load_trust()
        if trust is None or trust.get("super_admin_id") != self.owner_id:
            raise PermissionError("Super administrator authority is required")
        if not self.private_file.exists():
            raise PermissionError("This endpoint does not possess the authority private key")
        raw = self._unprotect(self.private_file.read_bytes())
        try:
            if len(raw) != 32:
                raise ValueError("Authority private key has invalid length")
            return ed25519.Ed25519PrivateKey.from_private_bytes(raw)
        finally:
            del raw

    def is_super_admin(self) -> bool:
        try:
            trust = self.load_trust()
        except Exception:
            return False
        return bool(
            trust
            and trust.get("super_admin_id") == self.owner_id
            and self.private_file.exists()
        )

    def export_environment_invitation(self) -> str:
        trust = self.load_trust()
        if trust is None:
            raise ValueError("No Base36 environment has been configured")
        private = self._load_authority_private()
        body = {
            "protocol": ENV_PROTOCOL,
            "environment_id": trust["environment_id"],
            "authority_public_key": trust["authority_public_key"],
            "super_admin_id": trust["super_admin_id"],
            "created_at": int(time.time()),
        }
        envelope = {
            "body": body,
            "signature": _b64e(private.sign(_canonical(body))),
        }
        return _pack(ENV_PREFIX, envelope)

    @staticmethod
    def inspect_environment_invitation(token: str) -> dict:
        envelope = _unpack(ENV_PREFIX, token.strip())
        body = envelope.get("body")
        signature = envelope.get("signature")
        if not isinstance(body, dict) or not isinstance(signature, str):
            raise ValueError("Invalid environment invitation")
        if body.get("protocol") != ENV_PROTOCOL:
            raise ValueError("Unsupported environment invitation protocol")
        for key in ("environment_id", "authority_public_key", "super_admin_id", "created_at"):
            if not body.get(key):
                raise ValueError(f"Environment invitation missing {key}")
        public = _public_from_text(body["authority_public_key"])
        try:
            public.verify(_b64d(signature), _canonical(body))
        except Exception as exc:
            raise ValueError("Environment invitation signature is invalid") from exc
        return dict(body)

    def import_environment_invitation(self, token: str) -> dict:
        if self.has_environment():
            raise FileExistsError("This Windows user already trusts a Base36 environment")
        body = self.inspect_environment_invitation(token)
        self._write_trust(body)
        return body

    # ---------- roles ----------

    def _authority_public(self):
        trust = self.load_trust()
        if trust is None:
            raise ValueError("No Base36 authority is configured")
        return _public_from_text(trust["authority_public_key"])

    def _next_sequence(self, subject_id: str) -> int:
        sequences = {}
        if self.sequence_file.exists():
            try:
                sequences = json.loads(self.sequence_file.read_text(encoding="utf-8"))
            except Exception:
                sequences = {}
        current = int(sequences.get(subject_id, 0) or 0)
        value = current + 1
        sequences[subject_id] = value
        temp = self.sequence_file.with_suffix(".tmp")
        temp.write_text(json.dumps(sequences, indent=2, sort_keys=True), encoding="utf-8")
        temp.replace(self.sequence_file)
        return value

    def issue_role_token(self, subject_id: str, role: str) -> str:
        if not self.is_super_admin():
            raise PermissionError("Only the Super Administrator can issue role statements")
        subject_id = str(subject_id).strip().lower()
        if not subject_id:
            raise ValueError("Subject user ID is required")
        if role not in VALID_ISSUED_ROLES:
            raise ValueError("Role must be administrator or user")
        trust = self.load_trust()
        private = self._load_authority_private()
        body = {
            "protocol": ROLE_PROTOCOL,
            "environment_id": trust["environment_id"],
            "subject_id": subject_id,
            "role": role,
            "sequence": self._next_sequence(subject_id),
            "issued_at": int(time.time()),
            "issuer_id": self.owner_id,
        }
        envelope = {
            "body": body,
            "signature": _b64e(private.sign(_canonical(body))),
        }
        return _pack(ROLE_PREFIX, envelope)

    def verify_role_token(self, token: str) -> dict:
        envelope = _unpack(ROLE_PREFIX, token.strip())
        body = envelope.get("body")
        signature = envelope.get("signature")
        if not isinstance(body, dict) or not isinstance(signature, str):
            raise ValueError("Invalid role statement")
        if body.get("protocol") != ROLE_PROTOCOL:
            raise ValueError("Unsupported role statement protocol")
        if body.get("role") not in VALID_ISSUED_ROLES:
            raise ValueError("Invalid role in authority statement")
        if not isinstance(body.get("sequence"), int) or body["sequence"] < 1:
            raise ValueError("Invalid role statement sequence")
        trust = self.load_trust()
        if trust is None or body.get("environment_id") != trust["environment_id"]:
            raise ValueError("Role statement belongs to another Base36 environment")
        try:
            self._authority_public().verify(_b64d(signature), _canonical(body))
        except Exception as exc:
            raise ValueError("Role statement signature is invalid") from exc
        return dict(body)

    def apply_role_token(self, token: str, *, expected_subject: str | None = None) -> dict:
        body = self.verify_role_token(token)
        expected = (expected_subject or self.owner_id).strip().lower()
        if body.get("subject_id") != expected:
            raise ValueError("Role statement is addressed to another user")

        current = self.load_local_role_statement()
        if current is not None and int(body["sequence"]) <= int(current.get("sequence", 0)):
            # Old/replayed grants cannot undo a newer revocation.
            return current

        doc = {
            "version": AUTHORITY_VERSION,
            "token": token.strip(),
            "body": body,
        }
        temp = self.role_file.with_suffix(".tmp")
        temp.write_text(json.dumps(doc, indent=2, sort_keys=True), encoding="utf-8")
        temp.replace(self.role_file)
        return body

    def load_local_role_statement(self) -> dict | None:
        if not self.role_file.exists():
            return None
        try:
            doc = json.loads(self.role_file.read_text(encoding="utf-8"))
            token = doc.get("token")
            body = self.verify_role_token(token)
        except Exception:
            return None
        if body.get("subject_id") != self.owner_id:
            return None
        return body

    def role_for_owner(self) -> str:
        if self.is_super_admin():
            return ROLE_SUPER_ADMIN
        statement = self.load_local_role_statement()
        if statement and statement.get("role") == ROLE_ADMIN:
            return ROLE_ADMIN
        return ROLE_USER
