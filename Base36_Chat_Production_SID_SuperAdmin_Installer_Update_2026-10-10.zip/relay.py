"""Base36 Chat no-queue relay.

Security/storage rule:
- Opaque message payloads are forwarded immediately or dropped.
- Message payloads are NEVER placed into an offline or retry queue.
- Only short-lived receipt metadata (message ID + opaque client IDs) may exist
  while waiting for the recipient ACK. No ciphertext/message body is retained.
- No database or file storage is used.
"""

import argparse
import asyncio
import json
import re
import time
import uuid
from collections import deque

from websockets.asyncio.server import serve
from websockets.exceptions import ConnectionClosed


RELAY_PROTOCOL_VERSION = 2
MAX_WS_MESSAGE_BYTES = 512 * 1024
MAX_CLIENT_ID_LENGTH = 64
MAX_INFLIGHT = 4096
INFLIGHT_TTL_SECONDS = 60
RATE_WINDOW_SECONDS = 10
RATE_MESSAGES_PER_WINDOW = 100

CLIENT_ID_RE = re.compile(r"^[a-z0-9_-]{1,64}$")


class RateWindow:
    def __init__(self):
        self.events = deque()

    def allow(self):
        now = time.monotonic()
        cutoff = now - RATE_WINDOW_SECONDS
        while self.events and self.events[0] < cutoff:
            self.events.popleft()
        if len(self.events) >= RATE_MESSAGES_PER_WINDOW:
            return False
        self.events.append(now)
        return True


class RelayState:
    def __init__(self, relay_name):
        self.relay_name = relay_name
        self.connections = {}
        self.inflight = {}
        self.lock = asyncio.Lock()

    async def register(self, client_id, websocket):
        async with self.lock:
            existing = self.connections.get(client_id)
            if existing is not None and existing is not websocket:
                return False
            self.connections[client_id] = websocket
            return True

    async def unregister(self, client_id, websocket):
        notifications = []
        async with self.lock:
            if self.connections.get(client_id) is websocket:
                self.connections.pop(client_id, None)

            # No payload is stored. If the intended recipient disappears,
            # receipt metadata is no longer useful, so remove it immediately.
            stale = [
                message_id
                for message_id, meta in self.inflight.items()
                if meta["recipient"] == client_id
            ]
            for message_id in stale:
                meta = self.inflight.pop(message_id)
                notifications.append((meta["sender"], message_id))

        for sender, message_id in notifications:
            await self.notify_sender(
                sender,
                {
                    "type": "error",
                    "code": "recipient_disconnected",
                    "error": "Recipient disconnected before delivery was confirmed",
                    "message_id": message_id,
                },
            )

    async def websocket_for(self, client_id):
        async with self.lock:
            return self.connections.get(client_id)

    async def add_inflight(self, message_id, sender, recipient):
        async with self.lock:
            if len(self.inflight) >= MAX_INFLIGHT:
                return False
            if message_id in self.inflight:
                return False
            self.inflight[message_id] = {
                "sender": sender,
                "recipient": recipient,
                "created": time.monotonic(),
            }
            return True

    async def acknowledge(self, message_id, recipient):
        async with self.lock:
            meta = self.inflight.get(message_id)
            if meta is None or meta["recipient"] != recipient:
                return None
            self.inflight.pop(message_id, None)
            return meta

    async def remove_inflight(self, message_id):
        async with self.lock:
            return self.inflight.pop(message_id, None)

    async def notify_sender(self, sender, packet):
        websocket = await self.websocket_for(sender)
        if websocket is None:
            return False
        try:
            await websocket.send(json.dumps(packet, separators=(",", ":")))
            return True
        except Exception:
            return False

    async def cleanup_loop(self):
        while True:
            await asyncio.sleep(2)
            expired = []
            now = time.monotonic()
            async with self.lock:
                for message_id, meta in list(self.inflight.items()):
                    if now - meta["created"] >= INFLIGHT_TTL_SECONDS:
                        expired.append((message_id, meta))
                        self.inflight.pop(message_id, None)

            for message_id, meta in expired:
                await self.notify_sender(
                    meta["sender"],
                    {
                        "type": "delivery_timeout",
                        "message_id": message_id,
                        "to": meta["recipient"],
                    },
                )


def valid_client_id(value):
    return isinstance(value, str) and bool(CLIENT_ID_RE.fullmatch(value.strip().lower()))


def valid_message_id(value):
    if not isinstance(value, str):
        return False
    try:
        uuid.UUID(value)
        return True
    except (ValueError, TypeError, AttributeError):
        return False


async def safe_send(websocket, packet):
    await websocket.send(json.dumps(packet, separators=(",", ":")))


async def handle_client(websocket, state):
    client_id = None
    rate = RateWindow()

    try:
        try:
            raw = await asyncio.wait_for(websocket.recv(), timeout=10)
            registration = json.loads(raw)
        except Exception:
            await safe_send(websocket, {"type": "error", "error": "Registration required"})
            return

        if not isinstance(registration, dict) or registration.get("type") != "register":
            await safe_send(websocket, {"type": "error", "error": "Registration required"})
            return

        client_id = str(registration.get("client_id", "")).strip().lower()
        if not valid_client_id(client_id):
            await safe_send(websocket, {"type": "error", "error": "Invalid client ID"})
            return

        if not await state.register(client_id, websocket):
            await safe_send(
                websocket,
                {
                    "type": "error",
                    "code": "already_connected",
                    "error": "This client ID is already connected",
                },
            )
            return

        await safe_send(
            websocket,
            {
                "type": "registered",
                "relay_protocol": RELAY_PROTOCOL_VERSION,
                "queue_mode": "none",
                "receipts": True,
                "max_message_bytes": MAX_WS_MESSAGE_BYTES,
            },
        )

        async for raw in websocket:
            if not rate.allow():
                await safe_send(
                    websocket,
                    {
                        "type": "error",
                        "code": "rate_limited",
                        "error": "Rate limit exceeded",
                    },
                )
                continue

            if isinstance(raw, bytes):
                if len(raw) > MAX_WS_MESSAGE_BYTES:
                    await websocket.close(code=1009, reason="Message too large")
                    return
                try:
                    raw = raw.decode("utf-8")
                except UnicodeDecodeError:
                    continue
            elif not isinstance(raw, str):
                continue

            if len(raw.encode("utf-8")) > MAX_WS_MESSAGE_BYTES:
                await websocket.close(code=1009, reason="Message too large")
                return

            try:
                packet = json.loads(raw)
            except json.JSONDecodeError:
                await safe_send(websocket, {"type": "error", "error": "Invalid JSON"})
                continue

            if not isinstance(packet, dict):
                await safe_send(websocket, {"type": "error", "error": "Invalid packet"})
                continue

            packet_type = packet.get("type")

            if packet_type == "message":
                message_id = packet.get("message_id")
                recipient = str(packet.get("to", "")).strip().lower()
                payload = packet.get("payload")

                if not valid_message_id(message_id) or not valid_client_id(recipient) or not isinstance(payload, dict):
                    await safe_send(
                        websocket,
                        {
                            "type": "error",
                            "code": "invalid_message",
                            "error": "Invalid message envelope",
                            "message_id": message_id if isinstance(message_id, str) else None,
                        },
                    )
                    continue

                recipient_socket = await state.websocket_for(recipient)
                if recipient_socket is None:
                    await safe_send(
                        websocket,
                        {
                            "type": "error",
                            "code": "recipient_offline",
                            "error": "Recipient is offline; message was not retained",
                            "message_id": message_id,
                        },
                    )
                    continue

                if not await state.add_inflight(message_id, client_id, recipient):
                    await safe_send(
                        websocket,
                        {
                            "type": "error",
                            "code": "duplicate_or_busy",
                            "error": "Message ID already active or relay is busy",
                            "message_id": message_id,
                        },
                    )
                    continue

                forwarded = {
                    "type": "message",
                    "message_id": message_id,
                    "from": client_id,
                    "to": recipient,
                    "payload": payload,
                }

                try:
                    await safe_send(recipient_socket, forwarded)
                except Exception:
                    await state.remove_inflight(message_id)
                    await safe_send(
                        websocket,
                        {
                            "type": "error",
                            "code": "delivery_failed",
                            "error": "Immediate delivery failed; message was not retained",
                            "message_id": message_id,
                        },
                    )
                    continue

                # The relay does not retain `forwarded` or `payload` after this point.
                await safe_send(
                    websocket,
                    {
                        "type": "accepted",
                        "message_id": message_id,
                        "to": recipient,
                    },
                )
                continue

            if packet_type == "ack":
                message_id = packet.get("message_id")
                if not valid_message_id(message_id):
                    continue

                meta = await state.acknowledge(message_id, client_id)
                if meta is not None:
                    await state.notify_sender(
                        meta["sender"],
                        {
                            "type": "delivered",
                            "message_id": message_id,
                            "to": client_id,
                        },
                    )
                continue

            await safe_send(websocket, {"type": "error", "error": "Unknown packet type"})

    except asyncio.CancelledError:
        raise
    except ConnectionClosed:
        pass
    finally:
        if client_id is not None:
            await state.unregister(client_id, websocket)


async def run_server(host, port, relay_name):
    state = RelayState(relay_name)
    cleanup = asyncio.create_task(state.cleanup_loop())
    print(f"{relay_name} listening on {host}:{port} (NO MESSAGE QUEUE)")
    try:
        async with serve(
            lambda websocket: handle_client(websocket, state),
            host,
            port,
            max_size=MAX_WS_MESSAGE_BYTES,
            ping_interval=20,
            ping_timeout=20,
            close_timeout=5,
            compression=None,
        ):
            await asyncio.Future()
    finally:
        cleanup.cancel()
        await asyncio.gather(cleanup, return_exceptions=True)
        async with state.lock:
            state.inflight.clear()
            state.connections.clear()


def main():
    parser = argparse.ArgumentParser(description="Base36 Chat no-queue WebSocket relay")
    parser.add_argument("--host", default="0.0.0.0")
    parser.add_argument("--port", type=int, required=True)
    parser.add_argument("--name", default="Base36 Relay")
    args = parser.parse_args()

    try:
        asyncio.run(run_server(args.host, args.port, args.name))
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
